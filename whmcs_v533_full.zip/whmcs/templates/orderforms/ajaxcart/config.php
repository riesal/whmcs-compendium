<?php

$orderconf = array(

    'directpidstep1' => true,

    'denynonajaxaccess' => array(
        'confdomains',
        'view',
        'checkout'
    ),

);

?>