<?php
/**
 * WHMCS Language File
 * Danish (da)
 *
 * Please Note: These language files are overwritten during software updates
 * and therefore editing of these files directly is not advised. Instead we
 * recommend that you use overrides to customise the text displayed in a way
 * which will be safely preserved through the upgrade process.
 *
 * For instructions on overrides, please visit:
 *   http://docs.whmcs.com/Language_Overrides
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

if (!defined("WHMCS")) die("This file cannot be accessed directly");

$_LANG['isocode'] = "da";

$_LANG['accountinfo'] = "Konto information";
$_LANG['accountstats'] = "Konto statistik";
$_LANG['addfunds'] = "Tank penge på din konto";
$_LANG['addfundsamount'] = "Beløb til optankning";
$_LANG['addfundsmaximum'] = "Maximum optankning";
$_LANG['addfundsmaximumbalance'] = "Maximum balance";
$_LANG['addfundsmaximumbalanceerror'] = "Maximum balance er";
$_LANG['addfundsmaximumerror'] = "Maximum beløb til optankning er";
$_LANG['addfundsminimum'] = "Minimum optankning";
$_LANG['addfundsminimumerror'] = "Minimum beløb til optankning er";
$_LANG['addmore'] = "Add More";
$_LANG['addtocart'] = "Tilføj til bestillingskurv";
$_LANG['affiliatesactivate'] = "Aktiver affiliate konto";
$_LANG['affiliatesamount'] = "Beløb";
$_LANG['affiliatesbalance'] = "Nuværende balance";
$_LANG['affiliatesbullet1'] = "Modtage en bonus på din affiliate konto på";
$_LANG['affiliatesbullet2'] = "for alle bestillinger kunde foretager, som er henvist af dig";
$_LANG['affiliatescommission'] = "Provision";
$_LANG['affiliatesdescription'] = "Klik her for at blive affiliate eller se dine indtjeninger";
$_LANG['affiliatesdisabled'] = "Vi tilbyder i øjeblikket ikke et affiliate system til vores kunder.";
$_LANG['affiliatesearn'] = "Tjen";
$_LANG['affiliatesearningstodate'] = "Total indtjening til dato";
$_LANG['affiliatesfootertext'] = "Når du henviser nogen til vores hjemmeside med dit unikke henvisnings ID, vil en cookie blive gemt med dit ID, så hvis de bestiller senere vil du stadig modtage din henvisningsprovision.";
$_LANG['affiliateshostingpackage'] = "Hosting pakke";
$_LANG['affiliatesintrotext'] = "Aktiver din affiliate konto idag for at:";
$_LANG['affiliateslinktous'] = "Link til os";
$_LANG['affiliatesnosignups'] = "Du har ikke henvist nogle bestillinger";
$_LANG['affiliatesrealtime'] = "Disse statistikker er i real time og altid opdateret";
$_LANG['affiliatesreferallink'] = "Dit unikke henvisningslink";
$_LANG['affiliatesreferals'] = "Dine henvisninger";
$_LANG['affiliatesregdate'] = "Registreringsdato";
$_LANG['affiliatesrequestwithdrawal'] = "Bed om udbetaling";
$_LANG['affiliatessignupdate'] = "Bestillingsdato";
$_LANG['affiliatesstatus'] = "Status";
$_LANG['affiliatestitle'] = "Affiliates";
$_LANG['affiliatesvisitorsreferred'] = "Antal henviste besøgende";
$_LANG['affiliateswithdrawalrequestsuccessful'] = "Din forespørgsel om udbetaling er blevet sendt. Du vil blive kontaktet snarest muligt.";
$_LANG['affiliateswithdrawn'] = "Total beløb";
$_LANG['all'] = "Alle";
$_LANG['alreadyregistered'] = "Allerede registreret?";
$_LANG['announcementsdescription'] = "Se nyheder og annonceringer";
$_LANG['announcementsnone'] = "Ingen annonceringer";
$_LANG['announcementsrss'] = "Vis RSS Feed";
$_LANG['announcementstitle'] = "Annonceringer";
$_LANG['bannedbanexpires'] = "Spærring ophører";
$_LANG['bannedbanreason'] = "Grund til spærring:";
$_LANG['bannedhasbeenbanned'] = "er spærret for tilgang til denne side";
$_LANG['bannedtitle'] = "IP spærret";
$_LANG['bannedyourip'] = "Din IP";
$_LANG['cartaddons'] = "Addons";
$_LANG['cartbrowse'] = "Gennemse produkter &amp; services";
$_LANG['cartconfigdomainextras'] = "Konfigurer domæne addons";
$_LANG['cartconfigoptionsdesc'] = "Dette produkt/service har nogle muligheder, som du vælge imellem.";
$_LANG['cartconfigserver'] = "Konfigurer server";
$_LANG['cartcustomfieldsdesc'] = "Dette produkt/service kræver ekstra information.";
$_LANG['cartdomainsconfig'] = "Domæne konfiguration";
$_LANG['cartdomainsconfigdesc'] = "Nedenfor kan du konfigurere domæner i din bestillingskurv.";
$_LANG['cartdomainshashosting'] = "Har hosting";
$_LANG['cartdomainsnohosting'] = "Ingen hosting! Klik her for at tilføje hosting";
$_LANG['carteditproductconfig'] = "Rediger tilpasning";
$_LANG['cartempty'] = "Din bestillingskurv er tom";
$_LANG['cartemptyconfirm'] = "Er du sikker på, at du vil tømme din bestillingskurv?";
$_LANG['cartexistingclientlogin'] = "Eksisterende kunde login";
$_LANG['cartexistingclientlogindesc'] = "For at tilføjge denne bestilling til din eksisterende konto, skal du logge ind nedenfor.";
$_LANG['cartnameserversdesc'] = "Hvis du ønsker at tilføje custom navneserverer skal du indtaste dem nedenfor. Som standard vil domæner benytte vores navneservere.";
$_LANG['cartproductaddons'] = "Produkt addons";
$_LANG['cartproductaddonschoosepackage'] = "Vælg pakke";
$_LANG['cartproductaddonsnone'] = "Ingen addons tilgængeligt for dine produkter &amp; services";
$_LANG['cartproductconfig'] = "Produkt konfiguration";
$_LANG['cartproductdesc'] = "Dette produkt/service har følgende mulighed for tilpasning.";
$_LANG['cartproductdomain'] = "Domæner";
$_LANG['cartproductdomainchoose'] = "Vælg domæne";
$_LANG['cartproductdomaindesc'] = "Dette produkt/service kræver et domæne. Indtast domæne nedenfor.";
$_LANG['cartproductdomainuseincart'] = "Brug et domæne, som allerede er i din bestillingskurv";
$_LANG['cartremove'] = "Slet";
$_LANG['cartremoveitemconfirm'] = "Er du sikker på, at du vil slette dette produkt fra din bestillingskurv?";
$_LANG['carttaxupdateselections'] = "Moms vil blive opkrævet afhængigt af det land du bor i. Klik her for at genberegne moms";
$_LANG['carttaxupdateselectionsupdate'] = "Opdater";
$_LANG['carttitle'] = "Bestillingskurv";
$_LANG['changessavedsuccessfully'] = "Changes Saved Successfully!";
$_LANG['checkavailability'] = "Check om domæne er ledigt";
$_LANG['checkout'] = "Checkout";
$_LANG['choosecurrency'] = "Vælg valuta";
$_LANG['choosedomains'] = "Vælg domæne";
$_LANG['clickheretologin'] = "Klik her for at logge ind";
$_LANG['clientareaaccountaddons'] = "Konto addons";
$_LANG['clientareaactive'] = "Aktive";
$_LANG['clientareaaddfundsdisabled'] = "We do not allow depositing funds in advance with us at the current time.";
$_LANG['clientareaaddfundsnotallowed'] = "Du skal have mindst en aktiv ordre for at kunne tanke penge på din konto. Du kan ikke fortsætte på nuværende tidspunkt!";
$_LANG['clientareaaddon'] = "Addon";
$_LANG['clientareaaddonorderconfirmation'] = "Tak for din for din ordre. Vi har modtaget en bestilling på nedenstående, vælg venligst betalingsmetoden nedenfor.";
$_LANG['clientareaaddonpricing'] = "Pris";
$_LANG['clientareaaddonsfor'] = "Addons for";
$_LANG['clientareaaddress1'] = "Adresse 1";
$_LANG['clientareaaddress2'] = "Adresse 2";
$_LANG['clientareabwlimit'] = "Trafik til rådighed";
$_LANG['clientareabwusage'] = "Trafik forbrug";
$_LANG['clientareacancel'] = "Fortryd ændringer";
$_LANG['clientareacancelconfirmation'] = "Vi har modtaget dit ønske om opsigelse. Hvis det er en fejl skal du kontakte supporten.";
$_LANG['clientareacancelinvalid'] = "Dette produkt er enten opsagt eller afventer godkendelse af opsigelse.";
$_LANG['clientareacancellationendofbillingperiod'] = "Ved udløbsperioden";
$_LANG['clientareacancellationimmediate'] = "Øjeblikkeligt";
$_LANG['clientareacancellationtype'] = "Opsigelses type";
$_LANG['clientareacancelled'] = "annulleret";
$_LANG['clientareacancelproduct'] = "Jeg ønsker at opsige";
$_LANG['clientareacancelreason'] = "Jeg ønsker at opsige fordi";
$_LANG['clientareacancelrequest'] = "Opsigelse";
$_LANG['clientareacancelrequestbutton'] = "Opsigelse";
$_LANG['clientareachangepassword'] = "Skift dit password";
$_LANG['clientareachangesuccessful'] = "Dine kundeinformationer blev ændret";
$_LANG['clientareachoosecontact'] = "Vælg kontakt";
$_LANG['clientareacity'] = "By";
$_LANG['clientareacompanyname'] = "Firma";
$_LANG['clientareaconfirmpassword'] = "Bekræft password";
$_LANG['clientareacontactsemails'] = "E-mail Preferencer";
$_LANG['clientareacontactsemailsdomain'] = "Domæne e-mails - Fornyelses påmindelser, registrerings bekræftelser osv.";
$_LANG['clientareacontactsemailsgeneral'] = "Generelle e-mails - Generel annoncering & password reminders";
$_LANG['clientareacontactsemailsinvoice'] = "Faktura e-mails - Faktura & rykkerskrivelser";
$_LANG['clientareacontactsemailsproduct'] = "Produkt e-mails - Ordre detaljer, Velkomst e-mail osv.";
$_LANG['clientareacontactsemailssupport'] = "Support e-mails - Support ticket information";
$_LANG['clientareacountry'] = "Land";
$_LANG['clientareacurrentsecurityanswer'] = "Please enter your current answer";
$_LANG['clientareacurrentsecurityquestion'] = "Please choose your current security question";
$_LANG['clientareadeletecontact'] = "Slet kontakt";
$_LANG['clientareadeletecontactareyousure'] = "Er du sikker på, at du vil slette denne kontakt?";
$_LANG['clientareadescription'] = "klik her for at redigere dine informationer, se faktura og bestille ekstra produkter og services";
$_LANG['clientareadisklimit'] = "Diskplads til rådighed";
$_LANG['clientareadiskusage'] = "Diskplads forbrug";
$_LANG['clientareadomainexpirydate'] = "Udløbsdato";
$_LANG['clientareadomainnone'] = "Du har ingen registrerede domæner hos os";
$_LANG['clientareaemail'] = "E-mail adresse";
$_LANG['clientareaemails'] = "Mine e-mails";
$_LANG['clientareaemailsdate'] = "Sendt den";
$_LANG['clientareaemailsintrotext'] = "Nedenfor er en historik af all beskeder vi har sendt til dig. Dette giver dig adgang til altid at se hvad vi har skrevet til dig.";
$_LANG['clientareaemailssubject'] = "Besked emne";
$_LANG['clientareaerroraddress1'] = "Du indtastede ikke din adresse (linie 1)";
$_LANG['clientareaerroraddress12'] = "Din adresse kan kun indeholde bogstaver, tal og mellemrum";
$_LANG['clientareaerrorbannedemail'] = "Vi tillader ikke brugere med den e-mail udbyder du indtastede. Prøv venligst en anden e-mail adresse.";
$_LANG['clientareaerrorcity'] = "Du indtastede ikke din by";
$_LANG['clientareaerrorcity2'] = "Din by kan kun indeholde bogstaver, tal og mellemrum";
$_LANG['clientareaerrorcountry'] = "vælg venligst land fra drop down boksen";
$_LANG['clientareaerroremail'] = "Du indtastede ikke din e-mail adresse";
$_LANG['clientareaerroremailinvalid'] = "Den indtastede e-mail adresse er ikke gyldig";
$_LANG['clientareaerrorfirstname'] = "Du indtastede ikke dit fornavn";
$_LANG['clientareaerrorfirstname2'] = "Dit fornavn kan kun indeholde bogstaver";
$_LANG['clientareaerrorisrequired'] = "er påkrævet";
$_LANG['clientareaerrorlastname'] = "Du indtastede ikke dit efternavn";
$_LANG['clientareaerrorlastname2'] = "Dit efternavn kan kun indeholde bogstaver";
$_LANG['clientareaerroroccured'] = "En fejl er opstået, prøv venligst igen senere.";
$_LANG['clientareaerrorpasswordconfirm'] = "Du bekræftede ikke dit password";
$_LANG['clientareaerrorpasswordnotmatch'] = "De indtastede passwords er ikke ens";
$_LANG['clientareaerrorphonenumber'] = "Du indtastede ikke dit telefonnummer";
$_LANG['clientareaerrorphonenumber2'] = "Dit telefonnummer er ikke gyldigt";
$_LANG['clientareaerrorpostcode'] = "Du indtastede ikke dit postnummer";
$_LANG['clientareaerrorpostcode2'] = "Dit postnummer kan kun indeholde tal";
$_LANG['clientareaerrors'] = "Følgende fejl er sket:";
$_LANG['clientareaerrorstate'] = "Du indtastede ikke dit region";
$_LANG['clientareaexpired'] = "Udløbet";
$_LANG['clientareafirstname'] = "Fornavn";
$_LANG['clientareafraud'] = "Fraud";
$_LANG['clientareafullname'] = "Kunde";
$_LANG['clientareaheader'] = "Velkommen til vores kundeside. Kundesiden giver dig adgang til at se, samt redigere dine kunde-informationer. Du kan se dine hosting pakker og domæner, oprette support tickets og bestille ekstra produkter &amp; services.";
$_LANG['clientareahostingaddons'] = "Addons";
$_LANG['clientareahostingaddonsintro'] = "You have the following addons for this product.";
$_LANG['clientareahostingaddonsview'] = "Vis";
$_LANG['clientareahostingamount'] = "Beløb";
$_LANG['clientareahostingdomain'] = "Domæne";
$_LANG['clientareahostingnextduedate'] = "Næste faktureringsdato";
$_LANG['clientareahostingpackage'] = "Pakke";
$_LANG['clientareahostingregdate'] = "Registrerings Dato";
$_LANG['clientarealastname'] = "Efternavn";
$_LANG['clientarealastupdated'] = "sidst opdateret";
$_LANG['clientarealeaveblank'] = "Efterlad blank, hvis du ikke vil ændre dit password.";
$_LANG['clientareamodifydomaincontactinfo'] = "Rediger domæne kontakt information";
$_LANG['clientareamodifynameservers'] = "Regider navneservere";
$_LANG['clientareamodifywhoisinfo'] = "Rediger WHOIS kontakt information";
$_LANG['clientareanameserver'] = "Navneserver";
$_LANG['clientareanavaddcontact'] = "Tilføj ny kontakt";
$_LANG['clientareanavchangecc'] = "Skift kreditkort detaljer";
$_LANG['clientareanavchangepw'] = "Skift password";
$_LANG['clientareanavdetails'] = "Mine informationer";
$_LANG['clientareanavdomains'] = "Mine domæner";
$_LANG['clientareanavhome'] = "Kundeside";
$_LANG['clientareanavlogout'] = "Log ud";
$_LANG['clientareanavorder'] = "Bestil ekstra produkter";
$_LANG['clientareanavsecurityquestions'] = "Change Security Question";
$_LANG['clientareanavservices'] = "My Services";
$_LANG['clientareanavsupporttickets'] = "Mine support tickets";
$_LANG['clientareanocontacts'] = "Ingen kontakter fundet";
$_LANG['clientareapassword'] = "Password";
$_LANG['clientareapending'] = "Afventende";
$_LANG['clientareapendingtransfer'] = "Pending Transfer";
$_LANG['clientareaphonenumber'] = "Telefonnummer";
$_LANG['clientareapostcode'] = "Postnummer";
$_LANG['clientareaproductdetails'] = "Produkt detaljer";
$_LANG['clientareaproducts'] = "Mine produkter &amp; services";
$_LANG['clientareaproductsnone'] = "Ingen produkter/services bestilt";
$_LANG['clientarearegistrationperiod'] = "Registreringsperiode";
$_LANG['clientareasavechanges'] = "Gem ændringer";
$_LANG['clientareasecurityanswer'] = "Please enter an answer";
$_LANG['clientareasecurityconfanswer'] = "Please confirm your answer";
$_LANG['clientareasecurityquestion'] = "Please choose a security question";
$_LANG['clientareaselectcountry'] = "Vælg land";
$_LANG['clientareasetlocking'] = "Lås domæner";
$_LANG['clientareastate'] = "Region";
$_LANG['clientareastatus'] = "Status";
$_LANG['clientareasuspended'] = "Suspenderet";
$_LANG['clientareaterminated'] = "Opsagt";
$_LANG['clientareaticktoenable'] = "Klik for at aktivere";
$_LANG['clientareatitle'] = "Kundeside";
$_LANG['clientareaunlimited'] = "Ubegrænset";
$_LANG['clientareaupdatebutton'] = "Opdater";
$_LANG['clientareaupdateyourdetails'] = "Opdater dine informationer";
$_LANG['clientareaused'] = "Brugt";
$_LANG['clientareaviewaddons'] = "Vis tilgængelige addons";
$_LANG['clientareaviewdetails'] = "Vis detaljer";
$_LANG['clientlogin'] = "Kunde login";
$_LANG['clientregisterheadertext'] = "Udfyld venligst felterne nedenfor for at oprette en konto. Felter markeret med * er påkrævet.";
$_LANG['clientregistertitle'] = "Registrer";
$_LANG['clientregisterverify'] = "Verificer registrering";
$_LANG['clientregisterverifydescription'] = "Indtast venligst teksten du ser i billedet nedefor i boksen. Dette er påkrævet for at undgå spam.";
$_LANG['clientregisterverifyinvalid'] = "Verificeringskoden du indtastede er ikke korrekt";
$_LANG['closewindow'] = "Luk vindue";
$_LANG['completeorder'] = "Gennemfør bestilling";
$_LANG['confirmnewpassword'] = "Bekræft nyt password";
$_LANG['contactemail'] = "E-mail";
$_LANG['contacterrormessage'] = "Du indtastede ikke en besked";
$_LANG['contacterrorname'] = "Du indtastede ikke dit navn";
$_LANG['contacterrorsubject'] = "Du indtastede ikke et emne";
$_LANG['contactheader'] = "Hvis du har spørgsmål før du bestiller eller ønske at kontakte os kan du benytte formularen nedenfor.";
$_LANG['contactmessage'] = "Besked";
$_LANG['contactname'] = "Navn";
$_LANG['contactsend'] = "Send besked";
$_LANG['contactsent'] = "Din besked er sendt";
$_LANG['contactsubject'] = "Emne";
$_LANG['contacttitle'] = "Kontakt os";
$_LANG['continueshopping'] = "Fortsæt med indkøb";
$_LANG['creditcard'] = "Betal med kreditkort";
$_LANG['creditcard3dsecure'] = "As part of our fraud prevention measures, you will now be asked to perform the Verified by Visa or Mastercard SecureCode checks if your credit card is enrolled for this service";
$_LANG['creditcardcardexpires'] = "Udløbsdato";
$_LANG['creditcardcardissuenum'] = "Issue nummer";
$_LANG['creditcardcardnumber'] = "Kortnummer";
$_LANG['creditcardcardstart'] = "Start dato";
$_LANG['creditcardcardtype'] = "Kort type";
$_LANG['creditcardccvinvalid'] = "Kort koden du indtastede er ikke gyldig";
$_LANG['creditcardconfirmation'] = "De indtastede kort detaljer blev accepteret og den første betaling er foretaget. Der er sendt en bekræftelse på e-mail.";
$_LANG['creditcardcvvnumber'] = "CVV/CVC2 Nummer";
$_LANG['creditcardcvvwhere'] = "Hvor finder jeg det?";
$_LANG['creditcarddeclined'] = "De indtastede kreditkort informationer blev afvist. Prøv venligst igen eller kontakt supporten.";
$_LANG['creditcarddetails'] = "Kredit kort detaljer";
$_LANG['creditcardenterexpirydate'] = "Du indtastede ikke udløbsdato";
$_LANG['creditcardenternewcard'] = "Indtast nyt kort nedenfor";
$_LANG['creditcardenternumber'] = "Du skal indtaste dit kortnummer";
$_LANG['creditcardinvalid'] = "De indtastede kreditkort informationer er ikke gyldige. Prøv venligst igen eller kontakt supporten.";
$_LANG['creditcardnumberinvalid'] = "Det indtastede kortnummer er ikke gyldigt";
$_LANG['creditcardsecuritynotice'] = "Data du indtaster her blevet sendt sikkert via en krypteret SSL forbindelse";
$_LANG['creditcarduseexisting'] = "Brug eksisterende kreditkort";
$_LANG['customfieldvalidationerror'] = "Det indtastede er ikke gyldigt";
$_LANG['days'] = "Dage";
$_LANG['defaultbillingcontact'] = "Standar faktura kontakt";
$_LANG['domainalternatives'] = "Du kan prøve et af disse alternativer:";
$_LANG['domainavailable'] = "Heldige kartoffel! Bestil nu";
$_LANG['domainavailable1'] = "Heldige kartoffel!";
$_LANG['domainavailable2'] = "er ledigt!";
$_LANG['domainavailableexplanation'] = "For at registrere domænet, klik linket nedenfor";
$_LANG['domainbulksearch'] = "Masse domæne søgning";
$_LANG['domainbulksearchintro'] = "Masse domæne søgningen giver dig adgang til at søge op til 20 domæner på én gang. Indtast domænerne i feltet nedenfor - en per linie. Du skal ikke taste www. eller http:// foran.";
$_LANG['domainbulktransferdescription'] = "Du kan flytte dit nuværende domæne til os i dag.  Det er nemt, du skal bare indtaste dit domæne nedenfor - et domæne per linje og du skal ikke engang taste www. or http://";
$_LANG['domainbulktransfersearch'] = "Masse domæne flytning";
$_LANG['domaincheckerdescription'] = "Se om et domæne er ledigt";
$_LANG['domaincontactinfo'] = "Kontakt information";
$_LANG['domaincurrentrenewaldate'] = "Nuværende fornyelsesdato";
$_LANG['domaindnsaddress'] = "Adresse";
$_LANG['domaindnshostname'] = "Hostnavn";
$_LANG['domaindnsmanagement'] = "DNS Administration";
$_LANG['domaindnsmanagementdesc'] = "Peg dit domæne til en hjemmeside ved at pege det til en IP adresse eller videresend dit domæne til en anden hjemmeside (parkering).";
$_LANG['domaindnsrecordtype'] = "Record type";
$_LANG['domainemailforwarding'] = "E-mail videresendelse";
$_LANG['domainemailforwardingdesc'] = "Hvis vores e-mail videresendelses server registrerer en fejl i modtager adressen, vil systemet automatisk deaktivere videresendelsen. Hvis du ændrer i adressen skal du være opmærksom på, at der kan gå op til en time før ændringerne træder i kraft.";
$_LANG['domainemailforwardingforwardto'] = "Videresend til";
$_LANG['domainemailforwardingprefix'] = "Prefix";
$_LANG['domaineppcode'] = "EPP kode";
$_LANG['domaineppcodedesc'] = "Denne kan du få ved nuværende domæne registrator";
$_LANG['domaineppcoderequired'] = "Du skal indtaste EPP kode for";
$_LANG['domainerror'] = "Der skete en fejl i din forespørgsel";
$_LANG['domainerrornodomain'] = "Indtast venligst et gyldigt domænenavn";
$_LANG['domainerrortoolong'] = "Domænet du indtastede er for langt. Domæner kan kun være op 67 karakterer.";
$_LANG['domaingeteppcode'] = "Hent EPP kode";
$_LANG['domaingeteppcodeemailconfirmation'] = "Din forespørgsel på EPP koden blev registreret. Koden er sendt til ejern af domænets e-mail adresse.";
$_LANG['domaingeteppcodeexplanation'] = "EPP koden er et password for et domæne. Det er en ekstra sikkerhed, der sikrer, at det kun er ejeren af domænet, der kan flytte domænet. Du skal bruge koden, hvis du vil flytte domænet på et senere tidspunkt.";
$_LANG['domaingeteppcodefailure'] = "Der skete en fejl:";
$_LANG['domaingeteppcodeis'] = "EPP koden for domænet er:";
$_LANG['domainidprotection'] = "ID Beskyttelse";
$_LANG['domainintrotext'] = "Indtast domæne i boksen og klik check domæne for at se om domænet er ledigt.";
$_LANG['domainlookupbutton'] = "Check domæne";
$_LANG['domainmanagementtools'] = "Administrations værktøj";
$_LANG['domainminyears'] = "Min. år";
$_LANG['domainmoreinfo'] = "Mere info";
$_LANG['domainname'] = "Domæne navn";
$_LANG['domainnameserver1'] = "Navneserver 1";
$_LANG['domainnameserver2'] = "Navneserver 2";
$_LANG['domainnameserver3'] = "Navneserver 3";
$_LANG['domainnameserver4'] = "Navneserver 4";
$_LANG['domainnameserver5'] = "Nameserver 5";
$_LANG['domainnameservers'] = "Navneservere";
$_LANG['domainordernow'] = "Bestil nu!";
$_LANG['domainorderrenew'] = "Forny domæne";
$_LANG['domainprice'] = "Pris";
$_LANG['domainregisterns'] = "Register navneservere";
$_LANG['domainregisternscurrentip'] = "Nuværende IP adresse";
$_LANG['domainregisternsdel'] = "Slet en navneserver";
$_LANG['domainregisternsdelsuccess'] = "Navneserveren  blev slettet korrekt";
$_LANG['domainregisternsexplanation'] = "Her kan du oprette og administrere navneservere for dine domæner (f.eks. NS1.youdomain.dk, NS2.yourdomain.dk)";
$_LANG['domainregisternsip'] = "IP adresse";
$_LANG['domainregisternsmod'] = "Rediger en navneserver IP";
$_LANG['domainregisternsmodsuccess'] = "Navneserveren  blev redigeret korrekt";
$_LANG['domainregisternsnewip'] = "Ny IP adresse";
$_LANG['domainregisternsns'] = "Navneserver";
$_LANG['domainregisternsreg'] = "Registrer et navneserver navn";
$_LANG['domainregisternsregsuccess'] = "Navneserveren  blev registreret korrekt";
$_LANG['domainregistrantchoose'] = "Vælg kontakt du ønsker at benytte her";
$_LANG['domainregistrantinfo'] = "Domæne registrant information";
$_LANG['domainregistrarlock'] = "Overførsels kode";
$_LANG['domainregistrarlockdesc'] = "Aktiver overførsels kode (anbefales). uautoriserede flytninger af domænet vil blive afvist hvis overførsels kode er aktiveret.";
$_LANG['domainregistration'] = "Domæne registrering";
$_LANG['domainregistryinfo'] = "Domæne registrerings information";
$_LANG['domainregnotavailable'] = "N/A";
$_LANG['domainrenew'] = "Forny domæne";
$_LANG['domainrenewal'] = "Domæne fornyelse";
$_LANG['domainrenewalprice'] = "Fornyelse";
$_LANG['domainrenewdesc'] = "Du kan sikre dig dit domæne ved at tilføje flere års betaling på det. Vælg hvor mange år du ønsker at forny det for og klik forny domæne.";
$_LANG['domainsautorenew'] = "Auto fornyelse";
$_LANG['domainsautorenewdisable'] = "Deaktiver auto fornyelse";
$_LANG['domainsautorenewdisabled'] = "Deaktiveret";
$_LANG['domainsautorenewdisabledwarning'] = "ADVARSEL! På dette domæne er auto fornyelse deaktiveret.<br />Det vil derfor blive inaktivt, når registreringsperioden på domænet udløber, medmindre du manuelt fornyer det.";
$_LANG['domainsautorenewenable'] = "Aktiver auto fornyelse";
$_LANG['domainsautorenewenabled'] = "Aktiveret";
$_LANG['domainsautorenewstatus'] = "Nuværende status";
$_LANG['domainsimplesearch'] = "Simple domæne søgning";
$_LANG['domainspricing'] = "Domæne pris";
$_LANG['domainsregister'] = "Registrer";
$_LANG['domainsrenew'] = "Forny";
$_LANG['domainsrenewnow'] = "Renew Now";
$_LANG['domainstatus'] = "Status";
$_LANG['domainstransfer'] = "Overfør";
$_LANG['domaintitle'] = "Domæne checker";
$_LANG['domaintld'] = "Domæne type";
$_LANG['domaintransfer'] = "Domæne flytning";
$_LANG['domainunavailable'] = "Optaget";
$_LANG['domainunavailable1'] = "Træls ting!";
$_LANG['domainunavailable2'] = "er allerede registreret!";
$_LANG['domainviewwhois'] = "se whois rapport";
$_LANG['downloaddescription'] = "Description";
$_LANG['downloadloginrequired'] = "Adgang nægtet! Du skal være logget ind før du kan downloade filen";
$_LANG['downloadname'] = "Download";
$_LANG['downloadpurchaserequired'] = "Adgang nægtet! Du skal bestille produktet før du kan downloade det";
$_LANG['downloadscategories'] = "Kategorier";
$_LANG['downloadsdescription'] = "Gennemse vores downloads bibliotek";
$_LANG['downloadsfiles'] = "Filer";
$_LANG['downloadsfilesize'] = "Fil størrelse";
$_LANG['downloadsintrotext'] = "I download biblioteket kan du finde manualer, programmer og andre filer, som kan være nyttige.";
$_LANG['downloadspopular'] = "Most Popular Downloads";
$_LANG['downloadsnone'] = "Ingen downloads";
$_LANG['downloadstitle'] = "Downloads";
$_LANG['email'] = "E-mail";
$_LANG['emptycart'] = "Tøm bestillingskurv";
$_LANG['existingpassword'] = "Eksisterende password";
$_LANG['existingpasswordincorrect'] = "Dit eksisterende password var ikke korrekt";
$_LANG['firstpaymentamount'] = "At betale idag";
$_LANG['flashtutorials'] = "Flash Tutorials";
$_LANG['flashtutorialsdescription'] = "Klik her for at se tutorials om hvordan du bruger dit hosting kontrolpanel";
$_LANG['flashtutorialsheadertext'] = "Vores flash tutorials er her for at hjælpe dig bruge dit webhosting kontrolpanel. Vælg tutorial nedenfor, for at se trin for trin guide.";
$_LANG['forwardingtogateway'] = "Vent venligst mens du bliver ført videre til vores betalingsside...";
$_LANG['globalsystemname'] = "Support";
$_LANG['globalyouarehere'] = "Du er her";
$_LANG['go'] = "Go";
$_LANG['headertext'] = "Velkommen til vores support.";
$_LANG['hometitle'] = "Forside";
$_LANG['imagecheck'] = "Indtast sikkerhedskoden vist på billedet - dette er påkrævet for at undgå spamming";
$_LANG['invoiceaddcreditamount'] = "Indtast beløb";
$_LANG['invoiceaddcreditapply'] = "Tilføj kredit";
$_LANG['invoiceaddcreditdesc1'] = "Din kreditbalance er";
$_LANG['invoiceaddcreditdesc2'] = "Kreditten kan blive tilføjet din faktura med nedenstående formular.";
$_LANG['invoiceaddcreditoverbalance'] = "Du kan ikke tilføje mere kredit end der er udestående";
$_LANG['invoiceaddcreditovercredit'] = "Du kan ikke tilføjere mere kredit end du har til rådighed på din konto";
$_LANG['invoicenumber'] = "faktura #";
$_LANG['invoiceofflinepaid'] = "Offline kredit kort betalinger bliver gennemført manuelt. Du vil modtage en bekræftelse når din betaling er gennemført.";
$_LANG['invoicerefnum'] = "Reference nr.";
$_LANG['invoices'] = "Mine faktura";
$_LANG['invoicesamount'] = "Beløb";
$_LANG['invoicesattn'] = "Att.";
$_LANG['invoicesbacktoclientarea'] = "<< Tilbage til kundeside";
$_LANG['invoicesbalance'] = "Balance";
$_LANG['invoicesbefore'] = "Før";
$_LANG['invoicescancelled'] = "Krediteret";
$_LANG['invoicescollections'] = "Collections";
$_LANG['invoicescredit'] = "kredit";
$_LANG['invoicesdatecreated'] = "Fakturadato";
$_LANG['invoicesdatedue'] = "Sidste betalingsdato";
$_LANG['invoicesdescription'] = "Beskrivelse";
$_LANG['invoicesdownload'] = "Download";
$_LANG['invoicesdue'] = "Faktura til betaling";
$_LANG['invoiceserror'] = "Der skete en fejl. Prøv venligst igen.";
$_LANG['invoicesinvoicedto'] = "Faktura til";
$_LANG['invoicesinvoicenotes'] = "Faktura bemærkning";
$_LANG['invoicesnoinvoices'] = "Ingen faktura";
$_LANG['invoicesnotes'] = "Bemærkninger";
$_LANG['invoicesoutstandinginvoices'] = "Udestående faktura";
$_LANG['invoicespaid'] = "Betalt";
$_LANG['invoicespaynow'] = "Betal nu";
$_LANG['invoicespayto'] = "Betaling til";
$_LANG['invoicesrefunded'] = "Refunderet";
$_LANG['invoicesstatus'] = "Status";
$_LANG['invoicessubtotal'] = "Sub Total";
$_LANG['invoicestax'] = "Moms 25%";
$_LANG['invoicestaxindicator'] = "Momspligtigt produkt.";
$_LANG['invoicestitle'] = "Faktura #";
$_LANG['invoicestotal'] = "Total";
$_LANG['invoicestransactions'] = "Transaktioner";
$_LANG['invoicestransamount'] = "Beløb";
$_LANG['invoicestransdate'] = "Transaktionsdato";
$_LANG['invoicestransgateway'] = "Betalingsmetode";
$_LANG['invoicestransid'] = "Transaktions ID";
$_LANG['invoicestransnonefound'] = "Ingen relaterede transaktioner fundet";
$_LANG['invoicesunpaid'] = "Ubetalt";
$_LANG['invoicesview'] = "Vis faktura";
$_LANG['jobtitle'] = "Job titel";
$_LANG['kbsuggestions'] = "Forslag fra vidensdatabasen";
$_LANG['kbsuggestionsexplanation'] = "Følgende artikler fra vidensdatabasen kan måske besvare dine spørgsmål. Venligst læs de viste forslag før kontakt.";
$_LANG['knowledgebasearticles'] = "Artikler";
$_LANG['knowledgebasecategories'] = "Kategorier";
$_LANG['knowledgebasedescription'] = "Gemmense vidensdatabasen for de oftest stillede spørgsmål";
$_LANG['knowledgebasefavorites'] = "Føj til favoritter";
$_LANG['knowledgebasehelpful'] = "Hjalp dette svar dig?";
$_LANG['knowledgebaseintrotext'] = "Vidensdatabasen er opdelt i kategorier. Du kan enten vælge en kategori nedenfor eller søge i vidensdatabasen efter dit spørgsmål.";
$_LANG['knowledgebasemore'] = "Mere";
$_LANG['knowledgebaseno'] = "Nej";
$_LANG['knowledgebasenoarticles'] = "Ingen artikler";
$_LANG['knowledgebasenorelated'] = "Der er ingen relaterede artikler";
$_LANG['knowledgebasepopular'] = "Mest populære";
$_LANG['knowledgebaseprint'] = "Print denne artikel";
$_LANG['knowledgebaserating'] = "Rating:";
$_LANG['knowledgebaseratingtext'] = "Kunder som kunne bruge dette svar";
$_LANG['knowledgebaserelated'] = "Relaterede artikler";
$_LANG['knowledgebasesearch'] = "Søg";
$_LANG['knowledgebasetitle'] = "Vidensdatabase";
$_LANG['knowledgebaseviews'] = "Visninger";
$_LANG['knowledgebasevote'] = "Stem";
$_LANG['knowledgebasevotes'] = "Stem";
$_LANG['knowledgebaseyes'] = "Ja";
$_LANG['language'] = "Sprog";
$_LANG['latefee'] = "Rykkergebyr";
$_LANG['latefeeadded'] = "Tilføjet";
$_LANG['latestannouncements'] = "Seneste nyheder";
$_LANG['loginbutton'] = "Login";
$_LANG['loginemail'] = "E-mail adresse";
$_LANG['loginforgotten'] = "Glemt dit password?";
$_LANG['loginforgotteninstructions'] = "Har du glemt dit password, kan du klikke her for at få tilsendt et nyt";
$_LANG['loginincorrect'] = "Login fejl. Prøv venligst igen.";
$_LANG['loginintrotext'] = "Du skal være logget ind for at se denne side.";
$_LANG['loginpassword'] = "Password";
$_LANG['loginrememberme'] = "Husk mig";
$_LANG['logoutcontinuetext'] = "Klik her for at fortsætte.";
$_LANG['logoutsuccessful'] = "Du er nu logget ud.";
$_LANG['logouttitle'] = "Log ud";
$_LANG['maxmind_anonproxy'] = "Vi tillader ikke bestillinger foretaget ved brug af anonym proxy";
$_LANG['maxmind_callingnow'] = "Vores system foretaget automatisk et opkald til din telefon nu. Dette er en del af vores anti bedrageri tjek. Du vil få oplæst en 4 cifret kode, som du skal indtaste nedenfor, for at gennemføre din ordre. Opkaldet er gratis.";
$_LANG['maxmind_countrymismatch'] = "Landet som din IP adresse hører til stemmer ikke overens med den indtastede adresse, så vi kan ikke gennemføre din bestilling";
$_LANG['maxmind_error'] = "Fejl";
$_LANG['maxmind_faileddescription'] = "Koden du indtastede er forkert. Hvis du mener dette er en fejl, kontakt venligst vores support hurtigst muligt.";
$_LANG['maxmind_highfraudriskscore'] = "Vores system har opfanget en stor risiko for bedrageri på din bestilling og har derfor blokeret den";
$_LANG['maxmind_highriskcountry'] = "Vi tillader ikke bestillinger fra dit land";
$_LANG['maxmind_incorrectcode'] = "Forkert pinkode";
$_LANG['maxmind_pincode'] = "Pinkode";
$_LANG['maxmind_rejectemail'] = "Vi accepterer ikke ordre fra gratis e-maill adresser, prøv venligst igen med en anden e-mail adresse";
$_LANG['maxmind_title'] = "MaxMind";
$_LANG['more'] = "Mere";
$_LANG['morechoices'] = "Flere muligheder";
$_LANG['networkissuesaffecting'] = "Påvirker";
$_LANG['networkissuesaffectingyourservers'] = "Bemærk: Problemer som vedrører den server som din konto er tilknyttet vil være markeret med en gylden background";
$_LANG['networkissuesdate'] = "Dato";
$_LANG['networkissuesdescription'] = "Læs mere om nuværende og planlagte netværks udfald";
$_LANG['networkissueslastupdated'] = "Senest opdateret";
$_LANG['networkissuesnonefound'] = "Der er ingen kendte driftproblemer";
$_LANG['networkissuespriority'] = "Prioritet";
$_LANG['networkissuesprioritycritical'] = "Kritisk";
$_LANG['networkissuespriorityhigh'] = "Høj";
$_LANG['networkissuesprioritylow'] = "Lav";
$_LANG['networkissuesprioritymedium'] = "Medium";
$_LANG['networkissuesstatusinprogress'] = "I gang";
$_LANG['networkissuesstatusinvestigating'] = "Vi undersøger";
$_LANG['networkissuesstatusopen'] = "Åben";
$_LANG['networkissuesstatusoutage'] = "Outage";
$_LANG['networkissuesstatusreported'] = "Rapporteret";
$_LANG['networkissuesstatusresolved'] = "Løst";
$_LANG['networkissuesstatusscheduled'] = "Planlagt";
$_LANG['networkissuestitle'] = "Networks problemer";
$_LANG['networkissuestypeother'] = "Andre";
$_LANG['networkissuestypeserver'] = "Server";
$_LANG['networkissuestypesystem'] = "System";
$_LANG['newpassword'] = "Nyt password";
$_LANG['nextpage'] = "Næste side";
$_LANG['no'] = "Nej";
$_LANG['nocarddetails'] = "Du har ingen eksisterende kort informationer gemt";
$_LANG['none'] = "Ingen";
$_LANG['norecordsfound'] = "Ingen records fundet";
$_LANG['or'] = "eller";
$_LANG['orderadditionalrequiredinfo'] = "yderligere information er påkrævet";
$_LANG['orderaddon'] = "Addon";
$_LANG['orderaddondescription'] = "De følgende addons er tilgængelige for dette produkt. Vælg venligst de addons du ønsker at bestille.";
$_LANG['orderavailable'] = "Tilgængelig";
$_LANG['orderavailableaddons'] = "Klik her for at se tilgængelige addons";
$_LANG['orderbillingcycle'] = "Betalingsperiode";
$_LANG['ordercategories'] = "Kategorier";
$_LANG['orderchangeaddons'] = "Skift Addons";
$_LANG['orderchangeconfig'] = "Skift mulige tilvalg";
$_LANG['orderchangedomain'] = "Skift domæne";
$_LANG['orderchangenameservers'] = "Skift kun navneservere";
$_LANG['orderchangeproduct'] = "Skift produkt";
$_LANG['ordercheckout'] = "Checkout";
$_LANG['orderchooseaddons'] = "Vælg produkt addons";
$_LANG['orderchooseapackage'] = "Produkt";
$_LANG['ordercodenotfound'] = "Rabat koden du indtastede findes ikke";
$_LANG['ordercompletebutnotpaid'] = "Attention! Din bestilling er fuldført, men du har ikke betalt endnu. Din bestilling vil blive udført når betalingen er modtaget.<br />Klik på linket nedenfor, for at gå til din faktura for at betale.";
$_LANG['orderconfigpackage'] = "Valgmuligheder";
$_LANG['orderconfigure'] = "Konfigurer";
$_LANG['orderconfirmation'] = "Ordre bekræftelse";
$_LANG['orderconfirmorder'] = "Bekræft bestilling";
$_LANG['ordercontinuebutton'] = "Klik for at fortsætte >>";
$_LANG['orderdesc'] = "Beskrivelse";
$_LANG['orderdescription'] = "Place a new order with us";
$_LANG['orderdiscount'] = "Rabat";
$_LANG['orderdomain'] = "Domæne";
$_LANG['orderdomainoption1part1'] = "Jeg ønsker at";
$_LANG['orderdomainoption1part2'] = "registerer et nyt domæne for mig.";
$_LANG['orderdomainoption2'] = "Jeg vil selv opdatere mine navneservere på et eksisterende domæne.";
$_LANG['orderdomainoption3'] = "Jeg vil flytte mit domæne til";
$_LANG['orderdomainoption4'] = "Jeg vil bruge et gratis sub-domæne.";
$_LANG['orderdomainoptions'] = "Domæne";
$_LANG['orderdomainregistration'] = "Domæne registrering";
$_LANG['orderdomainregonly'] = "Bestil kun domæne registrering";
$_LANG['orderdomaintransfer'] = "Domæne flytning";
$_LANG['orderdontusepromo'] = "Brug ikke rabat kode";
$_LANG['ordererroraccepttos'] = "Du skal acceptere vores betingelser";
$_LANG['ordererrordomainalreadyexists'] = "The domain you entered is already registered with us - you will need to cancel it prior to placing a new order";
$_LANG['ordererrordomaininvalid'] = "Domænet du indtastede er ikke gyldigt";
$_LANG['ordererrordomainnotld'] = "Du skal vælge en gyldig domæne type";
$_LANG['ordererrordomainnotregistered'] = "Du kan ikke flytte et domæne, som ikke er registreret";
$_LANG['ordererrordomainregistered'] = "Domænet du indtastede er allerede registreret";
$_LANG['ordererrornameserver1'] = "Du skal indtaste navneserver 1";
$_LANG['ordererrornameserver2'] = "Du skal indtaste navneserver 2";
$_LANG['ordererrornodomain'] = "Du skal indtaste et domænenavn";
$_LANG['ordererrorpassword'] = "Du skal indtaste et password";
$_LANG['ordererrorserverhostnameinuse'] = "The hostname you entered is already in use. Please choose another.";
$_LANG['ordererrorservernohostname'] = "Du skal indtaste et hostnavn for din server";
$_LANG['ordererrorservernonameservers'] = "Du skal indtaste et prefix for begge navneservere";
$_LANG['ordererrorservernorootpw'] = "Du skal indtaste et root password";
$_LANG['ordererrorsubdomaintaken'] = "Sub-domænet du indtastede er allerede i brug. Prøv venligst igen.";
$_LANG['ordererrortransfersecret'] = "Du skal indtaste en overflytningskode";
$_LANG['ordererroruserexists'] = "Den indtastede e-mail adresse er allerede registreret";
$_LANG['orderexistinguser'] = "Jeg er allerede kunde og ønsker at tilføje denne ordre til min konto";
$_LANG['orderfailed'] = "Din ordre blev ikke gemmenført";
$_LANG['orderfinalinstructions'] = "Hvis du har spørgsmål vedrørende din ordre, kan du oprette en support ticket direkte fra din kundeside. Husk at påføre dit ordrenummer.";
$_LANG['orderfree'] = "GRATIS!";
$_LANG['orderfreedomainappliesto'] = "kan benyttes på de følgende domæne typer";
$_LANG['orderfreedomaindescription'] = "på den valgte betalingsperiode";
$_LANG['orderfreedomainonly'] = "Gratis domæne";
$_LANG['orderfreedomainregistration'] = "Gratis domæne registrering";
$_LANG['ordergotoclientarea'] = "Klik her for at gå til din kundeside";
$_LANG['orderinvalidcodeforbillingcycle'] = "Denne kode kan ikke bruges sammen med den valgte betalingsperiode";
$_LANG['orderlogininfo'] = "Login information";
$_LANG['orderlogininfopart1'] = "Indtast det password du ønsker at bruge til at logge ind på din";
$_LANG['orderlogininfopart2'] = "kundeside. Dette vil ikke være det samme som brugernavn &amp; password til dit webhosting kontrolpanel.";
$_LANG['ordernewuser'] = "Jeg er ny kunde og ønsker at oprette en konto";
$_LANG['ordernoproducts'] = "Ingen produkter fundet";
$_LANG['ordernotes'] = "Bemækrninger / yderligere information";
$_LANG['ordernotesdescription'] = "Du kan indtaste yderligere informationer til din bestilling her...";
$_LANG['ordernowbutton'] = "Bestil nu";
$_LANG['ordernumberis'] = "Dit ordrenummer er:";
$_LANG['orderpaymentmethod'] = "Betalingsmetode";
$_LANG['orderpaymentterm12month'] = "12 måneders pris";
$_LANG['orderpaymentterm1month'] = "1 måneds pris";
$_LANG['orderpaymentterm24month'] = "24 måneders pris";
$_LANG['orderpaymentterm3month'] = "3 måneders pris";
$_LANG['orderpaymentterm6month'] = "6 måneders pris";
$_LANG['orderpaymenttermannually'] = "Årlig";
$_LANG['orderpaymenttermbiennially'] = "2 årlig";
$_LANG['orderpaymenttermfreeaccount'] = "Gratis konto";
$_LANG['orderpaymenttermmonthly'] = "Månedlig";
$_LANG['orderpaymenttermonetime'] = "En gang";
$_LANG['orderpaymenttermquarterly'] = "Kvartalsvis";
$_LANG['orderpaymenttermsemiannually'] = "Halvårlig";
$_LANG['orderprice'] = "Pris";
$_LANG['orderproduct'] = "Produkt/service";
$_LANG['orderprogress'] = "Fremad";
$_LANG['orderpromoexpired'] = "Rabat koden du indtastede er udløbet";
$_LANG['orderpromoinvalid'] = "Rabat koden du indtastede kan ikke benyttes sammen med de produkter du ønsker at bestille";
$_LANG['orderpromomaxusesreached'] = "Rabat koden du indtastede er allerede brugt";
$_LANG['orderpromotioncode'] = "Rabat kode";
$_LANG['orderpromovalidatebutton'] = "Valider kode >>";
$_LANG['orderprorata'] = "Pro Rata";
$_LANG['orderreceived'] = "Tak for din ordre. Du vil om et kort øjeblik modtage en e-mail.";
$_LANG['orderregisterdomain'] = "Registrer et nyt domæne";
$_LANG['orderregperiod'] = "Registreringsperiode";
$_LANG['ordersecure'] = "Denne bestilling er sendt via sikker krypteret SSL forbindelse. Din IP adresse:";
$_LANG['ordersecure2'] = "er blevet logget.";
$_LANG['orderserverhostname'] = "Server hostnavn";
$_LANG['orderservernameservers'] = "Navneservere";
$_LANG['orderservernameserversdescription'] = "De prefix du indtaster her vil blive primær navneserver for serveren. F.eks. ns1.yourdomain.com and ns2.yourdomain.com";
$_LANG['orderservernameserversprefix1'] = "Prefix 1";
$_LANG['orderservernameserversprefix2'] = "Prefix 2";
$_LANG['orderserverrootpassword'] = "Root Password";
$_LANG['ordersetupfee'] = "Oprettelse";
$_LANG['orderstartover'] = "Start forfra";
$_LANG['ordersubdomaininuse'] = "Sub-domænet er allerede i brug";
$_LANG['ordersubtotal'] = "Subtotal";
$_LANG['ordersummary'] = "Ordre Opsummering";
$_LANG['ordertaxcalculations'] = "Moms beregning";
$_LANG['ordertaxstaterequired'] = "Du skal indtaste dit land for at beregne moms";
$_LANG['ordertitle'] = "Bestilling";
$_LANG['ordertos'] = "betingelserne";
$_LANG['ordertosagreement'] = "Jeg har læst og accepterer";
$_LANG['ordertotalduetoday'] = "Til betaling idag";
$_LANG['ordertotalrecurring'] = "Fremtidig betaling";
$_LANG['ordertransferdomain'] = "Flyt et eksisterende domæne";
$_LANG['ordertransfersecret'] = "Overførselskode";
$_LANG['ordertransfersecretexplanation'] = "Indtast venligst overførselskoden. Koden kan oplyses af den nuværende registrator af domænet. ";
$_LANG['orderusesubdomain'] = "Brug sub-domæne";
$_LANG['orderyears'] = "år";
$_LANG['orderyourinformation'] = "Dine informationer";
$_LANG['orderyourorder'] = "Din ordre";
$_LANG['organizationname'] = "Organisations navn";
$_LANG['outofstock'] = "Ikke på lager";
$_LANG['outofstockdescription'] = "Vi har desværre ikke dette produkt på lager i øjeblikket. For mere information, kontakt os.";
$_LANG['page'] = "Side";
$_LANG['pageof'] = "af";
$_LANG['please'] = "Venligst";
$_LANG['pleasewait'] = "Vent venligst...";
$_LANG['presalescontactdescription'] = "Har du spørgsmål før du bestiller kan du stille dem her";
$_LANG['previouspage'] = "Forrige side";
$_LANG['proformainvoicenumber'] = "Proforma faktura #";
$_LANG['promoexistingclient'] = "For at benytte denne kode skal du have aktive produkter/services";
$_LANG['promoonceperclient'] = "Denne kode kan kun benyttes een gang per kunde";
$_LANG['pwstrengthfail'] = "Det indtastede password er ikke sikkert nok, indtast venligst et nyt og sværere password";
$_LANG['quicknav'] = "Kvik navigation";
$_LANG['recordsfound'] = "Records fundet";
$_LANG['recurring'] = "Gentagende";
$_LANG['recurringamount'] = "Abonnement";
$_LANG['every'] = "Every";
$_LANG['registerdomain'] = "Registrer domæne";
$_LANG['registerdomaindesc'] = "Indtast domæne for at tjekke om domænet er ledigt.";
$_LANG['registerdomainname'] = "Registrer et nyt domæne";
$_LANG['relatedservice'] = "Relaterede Services";
$_LANG['rssfeed'] = "Feed";
$_LANG['securityanswerrequired'] = "Du skal indtaste svaret på sikkerheds spørgsmålet";
$_LANG['securitybothnotmatch'] = "De indtastede svar er ikke ens, prøv igen";
$_LANG['securitycurrentincorrect'] = "Dit spørgsmål og svar er ikke korrekte";
$_LANG['serverchangepassword'] = "Skift password";
$_LANG['serverchangepasswordintro'] = "From here you can change the password of the product/service (note: this does not affect your password for our client area)";
$_LANG['serverchangepasswordconfirm'] = "Bekræft password";
$_LANG['serverchangepasswordenter'] = "Indtast nyt password";
$_LANG['serverchangepasswordfailed'] = "Password blev ikke skiftet!";
$_LANG['serverchangepasswordsuccessful'] = "Password skiftet!";
$_LANG['serverchangepasswordupdate'] = "Opdater";
$_LANG['serverhostname'] = "Hostnavn";
$_LANG['serverlogindetails'] = "Login detaljer";
$_LANG['servername'] = "Server";
$_LANG['serverns1prefix'] = "NS1 prefix";
$_LANG['serverns2prefix'] = "NS2 prefix";
$_LANG['serverpassword'] = "Password";
$_LANG['serverrootpw'] = "Root password";
$_LANG['serverstatusdescription'] = "Se status på vores servere";
$_LANG['serverstatusnoservers'] = "Der er ingen servere under overvågning";
$_LANG['serverstatusnotavailable'] = "Ikke tilgængelig";
$_LANG['serverstatusoffline'] = "Offline";
$_LANG['serverstatusonline'] = "Online";
$_LANG['serverstatusphpinfo'] = "PHP Info";
$_LANG['serverstatusserverload'] = "Server Load";
$_LANG['serverstatustitle'] = "Server status";
$_LANG['serverstatusuptime'] = "Oppetid";
$_LANG['serverusername'] = "Brugernavn";
$_LANG['show'] = "Vis";
$_LANG['ssladmininfo'] = "Administrativ kontakt information";
$_LANG['ssladmininfodetails'] = "Kontakt informationen nedenfor vil ikke blive vist på certificatet. Det vil kun blive brugt til at kontakte dig vedr. din ordre. SSL certifikatets fremtidige fornyelses påmindelser vil blive sendt til e-mail adressen nedenfor.";
$_LANG['sslcertapproveremail'] = "Certifikat validerings e-mail";
$_LANG['sslcertapproveremaildetails'] = "Du skal vælge nedenfor hvilken e-mail adresse du ønsker validerings e-mailen til dette certifikat sendt til.";
$_LANG['sslcertinfo'] = "SSL certifikat information";
$_LANG['pleasechooseone'] = "Please choose one...";
$_LANG['sslcerttype'] = "Certifikat type";
$_LANG['sslconfigcomplete'] = "Konfiguration fuldført";
$_LANG['sslconfigcompletedetails'] = "SSL certifikat konfigurationen er nu fuldført og sendt til certifikat udbyderen til validation. Du vil modtage en e-mail fra dem snarest muligt.";
$_LANG['sslconfsslcertificate'] = "Konfigurer SSL certifikat";
$_LANG['sslcsr'] = "CSR";
$_LANG['sslerrorapproveremail'] = "Du skal vælge en validerings e-mail adresse";
$_LANG['sslerrorentercsr'] = "Du skal indtaste dit certificate signing request (CSR)";
$_LANG['sslerrorselectserver'] = "Du skal vælge din server type";
$_LANG['sslinvalidlink'] = "Ugyldigt link.";
$_LANG['sslorderdate'] = "Ordre dato";
$_LANG['sslserverinfo'] = "Server information";
$_LANG['sslserverinfodetails'] = "Du skal have et gyldigt \"CSR\" (Certificate Signing Request) for at konfigurere dit SSL certifikat. CSR er en krypteret text, som er genereret af webserveren hvor SSL certifikat skal installeres. Hvis du ikke har et CSR, skal du generere et eller spørge din webhosting udbyder om dette. Det er vigtigt, at du instaster al information korrekt, da det ikke kan ændres efter SSL certifikatet er blevet godkendt.";
$_LANG['sslservertype'] = "Webserver type";
$_LANG['sslstatus'] = "Konfigurations status";
$_LANG['statscreditbalance'] = "Konto kredit balance";
$_LANG['statsdueinvoicesbalance'] = "OVerskredet faktura balance";
$_LANG['statsnumdomains'] = "Antal domæner";
$_LANG['statsnumproducts'] = "Antal produkter/services";
$_LANG['statsnumreferredsignups'] = "Antal henviste bestillinger";
$_LANG['statsnumtickets'] = "Antal support tickets";
$_LANG['submitticketdescription'] = "Opret en support ticket";
$_LANG['supportclickheretocontact'] = "klik her for at kontakte os";
$_LANG['supportpresalesquestions'] = "Hvis du har spørgsmål før du bestiller - ";
$_LANG['supportticketinvalid'] = "En fejl er sket. Den forespurgte ticket blev ikke fundet.";
$_LANG['supportticketsallowedextensions'] = "Tilladte filtyper";
$_LANG['supportticketschoosedepartment'] = "vælg afdeling";
$_LANG['supportticketsclient'] = "Kunde";
$_LANG['supportticketsclientemail'] = "E-mail adresse";
$_LANG['supportticketsclientname'] = "Navn";
$_LANG['supportticketsdate'] = "Dato";
$_LANG['supportticketsdepartment'] = "Afdeling";
$_LANG['supportticketsdescription'] = "Vis og besvar eksisterende tickets";
$_LANG['supportticketserror'] = "Fejl";
$_LANG['supportticketserrornoemail'] = "Du indtastede ikke din e-mail adresse";
$_LANG['supportticketserrornomessage'] = "Du indtastede ikke en besked";
$_LANG['supportticketserrornoname'] = "Du indtastede ikke dit navn";
$_LANG['supportticketserrornosubject'] = "Du indtastede ikke et emne";
$_LANG['supportticketsfilenotallowed'] = "Filen du prøver på at uploade er ikke tilladt.";
$_LANG['supportticketsheader'] = "Hvis du ikke kan finde et svar på dine spørgsmål i vores vidensdatabase kan du oprette en support ticket ved at vælge support afdeling nedenfor.";
$_LANG['supportticketsnotfound'] = "Ticket ikke fundet";
$_LANG['supportticketsopentickets'] = "Åbne support tickets";
$_LANG['supportticketspagetitle'] = "Support tickets";
$_LANG['supportticketsposted'] = "Oprettet den";
$_LANG['supportticketsreply'] = "Besvar";
$_LANG['supportticketsstaff'] = "Supporter";
$_LANG['supportticketsstatus'] = "Status";
$_LANG['supportticketsstatusanswered'] = "Besvaret";
$_LANG['supportticketsstatusclosed'] = "Lukket";
$_LANG['supportticketsstatuscloseticket'] = "Luk ticket";
$_LANG['supportticketsstatuscustomerreply'] = "Kunde-svar";
$_LANG['supportticketsstatusinprogress'] = "I gang";
$_LANG['supportticketsstatusonhold'] = "På hold";
$_LANG['supportticketsstatusopen'] = "Åben";
$_LANG['supportticketssubject'] = "Emne";
$_LANG['supportticketssubmitticket'] = "Opret ticket";
$_LANG['supportticketssystemdescription'] = "Support ticket systemet giver os adgang til at besvare dine spørgsmål hurtigt. Når vi besvarer din support ticket vil du modtage en e-mail.";
$_LANG['supportticketsticketattachments'] = "Attachments";
$_LANG['supportticketsticketcreated'] = "Support ticket oprettet";
$_LANG['supportticketsticketcreateddesc'] = "Din support ticket blev oprettet. Der er sendt en e-mail til din e-mail adresse med ticket information.";
$_LANG['supportticketsticketid'] = "Ticket ID";
$_LANG['supportticketsticketsubject'] = "Emne";
$_LANG['supportticketsticketsubmit'] = "Opret";
$_LANG['supportticketsticketurgency'] = "vigtighed";
$_LANG['supportticketsticketurgencyhigh'] = "Høj";
$_LANG['supportticketsticketurgencylow'] = "Lav";
$_LANG['supportticketsticketurgencymedium'] = "Medium";
$_LANG['supportticketsuploadfailed'] = "Kunne ikke uploade filen";
$_LANG['supportticketsviewticket'] = "Vis support ticket";
$_LANG['telesignincorrectpin'] = "Forkert pin!";
$_LANG['telesigninitiatephone'] = "Vi kan ikke starte telefon validering på dit nummer. Kontakt os venligst.";
$_LANG['telesigninvalidnumber'] = "Ugyldigt telefonnummer";
$_LANG['telesigninvalidpin'] = "Den indtastede PIN er ugyldig!";
$_LANG['telesigninvalidpin2'] = "Den indtastede pin er ikke gyldig.";
$_LANG['telesigninvalidpinmessage'] = "Pinkode validering fejlede";
$_LANG['telesignmessage'] = "Telefon validering er nu startet på telefonnummer %s . Vent et øjeblik...";
$_LANG['telesignphonecall'] = "Telefonopkald";
$_LANG['telesignpin'] = "Indtast din pin: ";
$_LANG['telesignsms'] = "Sms";
$_LANG['telesignsmstextmessage'] = "Tak fordi du benyttede dig af vores SMS valideringssystem. Din kode er: %s Indtast koden på din computer nu.!";
$_LANG['telesigntitle'] = "TeleSign telefon validering.";
$_LANG['telesigntype'] = "Vælg validerings type for telefonnummer %s:";
$_LANG['telesignverificationcanceled'] = "Der er opstået et midlertidigt problem med telefon validerings systemet og valideringen er blevet afbrudt.";
$_LANG['telesignverificationproblem'] = "Der opstod et problem med telefon valideringen og din bestilling kunne ikke valideres. Prøv venligst igen senere.";
$_LANG['telesignverify'] = "Det er nødvendigt at validere telefonnummer %s for at gennemføre denne bestilling.";
$_LANG['ticketratingexcellent'] = "Perfekt";
$_LANG['ticketratingpoor'] = "Skidt";
$_LANG['ticketratingquestion'] = "Hvordan synes du dette svar var?";
$_LANG['ticketreatinggiven'] = "Du har rated dette svar";
$_LANG['transferdomain'] = "Flyt domæne";
$_LANG['transferdomaindesc'] = "Vil du flytte dit domæne til os skal du indtaste domænet nedenfor.";
$_LANG['transferdomainname'] = "Flyt et domæne";
$_LANG['updatecart'] = "Opdater bestillingskurv";
$_LANG['upgradechooseconfigoptions'] = "Opgrader/nedgrader valgfrie tilpasninger for dette produkt.";
$_LANG['upgradechoosepackage'] = "Vælg pakke du ønsker at opgradere/nedgradere til.";
$_LANG['upgradecurrentconfig'] = "Nuværende tilpasning";
$_LANG['upgradedowngradeconfigoptions'] = "Opgrader/nedgrader tilpasning";
$_LANG['upgradenewconfig'] = "Ny tilpasning";
$_LANG['upgradenochange'] = "Ingen ændringer";
$_LANG['upgradeproductlogic'] = "Upgrade price is calculated from a credit of the unused portion of the current plan and billing of the new plan for the same period";
$_LANG['upgradesummary'] = "Nedenfor er en opsummering af din opgradering.";
$_LANG['usedefaultcontact'] = "Brug standard kontakt (detaljer ovenfor)";
$_LANG['varilogixfraudcall_callnow'] = "Foretag opkald nu!";
$_LANG['varilogixfraudcall_description'] = "Som en del af vores anti bedrageri tjek, vil vores system nu automatisk foretage et opkald til det telefonnummer du indtastede. Du skal indtaste pinkoden som er vist ovenfor. Skriv koden ned. Når du er klar til at modtage opkaldet tast knapen nedenfor.";
$_LANG['varilogixfraudcall_error'] = "Der skete en fejl da systemet forsøgte at lave et opkald til dig for at verificere din ordre. Kontakt venligst supporten for at gennemføre din bestilling.";
$_LANG['varilogixfraudcall_fail'] = "Opkaldet for at verificere din ordre fejlede. Dette kan være fordi du har indtastet et forkert telefonnummer. Kontakt venligst supporten for at gennemføre din bestilling.";
$_LANG['varilogixfraudcall_failed'] = "Fejl";
$_LANG['varilogixfraudcall_pincode'] = "Pinkode";
$_LANG['varilogixfraudcall_title'] = "VariLogix FraudCall";
$_LANG['viewcart'] = "Vis bestillingskurv";
$_LANG['welcomeback'] = "Velkommen tilbage";
$_LANG['whoisresults'] = "WHOIS resultater for";
$_LANG['yes'] = "Ja";
$_LANG['yourdetails'] = "Dine detaljer";

# Version 4.1

$_LANG['clientareafiles'] = "Attached Files";
$_LANG['clientareafilesdate'] = "Date Added";
$_LANG['clientareafilesfilename'] = "Filename";

$_LANG['pwreset'] = "Lost Password Reset";
$_LANG['pwresetdesc'] = "If you have forgotten your password, you can reset it here. When you fill in your registered email address (and answer your account security question if set), you will be sent instructions on how to reset your password.";
$_LANG['pwresetemailrequired'] = "You didn't enter your email address";
$_LANG['pwresetemailnotfound'] = "No client account was found with the email address you entered";
$_LANG['pwresetsecurityquestionrequired'] = "As you have a security question setup on your account, you must enter the answer to this question below.";
$_LANG['pwresetsecurityquestionincorrect'] = "The security question answer you entered does not match the answer set in your account";
$_LANG['pwresetsubmit'] = "Submit";
$_LANG['pwresetvalidationsent'] = "Validation Email Sent";
$_LANG['pwresetvalidationcheckemail'] = "The password reset process has now been started. Please check your email for instructions on what to do next.";
$_LANG['pwresetkeyinvalid'] = "The reset link you have followed is invalid. Please try again.";
$_LANG['pwresetkeyexpired'] = "The reset link you have followed has expired. Please try again.";
$_LANG['pwresetvalidationsuccess'] = "Password Reset Successful";

$_LANG['overagescharges'] = "Overage Charge";
$_LANG['overagestotaldiskusage'] = "Total Disk Usage";
$_LANG['overagestotalbwusage'] = "Total Bandwidth Usage";

$_LANG['affiliatescommissionspending'] = "Commissions Pending Maturation";
$_LANG['affiliatescommissionsavailable'] = "Available Commissions Balance";
$_LANG['affiliatessignups'] = "Number of Signups";
$_LANG['affiliatesconversionrate'] = "Conversion Rate";

$_LANG['configoptionqtyminmax'] = "%s has a minimum requirement of %s and maximum of %s";

$_LANG['creditcardnostore'] = "Tick this box if you do NOT want us to store your credit card details for recurring billing";
$_LANG['creditcarddelete'] = "Delete Saved Card Details";
$_LANG['creditcarddeleteconfirmation'] = "The stored credit card details have now been removed from your account";
$_LANG['creditcardupdatenotpossible'] = "Credit Card Details cannot be updated at the current time. Please try again later.";

$_LANG['invoicepaymentsuccessconfirmation'] = "Thank You! Your payment was successful.";
$_LANG['invoicepaymentfailedconfirmation'] = "Unfortunately your payment attempt was not successful.<br />Please try again or contact support.";

# Version 4.2

$_LANG['promoappliedbutnodiscount'] = "The promotion code you entered has been applied to your cart but no items qualify for the discount yet - please check the promotion terms";

$_LANG['upgradeerroroverdueinvoice'] = "You cannot currently upgrade or downgrade this product because an invoice has already been generated for the next renewal.<br /><br />To proceed, please first pay the outstanding invoice and then you will be able to upgrade or downgrade immediately following that and be charged the difference or credited as appropriate.";

$_LANG['subaccountactivate'] = "Activate Sub-Account";
$_LANG['subaccountactivatedesc'] = "Tick to configure as a sub-account with client area access";
$_LANG['subaccountpermissions'] = "Sub-Account Permissions";
$_LANG['subaccountpermsprofile'] = "Modify Master Account Profile";
$_LANG['subaccountpermscontacts'] = "View & Manage Contacts";
$_LANG['subaccountpermsproducts'] = "View Products & Services";
$_LANG['subaccountpermsmanageproducts'] = "View & Modify Product Passwords";
$_LANG['subaccountpermsdomains'] = "View Domains";
$_LANG['subaccountpermsmanagedomains'] = "Manage Domain Settings";
$_LANG['subaccountpermsinvoices'] = "View & Pay Invoices";
$_LANG['subaccountpermstickets'] = "View & Open Support Tickets";
$_LANG['subaccountpermsaffiliates'] = "View & Manage Affiliate Account";
$_LANG['subaccountpermsemails'] = "View Emails";
$_LANG['subaccountpermsorders'] = "Place New Orders/Upgrades/Cancellations";
$_LANG['subaccountpermissiondenied'] = "You do not have the required permissions to access this page";
$_LANG['subaccountallowedperms'] = "Your allowed permissions are:";
$_LANG['subaccountcontactmaster'] = "Contact the master account owner if you feel this to be an error.";

$_LANG['knowledgebasealsoread'] = "Also Read";

$_LANG['orderpaymenttermtriennially'] = "Triennially";
$_LANG['orderpaymentterm36month'] = "36 Month Price";

$_LANG['domainrenewals'] = "Domain Renewals";
$_LANG['domaindaysuntilexpiry'] = "Days Until Expiry";
$_LANG['domainrenewalsnoneavailable'] = "There are no domains elligible for renewal in your account";
$_LANG['domainrenewalspastgraceperiod'] = "Past Renewable Period";
$_LANG['domainrenewalsingraceperiod'] = "Last Chance to Renew!";
$_LANG['domainrenewalsdays'] = "Days";
$_LANG['domainrenewalsdaysago'] = "Days Ago";

$_LANG['invoicespartialpayments'] = "Partial Payments";
$_LANG['invoicestotaldue'] = "Total Due";

$_LANG['masspaytitle'] = "Mass Payment";
$_LANG['masspaydescription'] = "Below is a summary of the selected invoices and the total due to pay all of them. To submit payment please just choose your desired payment method below and then submit.";
$_LANG['masspayselected'] = "Pay Selected";
$_LANG['masspayall'] = "Pay All";
$_LANG['masspaymakepayment'] = "Make Payment";

# Version 4.3

$_LANG['searchenterdomain'] = "Enter Domain to Find";
$_LANG['searchfilter'] = "Filter";

$_LANG['suspendreason'] = "Suspension Reason";
$_LANG['suspendreasonoverdue'] = "Overdue on Payment";

$_LANG['vpsnetmanagement'] = "VPS Management";
$_LANG['vpsnetpowermanagement'] = "Power Management";
$_LANG['poweron'] = "Power On";
$_LANG['poweroffforced'] = "Power Off (Forced)";
$_LANG['powerreboot'] = "Reboot";
$_LANG['powershutdown'] = "Shutdown";
$_LANG['vpsnetcpugraphs'] = "CPU Graphs";
$_LANG['vpsnetnetworkgraphs'] = "Network Graphs";
$_LANG['vpsnethourly'] = "Hourly";
$_LANG['vpsnetdaily'] = "Daily";
$_LANG['vpsnetweekly'] = "Weekly";
$_LANG['vpsnetmonthly'] = "Monthly";
$_LANG['view'] = "View";
$_LANG['vpsnetbackups'] = "Backup Options";
$_LANG['vpsnetgenbackup'] = "Generate Backup";
$_LANG['vpsnetrestorebackup'] = "Restore Backup";
$_LANG['vpsnetrestorebackupwarning'] = "Restoring the backup will over write your VPS server";
$_LANG['vpsnetnobackups'] = "There are no backups";
$_LANG['vpsnetrunning'] = "Running";
$_LANG['vpsnetnotrunning'] = "Not Running";
$_LANG['vpsnetpowercycling'] = "Power is cycling";
$_LANG['vpsnetcloud'] = "Cloud";
$_LANG['vpsnettemplate'] = "Template";
$_LANG['vpsnetstatus'] = "System Status";
$_LANG['vpsnetbwusage'] = "Bandwidth Usage";

$_LANG['twitterlatesttweets'] = "Our Latest Tweets";
$_LANG['twitterfollow'] = "Follow Us on Twitter";
$_LANG['twitterfollowus'] = "Follow us";
$_LANG['twitterfollowuswhy'] = "to stay up to date with our latest news &amp; offers";

$_LANG['chatlivehelp'] = "Live Help";

$_LANG['domainrelease'] = "Release Domain";
$_LANG['domainreleasedescription'] = "Enter a new TAG here to move your domain name to another registrar";
$_LANG['domainreleasetag'] = "New Registrar Tag";

# Ajax Order Form

$_LANG['orderformtitle'] = "Order Form";

$_LANG['signup'] = "Signup";
$_LANG['loading'] = "Loading...";

$_LANG['ordersummarybegin'] = "Shopping Cart is Empty<br/>Please choose a product to begin...";

$_LANG['cartchooseproduct'] = "Choose Product";
$_LANG['cartconfigurationoptions'] = "Configuration Options";

$_LANG['ordererrorsoccurred'] = "The following errors occurred and must be corrected before checkout:";
$_LANG['ordererrortermsofservice'] = "The Terms of Service must be agreed to";
$_LANG['ordertostickconfirm'] = "Please tick to confirm you agree to the";

$_LANG['cartnewcustomer'] = "I'm a New Customer";
$_LANG['cartexistingcustomer'] = "I'm an Existing Customer";

$_LANG['cartpromo'] = "Promotion";
$_LANG['cartenterpromo'] = "Enter Promotion Code";
$_LANG['cartremovepromo'] = "Remove Promo";

$_LANG['cartrecurringcharges'] = "Recurring Charges";

$_LANG['cartenterdomain'] = "Please enter the domain you would like to use below.";

$_LANG['cartdomainavailableoptions'] = "Congratulations, this domain is available!";
$_LANG['cartdomainavailableregister'] = "Please register this domain for";
$_LANG['cartdomainavailablemanual'] = "I will register it myself seperately";

$_LANG['cartdomainunavailableoptions'] = "Sorry, this domain is already taken. If you are the owner, please choose an option below...";
$_LANG['cartdomainunavailabletransfer'] = "Please transfer my domain for";
$_LANG['cartdomainunavailablemanual'] = "I already own this domain and will update the nameservers";

$_LANG['cartdomaininvalid'] = "The domain you entered is not valid. Enter only the part after the www. and include the TLD";

# Version 4.4

$_LANG['dlinvalidlink'] = "Invalid Link Followed. Please Contact Support";

$_LANG['domaindnsmanagementlaunch'] = "Launch DNS Manager";
$_LANG['domainemailforwardinglaunch'] = "Launch Mail Forwarding Manager";

# Version 4.5

$_LANG['domaindnspriority'] = "Priority";
$_LANG['domaindnsmxonly'] = "Priority Record for MX Only";

$_LANG['orderpromoprestart'] = "This promotion has not yet started. Please try again later.";

$_LANG['ticketmerge'] = "MERGED";

$_LANG['quote'] = "Quote";
$_LANG['quotestitle'] = "My Quotes";
$_LANG['quoteview'] = "View";
$_LANG['quotedownload'] = "View/Download";
$_LANG['quoteacceptbtn'] = "Accept Quote";
$_LANG['quotedlpdfbtn'] = "Download PDF";
$_LANG['quotediscountheading'] = "Discount (%)";
$_LANG['noquotes'] = "There are currently no quotes saved under your account.<br />To request a quote, please open a ticket.";
$_LANG['quotenumber'] = "Quote #";
$_LANG['quotesubject'] = "Subject";
$_LANG['quotedatecreated'] = "Date Created";
$_LANG['quotevaliduntil'] = "Valid Until";
$_LANG['quotestage'] = "Status";
$_LANG['quoterecipient'] = "Receipient";
$_LANG['quoteqty'] = "Qty";
$_LANG['quotedesc'] = "Description";
$_LANG['quoteunitprice'] = "Unit Price";
$_LANG['quotediscount'] = "Discount %";
$_LANG['quotelinetotal'] = "Total";
$_LANG['quotestagedraft'] = "Draft";
$_LANG['quotestagedelivered'] = "Delivered";
$_LANG['quotestageonhold'] = "On Hold";
$_LANG['quotestageaccepted'] = "Accepted";
$_LANG['quotestagelost'] = "Lost";
$_LANG['quotestagedead'] = "Dead";
$_LANG['quoteref'] = "Re Quote #";
$_LANG['quotedeposit'] = "Deposit";
$_LANG['quotefinalpayment'] = "Balance from Deposit";

$_LANG['invoiceoneoffpayment'] = "Make One Off Payment";
$_LANG['invoicesubscriptionpayment'] = "Create Automated Recurring Subscription";

$_LANG['invoicepaymentpendingreview'] = "Thank You! Your payment was successful and will be applied to your invoice as soon as 2CheckOut's Review Process has completed.<br /><br />This can take up to a few hours so your patience is appreciated.";

$_LANG['step'] = "Step %s";
$_LANG['cartdomainexists'] = "This domain already exists in our database so cannot be ordered again";
$_LANG['cartcongratsdomainavailable'] = "Congratulations, %s is available!";
$_LANG['cartregisterhowlong'] = "How long do you want to register this for?";
$_LANG['cartdomaintaken'] = "Sorry, %s is already taken";
$_LANG['carttransfernotregistered'] = "%s does not appear to be registered yet";
$_LANG['carttransferpossible'] = "Congratulations, we can transfer %s to us for just %s";
$_LANG['cartotherdomainsuggestions'] = "Other domains you might be interested in...";
$_LANG['cartdomainsconfiginfo'] = "The following options and settings are available for the domains you have chosen. Required fields are indicated with a *.";
$_LANG['cartnameserverchoice'] = "Nameserver Choice";
$_LANG['cartnameserverchoicedefault'] = "Use default nameservers for our hosting";
$_LANG['cartnameserverchoicecustom'] = "Use custom nameservers";
$_LANG['cartfollowingaddonsavailable'] = "The following addons are available for your active products & services.";
$_LANG['cartregisterdomainchoice'] = "Register a new domain";
$_LANG['carttransferdomainchoice'] = "Transfer your domain from another registrar";
$_LANG['cartexistingdomainchoice'] = "I will use my existing domain and update my nameservers";
$_LANG['cartsubdomainchoice'] = "Use a subdomain from %s";
$_LANG['carterrordomainconfigskipped'] = "You must go back and complete the required domain configuration fields above";
$_LANG['cartproductchooseoptions'] = "Choose Options";
$_LANG['cartproductselection'] = "Product Selection";
$_LANG['cartreviewcheckout'] = "Review & Checkout";
$_LANG['cartchoosecycle'] = "Choose Billing Cycle";
$_LANG['cartavailableaddons'] = "Available Addons";
$_LANG['cartsetupfees'] = "Setup Fees";
$_LANG['cartchooseanotherproduct'] = "Choose Another Product";
$_LANG['cartaddandcheckout'] = "Add to Cart & Checkout";
$_LANG['cartchooseanothercategory'] = "Choose Another Category";
$_LANG['carttryanotherdomain'] = "Try another domain";
$_LANG['cartmakedomainselection'] = "Please provide us with the domain you want to use with your hosting service by selecting an option from the selections below.";
$_LANG['cartfraudcheck'] = "Fraud Check";

$_LANG['newcustomer'] = "New Customer";
$_LANG['existingcustomer'] = "Existing Customer";
$_LANG['newcustomersignup'] = "Not Yet Registered? %sClick here to signup...%s";

$_LANG['upgradeonselectedoptions'] = "(On Selected Options)";
$_LANG['recurringpromodesc'] = "This promotion code also includes a %s Recurring Discount<br />(This discount will apply to future renewals of the product's total price)";

# Version 4.5.2

$_LANG['ajaxcartcheckout'] = "Jump straight to checkout &raquo;";
$_LANG['ordersummarybegin'] = "Shopping Cart is Empty<br/>Please choose a product to begin...";
$_LANG['ajaxcartconfigreqnotice'] = "You're on the way to signing up with us, but you must choose a domain before you can add the selected product to your cart...";

# Version 5.0.0

$_LANG['cancelrequestdomain'] = "Annuller domæne fornyelse?";
$_LANG['cancelrequestdomaindesc'] = "Du har en aktiv domæneregistrering for det domæne der er tilknyttet dette produkt. <br />Dette domæne står til at skal fornyes den %s til en pris af %s for %s år<br /> <br />Hvis du ønsker at annullere dette domæne, og lad det udløber ved udgangen af den nuværende registreringsperiode, så afkrydser du bare feltet nedenfor.";
$_LANG['cancelrequestdomainconfirm'] = "Jeg bekræfter, Jeg ønsker ikke at forny dette domæne igen";

$_LANG['startingfrom'] = "Start fra";

$_LANG['orderpromopriceoverride'] = "Pris overstyring";
$_LANG['orderpromofreesetup'] = "Gratis opsætning";

$_LANG['thereisaproblem'] = "Ups, der er et problem ...";
$_LANG['problemgoback'] = "Gå tilbage og prøv igen";

$_LANG['quantity'] = "Antal";
$_LANG['cartqtyenterquantity'] = "Ønsker du mere end 1 af denne vare? Vælg antal her:";
$_LANG['cartqtyupdate'] = "Opdater";
$_LANG['invoiceqtyeach'] = "/hver";

$_LANG['nschoicedefault'] = "Brug standard navneservere";
$_LANG['nschoicecustom'] = "Brug brugerdefinerede navneservere (indtast nedenfor)";

$_LANG['jumpto'] = "Hop til";
$_LANG['top'] = "Top";

$_LANG['domaincontactusexisting'] = "Brug eksisterende kontaktperson";
$_LANG['domaincontactusecustom'] = "Angive brugerdefinerede oplysninger nedenfor";
$_LANG['domaincontactchoose'] = "Vælg kontaktperson";
$_LANG['domaincontactprimary'] = "Primær profil data";

$_LANG['invoicepdfgenerated'] = "PDF genereret den";

$_LANG['domainrenewalsbeforerenewlimit'] = "Minimumsperiode for forlængelse er %s dage";

$_LANG['promonewsignupsonly'] = "Denne kampagne kode er kun gyldig for nye kunder";

# Bulk Domain Management

$_LANG['domainbulkmanagement'] = "Vælg handling, der skal udføres på de markeret ";
$_LANG['domainbulkmanagementchangesaffect'] = "De ændringer, der foretages nedenfor vil påvirke følgende domæner:";
$_LANG['domainbulkmanagementchangeaffect'] = "Ændringen vil gælde for følgende domæner:";
$_LANG['domaincannotbemanaged'] = "Kan ikke administreres automatisk - Kontakt venligst support vedrørende eventuelle ændringer, du ønsker at foretage";
$_LANG['domainbulkmanagementnotpossible'] = "Desværre kan disse indstillinger ikke redigeres fra vores kunde område på det aktuelle tidspunkt. Kontakt venligst support vedrørende eventuelle ændringer, du ønsker at foretage";

$_LANG['domainmanagens'] = "Administrer navneservere";

$_LANG['domainautorenewstatus'] = "Automatisk fornyelse status";
$_LANG['domainautorenewinfo'] = "Automatisk fornyelse hjælper med at beskytte dit domæne. Når den er aktiveret, vil vi automatisk sende dig en fornyelse faktura i god tid før dit domæne udløber, for at vi kan forny domænet skal betalingen være fuldført.";
$_LANG['domainautorenewrecommend'] = "Vi anbefaler at holde automatisk fornyelse aktiveret for at undgå at miste dit domæne.";

$_LANG['domainreglockstatus'] = "Registrator låsestatus";
$_LANG['domainreglockinfo'] = "Registrator lås (også kendt som tyverisikring) sikrer dine domæne fra uautoriserede overførsler.";
$_LANG['domainreglockrecommend'] = "Vi anbefaler, at du holder denne aktiveret, undtagen hvis du vil flytte dit domænenavn.";
$_LANG['domainreglockenable'] = "Aktiver registrator lås";
$_LANG['domainreglockdisable'] = "Deaktiver registrator lås";

$_LANG['domaincontactinfoedit'] = "Rediger kontaktoplysninger";

$_LANG['domainmassrenew'] = "Forny domæner";

# reCAPTCHA

$_LANG['captchatitle'] = "Spam robot verifikation";
$_LANG['captchaverify'] = "De tegn du ser på billedet nedenfor, skal indtastes i tekstboksen. Dette er nødvendigt for at forhindre misbrug af registreringerne.";
$_LANG['captchaverifyincorrect'] = "De indtastede tegn matchede ikke billedet, der vises. Prøv venligst igen.";
$_LANG['recaptcha-invalid-site-private-key'] = "Der opstod en fejl, du bedes kontakte support (fejlkode: cap1)";
$_LANG['recaptcha-invalid-request-cookie'] = "Der opstod en fejl, prøv igen (fejlkode: cap2)";
$_LANG['recaptcha-incorrect-captcha-sol'] = "De indtastede tegn matchede ikke ord verifikation. Prøv venligst igen.";

# Product Bundles

$_LANG['bundledeal'] = "Bundle Deal!";
$_LANG['bundlevaliddateserror'] = "Der er ingen tilbudspakker";
$_LANG['bundlevaliddateserrordesc'] = "Denne tilbudspakke er enten inaktive eller udløbet. Hvis du mener at denne besked er en fejl, bedes du kontakte support.";
$_LANG['bundlemaxusesreached'] = "Tilbudspakkens maksimum er nået";
$_LANG['bundlemaxusesreacheddesc'] = "Denne tilbudspakke har nået det maksimale antal der kan sælges, så den er desværre ikke længere tilgængelig. Venligst kontakt os, hvis du er interesseret i vores serviceydelser.";
$_LANG['bundlereqsnotmet'] = "Tilbudspakkens krav er ikke opfyldt";
$_LANG['bundlewarningpromo'] = "Den valgte tilbudspakke kan ikke anvendes i forbindelse med andre kampagnetilbud eller tilbud.";
$_LANG['bundlewarningproductcycle'] = "Den valgte tilbudspakke kræver, at du vælger en faktureringsperiode '%s' for produkt %s inden du kan fortsætte";
$_LANG['bundlewarningproductconfopreq'] = "Den valgte tilbudspakke kræver, at du vælger '%s' for '%s' inden du kan fortsætte";
$_LANG['bundlewarningproductconfopyesnoenable'] = "Den valgte tilbudspakke kræver, at du vælger valgmuligheden '%s' inden du kan fortsætte";
$_LANG['bundlewarningproductconfopyesnodisable'] = "Den valgte tilbudspakke kræver, at du fravælger valgmuligheden '%s' inden du kan fortsætte";
$_LANG['bundlewarningproductconfopqtyreq'] = "Den valgte tilbudspakke kræver, at du vælger et antal af '%s' for '%s' inden du kan fortsætte";
$_LANG['bundlewarningproductaddonreq'] = "Den valgte tilbudspakke kræver, at du vælger tilføjelsen '%s' til produktet %s inden du kan fortsætte";
$_LANG['bundlewarningdomainreq'] = "Den valgte tilbudspakke kræver at du registrere eller overføre (redeleger) et domæne sammen med produktet %s inden du kan fortsætte";
$_LANG['bundlewarningdomaintld'] = "Den valgte tilbudspakke kræver, at du vælger et domæne med endelsen '%s' for domænet %s inden du kan fortsætte";
$_LANG['bundlewarningdomainregperiod'] = "Den valgte tilbudspakke kræver, at du vælger registreringsperiode '%s' for domænet %s inden du kan fortsætte";
$_LANG['bundlewarningdomainaddon'] = "Den valgte tilbudspakke kræver, at du vælger tilføjelsen '%s' til domænet %s inden du kan fortsætte";

# New Client Area Template  Lines

$_LANG['navservices'] = "Produkter";
$_LANG['navservicesorder'] = "Køb et produkt";
$_LANG['navdomains'] = "Domæner";
$_LANG['navrenewdomains'] = "Forny domæner";
$_LANG['navregisterdomain'] = "Registrere et nyt domæne";
$_LANG['navtransferdomain'] = "Overfør domæner til os";
$_LANG['navwhoislookup'] = "Whois opslag";
$_LANG['navbilling'] = "Fakturering";
$_LANG['navsupport'] = "Support";
$_LANG['navtickets'] = "Sager";
$_LANG['navopenticket'] = "Åbne sag";
$_LANG['navmanagecc'] = "Administrer kreditkort";
$_LANG['navemailssent'] = "E-mails sendt";

$_LANG['hello'] = "Hello";
$_LANG['account'] = "Konto";
$_LANG['login'] = "Log ind";
$_LANG['register'] = "Register";
$_LANG['forgotpw'] = "Glemt kodeord?";
$_LANG['editaccountdetails'] = "Redigere kontooplysninger";

$_LANG['clientareanavccdetails'] = "Kreditkort oplysninger";
$_LANG['clientareanavcontacts'] = "Kontakter/Underkonto";

$_LANG['manageyouraccount'] = "Manage Your Account";
$_LANG['accountoverview'] = "Kontooversigt";
$_LANG['paymentmethod'] = "Betalingsmetode";
$_LANG['paymentmethoddefault'] = "Brug standard (sæt pr ordre)";
$_LANG['productmanagementactions'] = "Administrative handlinger";
$_LANG['clientareanoaddons'] = "Der er endnu ikke købt nogle tilføjelser";
$_LANG['downloadssearch'] = "Søg i downloads";
$_LANG['emailviewmessage'] = "Vis besked";
$_LANG['resultsperpage'] = "Results Per Page";
$_LANG['accessdenied'] = "Adgang nægtet";
$_LANG['search'] = "Søg";
$_LANG['cancel'] = "Annuller";
$_LANG['clientareabacklink'] = "&laquo; Tilbage";
$_LANG['backtoserviceslist'] = "&laquo; Back to Services List";
$_LANG['backtodomainslist'] = "&laquo; Back to Domains List";

$_LANG['clientareahomeorder'] = "Gå til ordreformularen der kan du se de produkter og services vi tilbyder. Eksisterende kunder kan også købe ekstraudstyr og tilføjelser her";
$_LANG['clientareahomelogin'] = "Er du allerede registreret hos os? Hvis dette er tilfældet, skal du klikke på knappen nedenfor for at logge ind på vores kundeside, hvorfra du kan administrere din konto.";
$_LANG['clientareahomeorderbtn'] = "Gå til ordreformularen";
$_LANG['clientareahomeloginbtn'] = "Sikker Kundelogin";

$_LANG['clientareaproductsintro'] = "Dette er alle de produkter du har registreret på denne konto.";
$_LANG['clientareaproductdetailsintro'] = "Here is an overview of your product/service with us.";
$_LANG['clientareadomainsintro'] = "Dette er alle de domæner du har registreret på denne konto.";
$_LANG['invoicesintro'] = "Herunder kan du se alle de faktura du har modtaget fra os.";
$_LANG['quotesintro'] = "Her er alle de tilbud du har modtaget fra os.";
$_LANG['emailstagline'] = "Her er en kopi af de seneste e-mails vi har sendt dig...";
$_LANG['supportticketsintro'] = "Send og spor alle henvendelser til os her ...";
$_LANG['addfundsintro'] = "Tank din konto op";
$_LANG['registerintro'] = "Opret en konto hos os. . .";
$_LANG['masspayintro'] = "Betale alle de fakturaer, der er anført nedenfor i en enkelt transaktion ved at vælge en betalingsmetode";
$_LANG['domaincheckerintro'] = "Start din søgning efter web hosting, her ved at kontrollere om dit domæne er ledigt...";
$_LANG['networkstatusintro'] = "Services og drift information samt netværks meddelelser";

$_LANG['creditcardyourinfo'] = "Faktureringsoplysninger";
$_LANG['ourlatestnews'] = "Vores seneste nyheder";
$_LANG['ccexpiringsoon'] = "Kreditkortet udløber snart";
$_LANG['ccexpiringsoondesc'] = "Dit kreditkort udløber snart, så skal du sikre dig %s at få opdateret dine kortoplysninger %s til os, når du kan";
$_LANG['availcreditbal'] = "Tilgængelig saldo";
$_LANG['availcreditbaldesc'] = "Du har et indestående på %s og dette vil automatisk blive overført til nye fakturaer";
$_LANG['youhaveoverdueinvoices'] = "You have %s Overdue Invoice(s)";
$_LANG['overdueinvoicesdesc'] = "For at undgå afbrydelse af ydelserne, skal du betale dine udestående fakturaer så hurtigt som muligt. %sBetal nu&raquo;%s";
$_LANG['supportticketsnoneopen'] = "Der er i øjeblikket ingen åbne supportsager";
$_LANG['invoicesnoneunpaid'] = "Der er i øjeblikket ingen ubetalte fakturaer";

$_LANG['registerdisablednotice'] = "For at registrere skal du afgive en <strong><a href=\"cart.php\">ordre</a></strong>";

$_LANG['pwstrength'] = "kodeordet styrke";
$_LANG['pwstrengthenter'] = "Indtast et kodeord";
$_LANG['pwstrengthweak'] = "Svag";
$_LANG['pwstrengthmoderate'] = "Moderat";
$_LANG['pwstrengthstrong'] = "Stærk";

$_LANG['managing'] = "Administrerer";
$_LANG['information'] = "Information";
$_LANG['withselected'] = "Med udvalgte";
$_LANG['managedomain'] = "Administrer domæne";
$_LANG['changenameservers'] = "Skift navneservere";
$_LANG['clientareadomainmanagedns'] = "Administrer DNS";
$_LANG['clientareadomainmanageemailfwds'] = "Administrer e-mail viderestillinger";
$_LANG['moduleactionsuccess'] = "Handlingen er gennemført med succes!";
$_LANG['moduleactionfailed'] = "Handlingen mislykkedes";

$_LANG['domaininfoexp'] = "Til højre kan du finde oplysninger om dit domæne. Du kan administrere dit domæne ved hjælp af fanebladene ovenfor.";
$_LANG['domainrenewexp'] = "Aktiver automatisk fornyelse, så sender vi dig automatisk en faktura for fornyelsen, før dit domæne udløber. ";
$_LANG['domainnsexp'] = "Her kan du ændre hvor dit domæne skal peger hen. Vær opmærksom på ændringer kan tage op til 24 timer før alle navneserver er opdateret.";
$_LANG['domainlockingexp'] = "Lås dit domæne for at forhindre det i at blive flyttet væk (redelegeret) uden din tilladelse.";
$_LANG['domaincurrentlyunlocked'] = "Domænet er på nuværende tidspunkt ulåst!";
$_LANG['domaincurrentlyunlockedexp'] = "Du bør aktivere registrator låsen, medmindre du skal overfører (redeleger) domænet.";
$_LANG['searchmultipletlds'] = "Search Multiple TLDs";

$_LANG['networkstatustitle'] = "Netværksstatus";
$_LANG['networkstatusnone'] = "Der er ingen %s netværksproblemer i øjeblikket";
$_LANG['serverstatusheadingtext'] = "Nedenfor er et her og nu overblik over vores servere, hvor du kan se om der er fundet nogen problemer.";

$_LANG['clientareacancelreasonrequired'] = "Du skal skrive grunden til annulleringen";

$_LANG['addfundsdescription'] = "Tilføj penge til din konto hos os for at undgå masser af små transaktioner og til automatisk betaling af eventuelle nye fakturaer.";
$_LANG['addfundsnonrefundable'] = "* Alle indskud refunderes ikke.";

$_LANG['creditcardexpirydateinvalid'] = "Udløbsdatoen skal skrives i formatet MM/ÅÅ og må ikke være af ældre dato end i dag";

$_LANG['domaincheckerchoosedomain'] = "Vælg et domænenavn...";
$_LANG['domaincheckerchecknewdomain'] = "Se om domænet er tilgængeligt";
$_LANG['domaincheckerdomainexample'] = " f.eks. ditdomæne.dk";
$_LANG['domaincheckerinvalidtld'] = "er ikke et gyldigt TLD prøv venligst igen.";
$_LANG['domaincheckerhostingonly'] = "Bestil kun hosting";
$_LANG['domaincheckeravailtransfer'] = "Available for Transfer";
$_LANG['domaincheckerenterdomain'] = "Start din web hosting oplevelse med os ved at skrive det domænenavn, du ønsker at registrere eller overføre (redeleger) eller blot køb hosting til nedenfor...";
$_LANG['domaincheckerbulkinvaliddomain'] = "Et eller flere af de domæner, du har skrevet ovenfor var ugyldig, og er så blevet udeladt fra resultaterne";

$_LANG['kbquestionsearchere'] = "Have a question? Start your search here.";
$_LANG['contactus'] = "Kontakt os";

$_LANG['opennewticket'] = "Opret en ny sag";
$_LANG['searchtickets'] = "Skriv sagens # eller emne";
$_LANG['supportticketspriority'] = "Prioritet";
$_LANG['supportticketsubmitted'] = "Indsendt";
$_LANG['supportticketscontact'] = "Kontakt";
$_LANG['supportticketsticketlastupdated'] = "Sidst opdateret";

$_LANG['upgradedowngradepackage'] = "Opgradering/Nedgradering";
$_LANG['upgradedowngradechooseproduct'] = "Vælg produkt";

$_LANG['jobtitlereqforcompany'] = "(Påkrævet, hvis firmanavn er angivet)";

$_LANG['downloadproductrequired'] = "For at hente dette element kræves det, at du har et af følgende produkt/service som er aktivt:";

$_LANG['affiliatesignuptitle'] = "Get Paid for Referring Customers to Us";
$_LANG['affiliatesignupintro'] = "Activate your affiliate account and start earning money today...";
$_LANG['affiliatesignupinfo1'] = "We pay commissions for every signup that comes via your custom signup link.";
$_LANG['affiliatesignupinfo2'] = "We track the visitors you refer to us using cookies, so users you refer don't have to purchase instantly for you to receive your commission.  Cookies last for up to 90 days following the initial visit.";
$_LANG['affiliatesignupinfo3'] = "If you would like to find out more, please contact us.";

# Version 5.1

$_LANG['copyright'] = "Copyright";
$_LANG['allrightsreserved'] = "All Rights Reserved";
$_LANG['supportticketsclose'] = "Close Ticket";
$_LANG['affiliatesinitialthen'] = "Initially then";
$_LANG['invoicesoutstandingbalance'] = "Outstanding Balance";

$_LANG['cpanellogin'] = "Login to cPanel";
$_LANG['cpanelwhmlogin'] = "Login to WHM";
$_LANG['cpanelwebmaillogin'] = "Login to Webmail";
$_LANG['enkompasslogin'] = "Login to Enkompass";
$_LANG['plesklogin'] = "Login to Plesk Control Panel";
$_LANG['helmlogin'] = "Login to Helm Control Panel";
$_LANG['hypervmrestart'] = "Restart VPS Server";
$_LANG['siteworxlogin'] = "Login to SiteWorx Control Panel";
$_LANG['nodeworxlogin'] = "Login to NodeWorx Control Panel";
$_LANG['veportallogin'] = "Login to vePortal";
$_LANG['virtualminlogin'] = "Login to Control Panel";
$_LANG['websitepanellogin'] = "Login to Control Panel";
$_LANG['whmsoniclogin'] = "Login to Control Panel";
$_LANG['xpanelmaillogin'] = "Login to Webmail";
$_LANG['xpanellogin'] = "Login to XPanel";
$_LANG['heartinternetlogin'] = "Login to Control Panel";
$_LANG['gamecplogin'] = "Login to GameCP";
$_LANG['fluidvmrestart'] = "Restart VPS Server";
$_LANG['enomtrustedesc'] = "The TRUSTe Control Panel contains the set up wizard to get your Privacy Policy up and running.";
$_LANG['enomtrustelogin'] = "Login to TrustE Control Panel";
$_LANG['directadminlogin'] = "Login to DirectAdmin";
$_LANG['centovacastlogin'] = "Login to Centova Cast";
$_LANG['castcontrollogin'] = "Login to Control Panel";

$_LANG['sslconfigurenow'] = "Configure Now";
$_LANG['sslprovisioningdate'] = "SSL Provisioning Date";
$_LANG['globalsignvoucherscode'] = "Your OneClickSSL Voucher Code";
$_LANG['globalsignvouchersnotissued'] = "Not Yet Issued";

$_LANG['domaintrffailreasonunavailable'] = "Failure Reason Unavailable";

$_LANG['clientareaprojects'] = "My Projects";

$_LANG['clientgroupdiscount'] = "Client Discount";
$_LANG['billableitemshours'] = "Hours";
$_LANG['billableitemshour'] = "Hour";

$_LANG['invoicefilename'] = "Invoice-";
$_LANG['quotefilename'] = "Quote-";

# Licensing Addon

$_LANG['licensingkey'] = "License Key";
$_LANG['licensingvaliddomains'] = "Valid Domains";
$_LANG['licensingvalidips'] = "Valid IPs";
$_LANG['licensingvaliddirectory'] = "Valid Directory";
$_LANG['licensingstatus'] = "License Status";
$_LANG['licensingreissue'] = "Reissue License";
$_LANG['licensingreissued'] = "The Valid Domain, IP and Directory will be detected & saved the next time the license is used.";

# Domain Addons

$_LANG['domainaddons'] = "Addons";
$_LANG['domainaddonsinfo'] = "The following addons are available for your domain(s)...";
$_LANG['domainaddonsdnsmanagement'] = "DNS Host Record Management";
$_LANG['domainaddonsidprotectioninfo'] = "Protect your personal information and reduce the amount of spam to your inbox by enabling ID Protection.";
$_LANG['domainaddonsdnsmanagementinfo'] = "External DNS Hosting can help speed up your website and improve availability with reduced redundancy.";
$_LANG['domainaddonsemailforwardinginfo'] = "Get emails forwarded to alternate email addresses of your choice so that you can monitor all from a single account.";
$_LANG['domainaddonsbuynow'] = "Buy Now for";
$_LANG['domainaddonsperyear'] = "/Year";
$_LANG['domainaddonscancelareyousure'] = "Are you sure you want to disable & cancel this domain addon?";
$_LANG['domainaddonsconfirm'] = "Confirm Cancellation";
$_LANG['domainaddonscancelsuccess'] = "Addon Deactivated Successfully!";
$_LANG['domainaddonscancelfailed'] = "Failed to deactivate addon. Please contact support.";

# Version 5.2

$_LANG['yourclientareahostingaddons'] = "You have the following addons for this product.";
$_LANG['loginrequired'] = "Login Required";
$_LANG['unsubscribe'] = "Unsubscribe";
$_LANG['emailoptout'] = "Newsletter Opt-out";
$_LANG['newsletterunsubscribe'] = "Newsletter Unsubscribe";
$_LANG['emailoptoutdesc'] = "Tick to unsubscribe from our newsletters";
$_LANG['alreadyunsubscribed'] = "You have already unsubscribed from our newsletter.";
$_LANG['newsletterresubscribe'] = "If you wish to re-subscribe you can do so from the %sMy Details%s section of our client area at any time.";
$_LANG['unsubscribehashinvalid'] = "Unsubscribe failed, please contact support.";
$_LANG['unsubscribesuccess'] = "Unsubscribe Successful";
$_LANG['newsletterremoved'] = "Thank you, Your email has now been removed from our mailing list.";
$_LANG['erroroccured'] = "An Error Occurred";
$_LANG['pwresetsuccessdesc'] = "Your password has now been reset. %sClick here%s to continue to the client area...";
$_LANG['pwresetenternewpw'] = "Please enter your desired new password below.";
$_LANG['ordererrorsbudomainbanned'] = "The subdomain prefix you entered is not allowed - please try another";

$_LANG['ticketfeedbacktitle'] = "Feedback Request for Ticket";

$_LANG['nosupportdepartments'] = "No support departments found. Please try again later.";

$_LANG['feedbackclosed'] = "Feedback cannot be provided until the ticket is closed";
$_LANG['feedbackprovided'] = "You have already provided feedback for this ticket";
$_LANG['feedbackthankyou'] = "We thank you for taking the time to provide your feedback.";
$_LANG['feedbackreceived'] = "Submission Received";
$_LANG['feedbackdesc'] = "Please can we ask you to take a moment of your time to fill out the below form about the quality of your experience with our support team.";
$_LANG['feedbackclickreview'] = "Click here to Review The Ticket";
$_LANG['feedbackopenedat'] = "Opened At";
$_LANG['feedbacklastreplied'] = "Last Replied To";
$_LANG['feedbackstaffinvolved'] = "Staff Involved";
$_LANG['feedbacktotalduration'] = "Total Duration";
$_LANG['feedbackpleaserate1'] = "Please rate (on a scale of 1 to 10) how well";
$_LANG['feedbackpleasecomment1'] = "Please comment on how well";
$_LANG['feedbackhandled'] = "handled this support request";
$_LANG['feedbackworst'] = "Worst";
$_LANG['feedbackbest'] = "Best";
$_LANG['feedbackimprove'] = "How may we make your experience better in the future?";
$_LANG['pleaserate2'] = "handled this support request";
$_LANG['returnclient'] = "Return to Client Area";

$_LANG['clientareanavsecurity'] = "Security Settings";
$_LANG['twofactorauth'] = "Two-Factor Authentication";
$_LANG['twofaenable'] = "Enable Two-Factor Authentication";
$_LANG['twofadisable'] = "Disable Two-Factor Authentication";
$_LANG['twofaenableclickhere'] = "Click here to Enable";
$_LANG['twofadisableclickhere'] = "Click here to Disable";
$_LANG['twofaenforced'] = "The system administrator has enforced that you must enable Two-Factor Authentication before you can continue. This page will guide you through the process of setting it up.";
$_LANG['twofasetup'] = "Two-Factor Authentication Setup Process";
$_LANG['twofasetupgetstarted'] = "Get Started";
$_LANG['twofaactivationintro'] = "Two-Factor Authentication adds an extra layer of protection to logins. Once enabled &amp; configured, each time you sign in you will be asked to enter both your username & password as well as a second factor such as a security code.";
$_LANG['twofaactivationmultichoice'] = "To continue, please choose your desired Two-Factor Authentication method from below.";
$_LANG['twofadisableintro'] = "To disable Two-Factor Authentication please confirm your password in the field below.";
$_LANG['twofaactivationerror'] = "An error occurred while attempting to activate Two-Factor Authentication for your account. Please try again.";
$_LANG['twofamoduleerror'] = "An error occurred loading the module. Please try again.";
$_LANG['twofaactivationcomplete'] = "Two-Factor Authentication Setup is Complete!";
$_LANG['twofadisableconfirmation'] = "Two-Factor Authentication has now been disabled for your account.";
$_LANG['twofabackupcodeis'] = "Your Backup Code is";
$_LANG['twofanewbackupcodeis'] = "Your New Backup Code is";
$_LANG['twofabackupcodelogin'] = "Enter Your Backup Code Above to Login";
$_LANG['twofabackupcodeexpl'] = "Write this down on paper and keep it safe.<br />It will be needed if you ever lose your 2nd factor device or it is unavailable to you.";
$_LANG['twofaconfirmpw'] = "Enter Your Password";
$_LANG['twofa2ndfactorreq'] = "Your second factor is required to complete login.";
$_LANG['twofa2ndfactorincorrect'] = "The second factor you supplied was incorrect. Please try again.";
$_LANG['twofabackupcodereset'] = "Login via Backup Code Successful. Backup Codes are valid once only. It will now be reset.";
$_LANG['twofacantaccess2ndfactor'] = "Can't Access Your 2nd Factor Device?";
$_LANG['twofaloginusingbackupcode'] = "Login using Backup Code";
$_LANG['twofageneralerror'] = "An error occurred loading the module. Please try again.";

$_LANG['continue'] = "Continue";
$_LANG['disable'] = "Disable";
$_LANG['manage'] = "Manage";
