<?php
/**
 * WHMCS Language File
 * Hungarian (hu)
 *
 * Please Note: These language files are overwritten during software updates
 * and therefore editing of these files directly is not advised. Instead we
 * recommend that you use overrides to customise the text displayed in a way
 * which will be safely preserved through the upgrade process.
 *
 * For instructions on overrides, please visit:
 *   http://docs.whmcs.com/Language_Overrides
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

if (!defined("WHMCS")) die("This file cannot be accessed directly");

$_LANG['isocode'] = "hu";

$_LANG['accountinfo'] = "Fiókinformációk";
$_LANG['accountstats'] = "Fiókstatisztikák";
$_LANG['addfunds'] = "Alaptőke hozzáadása";
$_LANG['addfundsamount'] = "Összeg hozzáadása";
$_LANG['addfundsmaximum'] = "Maximum betét";
$_LANG['addfundsmaximumbalance'] = "Maximum egyenleg";
$_LANG['addfundsmaximumbalanceerror'] = "Maximum egyenleg összege";
$_LANG['addfundsmaximumerror'] = "Maximum betét összege";
$_LANG['addfundsminimum'] = "Minimum betét";
$_LANG['addfundsminimumerror'] = "Minimum betét összege";
$_LANG['addmore'] = "Mégtöbbet hozzáad";
$_LANG['addtocart'] = "Kosárba";
$_LANG['affiliatesactivate'] = "Affiliate fiók aktiválása";
$_LANG['affiliatesamount'] = "Összeg";
$_LANG['affiliatesbalance'] = "Aktuális egyenleg";
$_LANG['affiliatesbullet1'] = "Affiliate fiókjához egy bónusz kezdő tőkét kap ekkora értékben:";
$_LANG['affiliatesbullet2'] = "-ot minden fizetés után, minden egyes ügyfél kapcsán akinek ajánlottál minket az Ő hoszting fiók bérlésének teljes időtartamára";
$_LANG['affiliatescommission'] = "Jutalék";
$_LANG['affiliatesdescription'] = "Csatlakozzon affiliate programunkhoz vagy nézze meg jutalékait";
$_LANG['affiliatesdisabled'] = "Jelenleg nem ajánlunk fel affiliate rendszert ügyfeleinknek.";
$_LANG['affiliatesearn'] = "Keressen";
$_LANG['affiliatesearningstodate'] = "Összes kereset eddig a dátumig";
$_LANG['affiliatesfootertext'] = "Amikor te ajánlasz valakinek minket a te egyedi Azonosítóddal, egy cookie-t mentünk el az Ő számítógépére ezzel az azonosítóval, tehát ha a kedvencek közé menti az oldalt és később vissza jön, te akkor is megkapod a jutalékod.";
$_LANG['affiliateshostingpackage'] = "Tárhely csomag";
$_LANG['affiliatesintrotext'] = "Aktiválja affiliate fiókját még ma:";
$_LANG['affiliateslinktous'] = "Link hozzánk";
$_LANG['affiliatesnosignups'] = "Jelenleg még nem érkezett regisztrációs kérelem Ön által ajánlott ügyféltől.";
$_LANG['affiliatesrealtime'] = "Ezek a statisztikák valósidejűek és azonnal frissülnek.";
$_LANG['affiliatesreferallink'] = "Az Ön egyedi ajánló linkje";
$_LANG['affiliatesreferals'] = "Az Ön ajánlottjai";
$_LANG['affiliatesregdate'] = "Regisztráció dátuma";
$_LANG['affiliatesrequestwithdrawal'] = "Kifizetés igénylése";
$_LANG['affiliatessignupdate'] = "Regisztráció dátuma";
$_LANG['affiliatesstatus'] = "Állapot";
$_LANG['affiliatestitle'] = "Affiliatek";
$_LANG['affiliatesvisitorsreferred'] = "Ajánlott látogatók száma";
$_LANG['affiliateswithdrawalrequestsuccessful'] = "Az Ön kifizetési igénye elküldve. Hamarosan kapcsolatba lépünk Önnel.";
$_LANG['affiliateswithdrawn'] = "Kifizetés teljes összege";
$_LANG['all'] = "Összes";
$_LANG['alreadyregistered'] = "Már regisztrált?";
$_LANG['announcementsdescription'] = "Nézze meg legfrissebb híreinket és közleményeinket";
$_LANG['announcementsnone'] = "Nincsenek megjelenítendő közlemények";
$_LANG['announcementsrss'] = "RSS-hírfolyam";
$_LANG['announcementstitle'] = "Közlemények";
$_LANG['bannedbanexpires'] = "Tiltás Lejárata";
$_LANG['bannedbanreason'] = "Tiltás oka";
$_LANG['bannedhasbeenbanned'] = "kitiltva";
$_LANG['bannedtitle'] = "Tiltott IP";
$_LANG['bannedyourip'] = "Az Ön IP-je";
$_LANG['cartaddons'] = "Kiegészítők";
$_LANG['cartbrowse'] = "Termékek és szolgáltatások böngészése";
$_LANG['cartconfigdomainextras'] = "Domain kiegészítők konfigurálása";
$_LANG['cartconfigoptionsdesc'] = "Ennek a terméknek/szolgáltatásnak van néhány lehetősége, amit alább kiválaszthat a rendelés testreszabásához.";
$_LANG['cartconfigserver'] = "Szerver Konfigurálása";
$_LANG['cartcustomfieldsdesc'] = "Ennek a terméknek/szolgáltatásnak a megrendeléséhez további információkra van szükségünk a rendelés feldolgozásához.";
$_LANG['cartdomainsconfig'] = "Domainek konfigurációja";
$_LANG['cartdomainsconfigdesc'] = "Az alábbiakban beállíthatja a kosárban lévő domain neveket, kiválaszthatja a kiegészítő szolgáltatásokat, megadhatja a szükséges információkat, meghatározhatja a névszerveket amiket használni szeretne.";
$_LANG['cartdomainshashosting'] = "Van Tárhely";
$_LANG['cartdomainsnohosting'] = "Nincs tárhely! Kattintson a hozzáadáshoz.";
$_LANG['carteditproductconfig'] = "Konfiguráció szerkesztése";
$_LANG['cartempty'] = "Az Ön kosara üres";
$_LANG['cartemptyconfirm'] = "Biztos benne, hogy kiüríti a kosarat?";
$_LANG['cartexistingclientlogin'] = "Regisztrált Ügyfél bejelentkezése";
$_LANG['cartexistingclientlogindesc'] = "Ahhoz, hogy hozzáadd ezt a rendelést a már meglévő fiókodhoz, előbb be kell jelentkezned.";
$_LANG['cartnameserversdesc'] = "Ha saját névszerverét használna, írja be ide. Alapaesetben, új domaineknél a saját névszervereinket használjuk a saját hálózatunkon.";
$_LANG['cartproductaddons'] = "Termék kiegészítők";
$_LANG['cartproductaddonschoosepackage'] = "Válasszon csomagot";
$_LANG['cartproductaddonsnone'] = "Nincsen elérhető kiegészítő ehhez a termékhez és szolgáltatáshoz";
$_LANG['cartproductconfig'] = "Termék konfiguráció";
$_LANG['cartproductdesc'] = "A kiválasztott termékhez/szolgáltatáshoz az alábbi beállítási lehetőségek közül választhat.";
$_LANG['cartproductdomain'] = "Domainek";
$_LANG['cartproductdomainchoose'] = "Válasszon Domaint";
$_LANG['cartproductdomaindesc'] = "A kiválasztott termék/szolgáltatás domain nevet igényel, ezért kérjük, adja meg a domain nevet az alábbiak közül.";
$_LANG['cartproductdomainuseincart'] = "A kosárban lévő domain használata.";
$_LANG['cartremove'] = "Eltávolít";
$_LANG['cartremoveitemconfirm'] = "Biztosan el szeretné távolítani ezt az elemet a kosárból?";
$_LANG['carttaxupdateselections'] = "Az adó mértéke megváltozhat, különböző megye vagy ország választása esetén. Kattintson az újraszámolás gombra, ha meghozta döntését.";
$_LANG['carttaxupdateselectionsupdate'] = "Frissít";
$_LANG['carttitle'] = "Kosár";
$_LANG['changessavedsuccessfully'] = "Változások sikeresen mentve!";
$_LANG['checkavailability'] = "Elérhetőség ellenőrzése";
$_LANG['checkout'] = "Vásárlás";
$_LANG['choosecurrency'] = "Pénznem választása";
$_LANG['choosedomains'] = "Domainek választása";
$_LANG['clickheretologin'] = "Bejelentkezéshez kattintson ide";
$_LANG['clientareaaccountaddons'] = "Fiók kiegészítők";
$_LANG['clientareaactive'] = "Aktív";
$_LANG['clientareaaddfundsdisabled'] = "Jelenleg nem engedjük alapok elhelyezesét.";
$_LANG['clientareaaddfundsnotallowed'] = "Legalább egy aktív rendeléssel kell rendelkeznie mielőtt alapot ad hozzá, tehát ez most jelenleg nem folytatható!";
$_LANG['clientareaaddon'] = "Kiegészítők";
$_LANG['clientareaaddonorderconfirmation'] = "Köszönöm. Az Ön kiegészítő rendelése alább látható. Válasszon fizetési módot az alábbiak közül.";
$_LANG['clientareaaddonpricing'] = "Árak";
$_LANG['clientareaaddonsfor'] = "Kiegészítők a";
$_LANG['clientareaaddress1'] = "Cím 1";
$_LANG['clientareaaddress2'] = "Cím 2";
$_LANG['clientareabwlimit'] = "Sávszélesség korlát";
$_LANG['clientareabwusage'] = "Felhasznált sávszélesség";
$_LANG['clientareacancel'] = "Változások visszavonása";
$_LANG['clientareacancelconfirmation'] = "Köszönjük, a törlési kérést fogadtuk. Amennyiben ez tévedés volt, azonnal értesítsen minket, vagy fiókja törlésre kerülhet.";
$_LANG['clientareacancelinvalid'] = "Erre a fiókra már adott be törlési kérést.";
$_LANG['clientareacancellationendofbillingperiod'] = "Számlázási időszak vége";
$_LANG['clientareacancellationimmediate'] = "Azonnali";
$_LANG['clientareacancellationtype'] = "Lemondás típusa";
$_LANG['clientareacancelled'] = "Lemondva";
$_LANG['clientareacancelproduct'] = "Lemondás kérése erre a";
$_LANG['clientareacancelreason'] = "Röviden ismertesse a szolgáltatás lemondásának okát";
$_LANG['clientareacancelrequest'] = "Fiók törlés kérése";
$_LANG['clientareacancelrequestbutton'] = "Törlés kérése";
$_LANG['clientareachangepassword'] = "Jelszó megváltoztatása";
$_LANG['clientareachangesuccessful'] = "Az Ön adatai sikeresen megváltoztatva";
$_LANG['clientareachoosecontact'] = "Válasszon Kapcsolatot";
$_LANG['clientareacity'] = "Város";
$_LANG['clientareacompanyname'] = "Cég/szervezet neve";
$_LANG['clientareaconfirmpassword'] = "Jelszó megerősítése";
$_LANG['clientareacontactsemails'] = "E-mail beállítások";
$_LANG['clientareacontactsemailsdomain'] = "Domain Emailek - Megújítási figyelmeztetések, Regisztrációs megerősítések, stb...";
$_LANG['clientareacontactsemailsgeneral'] = "Általános e-mailek - Általános közlemények és Jelszó emlékeztetők";
$_LANG['clientareacontactsemailsinvoice'] = "Számla e-mailek - Számlák és Számlázási emlékeztetők";
$_LANG['clientareacontactsemailsproduct'] = "Termék e-mailek - Rendelés részletei, Üdvözlő e-mailek, stb...";
$_LANG['clientareacontactsemailssupport'] = "Támogatás e-mailek - Engedélyezi ennek a felhasználónak, hogy hibajegyet nyisson a fiókodban";
$_LANG['clientareacountry'] = "Ország";
$_LANG['clientareacurrentsecurityanswer'] = "Kérjük, adja meg az aktuális választ";
$_LANG['clientareacurrentsecurityquestion'] = "Kérjük, válassza ki a jelenlegi biztonsági kérdését";
$_LANG['clientareadeletecontact'] = "Kapcsolat törlése";
$_LANG['clientareadeletecontactareyousure'] = "Biztosan törölni szeretné ezt a kapcsolatot?";
$_LANG['clientareadescription'] = "Előfizetői fiók megtekintése és frissítése";
$_LANG['clientareadisklimit'] = "Tárhely korlát";
$_LANG['clientareadiskusage'] = "Tárhely használat";
$_LANG['clientareadomainexpirydate'] = "Lejárati Dátum";
$_LANG['clientareadomainnone'] = "Nincsen nálunk regisztrált domain neve";
$_LANG['clientareaemail'] = "E-mail cím";
$_LANG['clientareaemails'] = "E-mail üzeneteim";
$_LANG['clientareaemailsdate'] = "Küldés dátuma";
$_LANG['clientareaemailsintrotext'] = "Az alábbiakban láthatja az összes általunk küldött üzenetet. Így könnyen elolvashatja bármelyik, a fiókjával kapcsolatos e-mailt, ha esetleg elvesztené az üzeneteit.";
$_LANG['clientareaemailssubject'] = "Üzenet tárgya";
$_LANG['clientareaerroraddress1'] = "Nem adta meg a címét (első sor)";
$_LANG['clientareaerroraddress12'] = "A cím csak betűket, számokat és szóközöket tartalmazhat";
$_LANG['clientareaerrorbannedemail'] = "Nem engedélyezett a felhasználók számára az az e-mail cím szolgáltató amit megadott. Kérem, próbáljon meg egy másik címet.";
$_LANG['clientareaerrorcity'] = "Nem adott meg várost";
$_LANG['clientareaerrorcity2'] = "A város csak betűket és szóközöket tartalmazhat";
$_LANG['clientareaerrorcountry'] = "Kérjük, válassza ki az országot a legördülő listából";
$_LANG['clientareaerroremail'] = "Nem adta meg az e-mail címét";
$_LANG['clientareaerroremailinvalid'] = "A megadott e-mail cím nem érvényes";
$_LANG['clientareaerrorfirstname'] = "Nem adta meg a keresztnevét";
$_LANG['clientareaerrorfirstname2'] = "A Keresztnév csak betűket tartalmazhat";
$_LANG['clientareaerrorisrequired'] = "kötelező";
$_LANG['clientareaerrorlastname'] = "Nem adta meg a vezetéknevét";
$_LANG['clientareaerrorlastname2'] = "A vezetéknév csak betűket tartalmazhat";
$_LANG['clientareaerroroccured'] = "Hiba történt, kérem, próbálja meg később.";
$_LANG['clientareaerrorpasswordconfirm'] = "Nem erősítette meg a jelszavát";
$_LANG['clientareaerrorpasswordnotmatch'] = "Az általad megadott jelszavak nem egyeznek";
$_LANG['clientareaerrorphonenumber'] = "Nem adta meg a telefonszámát";
$_LANG['clientareaerrorphonenumber2'] = "A telefonszám nem érvényes";
$_LANG['clientareaerrorpostcode'] = "Nem adta meg az irányítószámát";
$_LANG['clientareaerrorpostcode2'] = "Az irányítószám csak betűket, számokat és szóközöket tartalmazhat";
$_LANG['clientareaerrors'] = "A következő hibák történtek:";
$_LANG['clientareaerrorstate'] = "Nem adta meg megyéjét";
$_LANG['clientareaexpired'] = "Lejárt";
$_LANG['clientareafirstname'] = "Keresztnév";
$_LANG['clientareafraud'] = "Csalás";
$_LANG['clientareafullname'] = "Ügyfél neve";
$_LANG['clientareaheader'] = "Üdvözöljük az ügyfélfiókjában, ahol a fiókját kezelheti. Itt könnyedén tájékozódhat előfizetései állapotáról, nyitott ügyfélszolgálati bejelentéseiről és számláiról. Győződjön meg róla, hogy naprakészek a kapcsolattartási adatai.";
$_LANG['clientareahostingaddons'] = "Kiegészítők";
$_LANG['clientareahostingaddonsintro'] = "Önnek a következő kiegészítői vannak ehhez a termékhez.";
$_LANG['clientareahostingaddonsview'] = "Megnéz";
$_LANG['clientareahostingamount'] = "Összeg";
$_LANG['clientareahostingdomain'] = "Domain";
$_LANG['clientareahostingnextduedate'] = "Következő teljesítés határideje";
$_LANG['clientareahostingpackage'] = "Csomag";
$_LANG['clientareahostingregdate'] = "Regisztráció dátuma";
$_LANG['clientarealastname'] = "Vezetéknév";
$_LANG['clientarealastupdated'] = "Legutóbb frissítve";
$_LANG['clientarealeaveblank'] = "Hagyja üresen, amíg nem szeretné lecserélni a jelszavát.";
$_LANG['clientareamodifydomaincontactinfo'] = "Domain kapcsolati információk módosítása";
$_LANG['clientareamodifynameservers'] = "Névszerverek módosítása";
$_LANG['clientareamodifywhoisinfo'] = "WHOIS kapcsolati információk módosítása";
$_LANG['clientareanameserver'] = "Névszerver";
$_LANG['clientareanavaddcontact'] = "Új kapcsolattartó hozzáadása";
$_LANG['clientareanavchangecc'] = "Hitelkártya-adatok módosítása";
$_LANG['clientareanavchangepw'] = "Jelszó módosítása";
$_LANG['clientareanavdetails'] = "Adataim";
$_LANG['clientareanavdomains'] = "Domainjeim";
$_LANG['clientareanavhome'] = "Főoldal";
$_LANG['clientareanavlogout'] = "Kijelentkezés";
$_LANG['clientareanavorder'] = "További termékek rendelése";
$_LANG['clientareanavsecurityquestions'] = "Biztonsági kérdés megváltoztatása";
$_LANG['clientareanavservices'] = "Szolgáltatásaim";
$_LANG['clientareanavsupporttickets'] = "Hibajegyeim";
$_LANG['clientareanocontacts'] = "Nem találhatók kapcsolatok";
$_LANG['clientareapassword'] = "Jelszó";
$_LANG['clientareapending'] = "Függőben";
$_LANG['clientareapendingtransfer'] = "Függőben lévő áthozatal";
$_LANG['clientareaphonenumber'] = "Telefonszám";
$_LANG['clientareapostcode'] = "Irányítószám";
$_LANG['clientareaproductdetails'] = "Termék Részletek";
$_LANG['clientareaproducts'] = "Termékeim &amp; Szolgáltatásaim";
$_LANG['clientareaproductsnone'] = "Nincsenek megrendelt termékek/szolgáltatások";
$_LANG['clientarearegistrationperiod'] = "Regisztrációs időszak";
$_LANG['clientareasavechanges'] = "Módosítások mentése";
$_LANG['clientareasecurityanswer'] = "Kérjük, adja meg a választ";
$_LANG['clientareasecurityconfanswer'] = "Kérjük, erősítse meg a választ";
$_LANG['clientareasecurityquestion'] = "Kérem, válasszon ki egy biztonsági kérdést";
$_LANG['clientareaselectcountry'] = "Válasszon országot";
$_LANG['clientareasetlocking'] = "Zárolás beállítása";
$_LANG['clientareastate'] = "Állam/Megye/Régió";
$_LANG['clientareastatus'] = "Állapot";
$_LANG['clientareasuspended'] = "Felfüggesztve";
$_LANG['clientareaterminated'] = "Megszűntetve";
$_LANG['clientareaticktoenable'] = "Engedélyezéshez pipálja be.";
$_LANG['clientareatitle'] = "Ügyfélfiók";
$_LANG['clientareaunlimited'] = "Korlátlan";
$_LANG['clientareaupdatebutton'] = "Frissít";
$_LANG['clientareaupdateyourdetails'] = "Adatok frissítése";
$_LANG['clientareaused'] = "Használt";
$_LANG['clientareaviewaddons'] = "Elérhető kiegészítők megtekintése";
$_LANG['clientareaviewdetails'] = "Részletek megtekintése";
$_LANG['clientlogin'] = "Ügyfél Bejelentkezés";
$_LANG['clientregisterheadertext'] = "Kérjük, töltse ki az alábbi mezőket új fiók létrehozásához.";
$_LANG['clientregistertitle'] = "Regisztráció";
$_LANG['clientregisterverify'] = "Regisztráció ellenőrzése";
$_LANG['clientregisterverifydescription'] = "Kérjük, adja meg az alábbi képen látható ellenőrző kódot. Erre azért van szükség, hogy megakadályozzuk az automatikus regisztrációkat.";
$_LANG['clientregisterverifyinvalid'] = "Hibás ellenőrzőkód";
$_LANG['closewindow'] = "Ablak bezárása";
$_LANG['completeorder'] = "Megrendelés befejezése";
$_LANG['confirmnewpassword'] = "Új jelszó megerősítése";
$_LANG['contactemail'] = "E-mail";
$_LANG['contacterrormessage'] = "Nem adott meg üzenetet";
$_LANG['contacterrorname'] = "Nem adta meg a nevét";
$_LANG['contacterrorsubject'] = "Nem adott meg tárgyat";
$_LANG['contactheader'] = "Ha rendelés előtti kérdése van, azt az alábbi űrlapon küldheti el nekünk.";
$_LANG['contactmessage'] = "Üzenet";
$_LANG['contactname'] = "Név";
$_LANG['contactsend'] = "Üzenet küldése";
$_LANG['contactsent'] = "Üzenet elküldve";
$_LANG['contactsubject'] = "Tárgy";
$_LANG['contacttitle'] = "Vásárlás előtti kérdések";
$_LANG['continueshopping'] = "Vásárlás folytatása";
$_LANG['creditcard'] = "Fizetés hitelkártyával";
$_LANG['creditcard3dsecure'] = "A csalások megelőzésével kapcsolatos intézkedések részeként, most meg kérjük, hogy hajtson végre egy ellenőrzést a Visa vagy Mastercard BiztonságiKód szolgáltatással a fizetés befejezéséhez..<br /><br />Ne kattintson a frissítés vagy a Vissza gombra, vagy a tranzakció megszakad vagy törlésre kerül.";
$_LANG['creditcardcardexpires'] = "Lejárat dátuma";
$_LANG['creditcardcardissuenum'] = "Kibocsátás dátuma";
$_LANG['creditcardcardnumber'] = "Kártya száma";
$_LANG['creditcardcardstart'] = "Kibocsátás dátuma";
$_LANG['creditcardcardtype'] = "Kártya típusa";
$_LANG['creditcardccvinvalid'] = "A kártya CVV száma szükséges";
$_LANG['creditcardconfirmation'] = "Köszönöm! Az új kártyainformációk elfogadásra kerültek és az első fizetés megtörtént. Önnek egy visszaigazoló e-mail lett küldve erről.";
$_LANG['creditcardcvvnumber'] = "CVV/CVC2 Szám";
$_LANG['creditcardcvvwhere'] = "Hol találom meg?";
$_LANG['creditcarddeclined'] = "A megadott hitelkártya adatokat elutasították. Kérem, próbáljon ki egy másik kártyát, vagy lépjen kapcsolatba ügyfélszolgálatunkkal.";
$_LANG['creditcarddetails'] = "Hitelkártya adatok";
$_LANG['creditcardenterexpirydate'] = "Nem adta meg a kártya érvényességi idejét";
$_LANG['creditcardenternewcard'] = "Írja be az új kártyainformációkat.";
$_LANG['creditcardenternumber'] = "Nem adta meg a kártya számát";
$_LANG['creditcardinvalid'] = "A megadott hitelkártya-adatok érvénytelenek. Kérjük, próbáljon ki egy másik kártyát, vagy lépjen kapcsolatba velünk.";
$_LANG['creditcardnumberinvalid'] = "A megadott hitelkártya szám érvénytelen";
$_LANG['creditcardsecuritynotice'] = "Minden itt megadott adata biztonságosan és titkosítva lett leküldve, hogy csökkentsük a csalás kockázatát";
$_LANG['creditcarduseexisting'] = "Meglévő kártya használata";
$_LANG['customfieldvalidationerror'] = "érvénytelen érték";
$_LANG['days'] = "Nap";
$_LANG['defaultbillingcontact'] = "Alapértelmezett Számlázási Kapcsolat";
$_LANG['domainalternatives'] = "Próbálja ki ezeket az alternatívákat:";
$_LANG['domainavailable'] = "Elérhető! Rendelje meg most!";
$_LANG['domainavailable1'] = "Gratulálunk!";
$_LANG['domainavailable2'] = "Elérhető!";
$_LANG['domainavailableexplanation'] = "A domain regisztráláshoz kattintson az alábbi linkre";
$_LANG['domainbulksearch'] = "Tömeges Domain Keresés";
$_LANG['domainbulksearchintro'] = "A tömeges valósidejű domain név kereső lehetővé teszi, hogy legfeljebb 20 domaint keressen egyszerre. Írja be a domain neveket az alábbi mezőbe, soronként egyet - kérem, ne írja be a domainek elé a www. vagy http:// előtagot.";
$_LANG['domainbulktransferdescription'] = "Még ma át tudja hozzánk meglévő domanjeit. A kezdéshez egyszerűen írja be a domaineket alább, soronként egyet - kérem, ne írja be a domainek elé a www. vagy http:// előtagot";
$_LANG['domainbulktransfersearch'] = "Tömeges Domain Áthozatal";
$_LANG['domaincheckerdescription'] = "Itt ellenőrizheti, hogy egy domain név szabad-e";
$_LANG['domaincontactinfo'] = "Kapcsolati adatok";
$_LANG['domaincurrentrenewaldate'] = "Jelenlegi megújítás dátuma";
$_LANG['domaindnsaddress'] = "Cím";
$_LANG['domaindnshostname'] = "Hosztnév";
$_LANG['domaindnsmanagement'] = "DNS-kezelés";
$_LANG['domaindnsmanagementdesc'] = "A domained kipontolása egy weboldalra IP cím pontolással, vagy továbbítása egy másik oldalra, vagy kipontolása egy ideiglenes oldalra (ez nevezzük Parkoltatásnak), és így tovább. Ezek a rekordokat úgy is ismeheted mint aldomain.";
$_LANG['domaindnsrecordtype'] = "Rekord Típus";
$_LANG['domainemailforwarding'] = "Email átirányítás";
$_LANG['domainemailforwardingdesc'] = "Ha az E-mail Továbbító Szerver észleli, hogy a Továbbításra kijelölt e-mail cím érvénytelen, automatikus letiltja a továbbítást. Kérem, ellenőrizze a Továbbításra kiejlölt e-mail címet mielőtt újra engedélyezné. A változások a meglévő továbbító rekordoknál lehet, hogy csak 1 óra múlva lépnek érvénybe.";
$_LANG['domainemailforwardingforwardto'] = "Továbbítás";
$_LANG['domainemailforwardingprefix'] = "Előtag";
$_LANG['domaineppcode'] = "EPP kód";
$_LANG['domaineppcodedesc'] = "Ezt szükséges megszerezni a jelenlegi regisztrátortól azonosításra";
$_LANG['domaineppcoderequired'] = "Meg kell adnia az EPP kódot a";
$_LANG['domainerror'] = "Hiba történt a regisztrátorhoz való kapcsolódás közben. Kérem, próbálja meg később újra.";
$_LANG['domainerrornodomain'] = "Kérem írjon be egy érvényes domain nevet";
$_LANG['domainerrortoolong'] = "A beírt domain név túl hosszú. Egy domain maximum 67 karakter hosszú lehet.";
$_LANG['domaingeteppcode'] = "EPP kód kérés";
$_LANG['domaingeteppcodeemailconfirmation'] = "Az EPP kódkérés sikeres volt! A kód el lett küldve a domain regisztrátor e-mail címére.";
$_LANG['domaingeteppcodeexplanation'] = "Az EPP kód alapvető egy jelszó a domain névhez. Ez egy biztonsági intézkedés, ami biztosítja csak a domain név tulajdonos tudja áthozni a domain nevet. Szüksége lesz rá, ha át szeretné vinne a domaint egy másik regisztrátorhoz.";
$_LANG['domaingeteppcodefailure'] = "Hiba történt az EPP kód keresése során:";
$_LANG['domaingeteppcodeis'] = "A domained EPP kódja:";
$_LANG['domainidprotection'] = "ID Védelem";
$_LANG['domainintrotext'] = "Írjon be egy domaint és egy végződést (tld) a szöveges mezőbe amit használni szeretne és kattintson a Keresés-re, hogy ellenőrizhesse a domain elérhető és megvásárolható";
$_LANG['domainlookupbutton'] = "Keresés";
$_LANG['domainmanagementtools'] = "Menedzsment eszközök";
$_LANG['domainminyears'] = "Min. év";
$_LANG['domainmoreinfo'] = "Még több információ";
$_LANG['domainname'] = "Domain Név";
$_LANG['domainnameserver1'] = "Névszerver 1";
$_LANG['domainnameserver2'] = "Névszerver 2";
$_LANG['domainnameserver3'] = "Névszerver 3";
$_LANG['domainnameserver4'] = "Névszerver 4";
$_LANG['domainnameserver5'] = "Névszerver 5";
$_LANG['domainnameservers'] = "Névszerverek";
$_LANG['domainordernow'] = "Rendelje meg most!";
$_LANG['domainorderrenew'] = "Rendelés megújítása";
$_LANG['domainprice'] = "Ár";
$_LANG['domainregisterns'] = "Névszerver regisztráció";
$_LANG['domainregisternscurrentip'] = "Jelenlegi IP cím";
$_LANG['domainregisternsdel'] = "Névszerver törlése";
$_LANG['domainregisternsdelsuccess'] = "A névszerver sikeresen törölve";
$_LANG['domainregisternsexplanation'] = " Itt létrehozhatja és kezelheti saját névszervereit a domainhez (pl.: NS1.tedomained.hu, NS2.tedomained.hu...).";
$_LANG['domainregisternsip'] = "IP cím";
$_LANG['domainregisternsmod'] = "Névszerver IP címének módosítása";
$_LANG['domainregisternsmodsuccess'] = "A névszerver sikeresen módosítva";
$_LANG['domainregisternsnewip'] = "Új IP cím";
$_LANG['domainregisternsns'] = "Névszerver";
$_LANG['domainregisternsreg'] = "Névszerver név regisztrálása";
$_LANG['domainregisternsregsuccess'] = "A névszerver sikeresen regisztrálva";
$_LANG['domainregistrantchoose'] = "Válassza ki, melyik kapcsolattartót szeretné itt használni";
$_LANG['domainregistrantinfo'] = "Domain regisztrátor információ";
$_LANG['domainregistrarlock'] = "Regisztrátor zár";
$_LANG['domainregistrarlockdesc'] = "Engedélyezze a regisztrátor zárt (ajánlott). A jogosulatlan átvitel megelőzhető, ha be van állítva.";
$_LANG['domainregistration'] = "Domain regisztráció";
$_LANG['domainregistryinfo'] = "Domain Regisztrátori Információk";
$_LANG['domainregnotavailable'] = "N/A";
$_LANG['domainrenew'] = "Domain megújítása";
$_LANG['domainrenewal'] = "Domain megújítás";
$_LANG['domainrenewalprice'] = "Megújítása";
$_LANG['domainrenewdesc'] = "Biztosítsa domainjeit azzal, hogy több évet ad hozzájuk. Válassza ki, hány évre szeretné megújítani, majd kattintson a folytatáshoz..";
$_LANG['domainsautorenew'] = "Automatikus megújítás";
$_LANG['domainsautorenewdisable'] = "Automatikus megújítás letiltása";
$_LANG['domainsautorenewdisabled'] = "Letiltva";
$_LANG['domainsautorenewdisabledwarning'] = "FIGYELEM! Ennek a domainnek az automatikus megújítása le van tiltva.<br /> A domain le fog járni és inaktívvá válik a jelenlegi határidő végén, ha csak manuálisan meg nem újítja.";
$_LANG['domainsautorenewenable'] = "Automatikus Megújítás Engedélyezése";
$_LANG['domainsautorenewenabled'] = "Engedélyezve";
$_LANG['domainsautorenewstatus'] = "Jelenlegi állapot";
$_LANG['domainsimplesearch'] = "Egyszerű Domain Kereső";
$_LANG['domainspricing'] = "Domain árak";
$_LANG['domainsregister'] = "Regisztrál";
$_LANG['domainsrenew'] = "Megújít";
$_LANG['domainsrenewnow'] = "Megújít most";
$_LANG['domainstatus'] = "Állapot";
$_LANG['domainstransfer'] = "Áthoz";
$_LANG['domaintitle'] = "Domain kereső";
$_LANG['domaintld'] = "TLD - végződés";
$_LANG['domaintransfer'] = "Domain Áthozatal";
$_LANG['domainunavailable'] = "Nem elérhető";
$_LANG['domainunavailable1'] = "Sajnálom!";
$_LANG['domainunavailable2'] = "már foglalt!";
$_LANG['domainviewwhois'] = "whois jelentés megtekintése";
$_LANG['downloaddescription'] = "Leírás";
$_LANG['downloadloginrequired'] = "Hozzáférés megtagadva - Be kell jelentkezni a fájl letöltéséhez";
$_LANG['downloadname'] = "Letöltés";
$_LANG['downloadpurchaserequired'] = "Hozzáférés megtagadva – Meg kell vásárolni az adott terméket mielőtt letöltené azt";
$_LANG['downloadscategories'] = "Kategóriák";
$_LANG['downloadsdescription'] = "Tekintse meg letöltési könyvtárunkat.";
$_LANG['downloadsfiles'] = "Fájlok";
$_LANG['downloadsfilesize'] = "Fájlméret";
$_LANG['downloadsintrotext'] = "A letöltési könyvtár tartalmazza az összes kézikönyvet, programot és egyéb fájlokat amire szüksége lehet weboldala létrehozásához és működtetéséhez..";
$_LANG['downloadspopular'] = "Legnépszerűbb letöltések";
$_LANG['downloadsnone'] = "Nincs megjeleníthető Letöltések";
$_LANG['downloadstitle'] = "Letöltések";
$_LANG['email'] = "E-mail";
$_LANG['emptycart'] = "A kosár üres";
$_LANG['existingpassword'] = "Jelenlegi jelszó";
$_LANG['existingpasswordincorrect'] = "Jelenlegi jelszava helytelen volt";
$_LANG['firstpaymentamount'] = "Az első kifizetés összege";
$_LANG['flashtutorials'] = "Flash Tutorialok";
$_LANG['flashtutorialsdescription'] = "Ide kattintva megtekintheti a tutorialokat, amelyek megmutatják Önnek, hogyan használhatja a tárhelykezelő panelt.";
$_LANG['flashtutorialsheadertext'] = "Flash tutorialjaink segítenek, hogy teljes mértékben ki tudja használni tárhelye kezelőfelütetét. Válasszon egy feladatot az alábbiak közül amelyek megmutatják lépésről lépésre hogyan fejezheti be.";
$_LANG['forwardingtogateway'] = "Kérem várjon, amíg átirányítjuk Önt a kiválasztott fizetési átjáróhoz...";
$_LANG['globalsystemname'] = "Kezdőlap";
$_LANG['globalyouarehere'] = "Ön itt van";
$_LANG['go'] = "Tovább";
$_LANG['headertext'] = "Üdvözöljük támogató webhelyünkön.";
$_LANG['hometitle'] = "Főoldal";
$_LANG['imagecheck'] = "Kérjük, írja be a képen látható biztonsági kódot - ez szükséges, hogy megakadályozzuk az automatikus kérelmeket";
$_LANG['invoiceaddcreditamount'] = "Írja be az alkalmazandó összeget";
$_LANG['invoiceaddcreditapply'] = "Kredit alkalmazása";
$_LANG['invoiceaddcreditdesc1'] = "Az Ön kredit egyenleg";
$_LANG['invoiceaddcreditdesc2'] = "Az alábbi űrlap használatával ez alkalmazható a számlára.";
$_LANG['invoiceaddcreditoverbalance'] = "Nem alkalmazhat több kreditet mint a jelenlegi egynelege";
$_LANG['invoiceaddcreditovercredit'] = "Nem alkalmazhat több kreditet mint amennyi a fiókjában van";
$_LANG['invoicenumber'] = "Számla #:";
$_LANG['invoiceofflinepaid'] = "Az Offline hitelkártyás fizetéseket manuálsan dolgozzuk fel.<br /> Ön majd kapni fog egy visszaigazoló e-mailt, ha a fizetés feldolgozásra került.";
$_LANG['invoicerefnum'] = "Hivatkozási szám";
$_LANG['invoices'] = "Számláim";
$_LANG['invoicesamount'] = "Összeg";
$_LANG['invoicesattn'] = "ATTN";
$_LANG['invoicesbacktoclientarea'] = "&laquo; Vissza az ügyfél fiókba";
$_LANG['invoicesbalance'] = "Egyenleg";
$_LANG['invoicesbefore'] = "előtt";
$_LANG['invoicescancelled'] = "Visszaondva";
$_LANG['invoicescollections'] = "Gyűjtemények";
$_LANG['invoicescredit'] = "Kredit";
$_LANG['invoicesdatecreated'] = "Kiállítás dátuma";
$_LANG['invoicesdatedue'] = "Esedékesség dátuma";
$_LANG['invoicesdescription'] = "Leírás";
$_LANG['invoicesdownload'] = "Letöltés";
$_LANG['invoicesdue'] = "Fizetendő számlák";
$_LANG['invoiceserror'] = "Hiba történt. Kérjük, próbálja újra.";
$_LANG['invoicesinvoicedto'] = "Vásárló";
$_LANG['invoicesinvoicenotes'] = "Számla megjegyzések";
$_LANG['invoicesnoinvoices'] = "Nincsenek számlák";
$_LANG['invoicesnotes'] = "Megjegyzések";
$_LANG['invoicesoutstandinginvoices'] = "Kifizetetlen számlák";
$_LANG['invoicespaid'] = "Fizetett";
$_LANG['invoicespaynow'] = "Fizetés most";
$_LANG['invoicespayto'] = "Számla Kibocsátó";
$_LANG['invoicesrefunded'] = "Visszatérített";
$_LANG['invoicesstatus'] = "Állapot";
$_LANG['invoicessubtotal'] = "Részösszeg";
$_LANG['invoicestax'] = "Fizentedő adó";
$_LANG['invoicestaxindicator'] = "Adózott terméket jelez.";
$_LANG['invoicestitle'] = "Számla #";
$_LANG['invoicestotal'] = "Összesen";
$_LANG['invoicestransactions'] = "Tranzakciók";
$_LANG['invoicestransamount'] = "Összeg";
$_LANG['invoicestransdate'] = "Tranzakció dátuma";
$_LANG['invoicestransgateway'] = "Fizetési mód";
$_LANG['invoicestransid'] = "Tranzakció AZ";
$_LANG['invoicestransnonefound'] = "Nem található ehhez kapcsolódó tranzakció";
$_LANG['invoicesunpaid'] = "Kifizetetlen";
$_LANG['invoicesview'] = "Számla megtekintése";
$_LANG['jobtitle'] = "Beosztás";
$_LANG['kbsuggestions'] = "Tudásbázis javaslatok";
$_LANG['kbsuggestionsexplanation'] = "Az alábbi cikkek találhatók a tudásbázisban, amelyek választ adhatnak kérdéseire. Kérjük, nézze át a javaslatokat mielőtt javaslatát benyújtaná";
$_LANG['knowledgebasearticles'] = "Cikkek";
$_LANG['knowledgebasecategories'] = "Kategóriák";
$_LANG['knowledgebasedescription'] = "A tudásbázisban választ találhat a leggyakrabban felmerülő kérdésekre";
$_LANG['knowledgebasefavorites'] = "Hozzáadás a Kedvencekhez";
$_LANG['knowledgebasehelpful'] = "Hasznosnak találta ezt a választ?";
$_LANG['knowledgebaseintrotext'] = "A Tudásbázis kategóriák szerint van elrendezve. Válasszon egy kategóriát alábbiak közül, vagy keressen a Tudásbázisban.";
$_LANG['knowledgebasemore'] = "Még több";
$_LANG['knowledgebaseno'] = "Nem";
$_LANG['knowledgebasenoarticles'] = "Nem találhatók cikkek";
$_LANG['knowledgebasenorelated'] = "Nincsenek Kapcsolódó cikkek";
$_LANG['knowledgebasepopular'] = "Legnépszerűbb cikkek";
$_LANG['knowledgebaseprint'] = "Cikk nyomtatása";
$_LANG['knowledgebaserating'] = "Értékelés:";
$_LANG['knowledgebaseratingtext'] = "felhasználó találta ezt hasznosnak";
$_LANG['knowledgebaserelated'] = "Kapcsolódó cikkek";
$_LANG['knowledgebasesearch'] = "Keresés";
$_LANG['knowledgebasetitle'] = "Tudásbázis";
$_LANG['knowledgebaseviews'] = "Megtekintve";
$_LANG['knowledgebasevote'] = "Szavazás";
$_LANG['knowledgebasevotes'] = "Szavazat";
$_LANG['knowledgebaseyes'] = "Igen";
$_LANG['language'] = "Nyelv";
$_LANG['latefee'] = "Késedelmi díj";
$_LANG['latefeeadded'] = "Hozzáadva";
$_LANG['latestannouncements'] = "Legutóbbi hírek";
$_LANG['loginbutton'] = "Bejelentkezés";
$_LANG['loginemail'] = "E-mail cím";
$_LANG['loginforgotten'] = "Elfelejtette a jelszavát?";
$_LANG['loginforgotteninstructions'] = "Egy új jelszó kérése";
$_LANG['loginincorrect'] = "Hibás bejelentkezési adatok. Kérjük, próbálja újra.";
$_LANG['loginintrotext'] = "Az oldal eléréséhez be kell jelentkeznie. Ezek a belépési adatok különböznek az egyes szolgáltatások hozzáférési adataitól.";
$_LANG['loginpassword'] = "Jelszó";
$_LANG['loginrememberme'] = "Emlékezzen rám";
$_LANG['logoutcontinuetext'] = "Kattintson ide a folytatáshoz.";
$_LANG['logoutsuccessful'] = "Ön sikeresen kijelentkezet.";
$_LANG['logouttitle'] = "Kijelentkezés";
$_LANG['maxmind_anonproxy'] = "Nem engedélyezzük rendelés leadását Anonym Proxy segítségével";
$_LANG['maxmind_callingnow'] = "Most egy automatikus hívást fogunk intézni az Ön telefonjára. Ez része a csalás elleni ellenőrző intézkedéseknek. Ön kap egy 4-jegyű biztonsági kódot, amelyet  alább meg kell adnia megrendelése befejezéséhez.";
$_LANG['maxmind_countrymismatch'] = "Az IP cím országa és a számlázási címnek megadott ország nem egyezik meg, így nem tudjuk elfogadni az Ön rendelését";
$_LANG['maxmind_error'] = "Hiba";
$_LANG['maxmind_faileddescription'] = "A megadott kód helytelen. Ha úgy érzi, hogy ez egy hiba miatt lépett fel, kérjük, lépjen kapcsolatba ügyfélszolgálatunkkal amilyen gyorsan csak lehetséges.";
$_LANG['maxmind_highfraudriskscore'] = "A MaxMind úgy ítélte meg, hogy az Ön rendelése magas kockázatú, ezért manuális ellenőrzésre szorul.<br /><br />Ha úgy érzi, hogy valami hiba folytán kapta tőlünk ezt a levelet, fogadja el bocsánat kérésünket és <a href=\"submitticket.php\"> küldjön egy hibajegyet</a> az ügyfélszolgálatunkra. Köszönjük.";
$_LANG['maxmind_highriskcountry'] = "Sajnálatos módon nem áll módunkban elfogadni az Ön rendelését, mert sok csalás volt az Ön országából. Ha azt szeretné, hogy alternatív módon gondoskodjunk az Ön fizetésérlő, kérjük lépjen kapcsolatba velünk.";
$_LANG['maxmind_incorrectcode'] = "Hibás kód";
$_LANG['maxmind_pincode'] = "Pin Kód";
$_LANG['maxmind_rejectemail'] = "Nem engedélyezzük azokat a rnegrendeléseket amelyek ingyenes e-mail címet használnak, kérjük, próbálj a meg újra egy másik e-mail cím használatával";
$_LANG['maxmind_title'] = "MaxMind";
$_LANG['more'] = "Még több";
$_LANG['morechoices'] = "Még több lehetőség";
$_LANG['networkissuesaffecting'] = "Érinti";
$_LANG['networkissuesaffectingyourservers'] = "Figyelem: Azokat a problémákat, amelyek azokat a szervereket érintik, melyen az Ön fiókja is található, arany színű háttérrel emeltük ki.";
$_LANG['networkissuesdate'] = "Dátum";
$_LANG['networkissuesdescription'] = "Tudnivalók a jelenlegi és ütemezett hálózati üzemszünetekről";
$_LANG['networkissueslastupdated'] = "Utoljára frissítve";
$_LANG['networkissuesnonefound'] = "Nem találhatók hálózati problémák";
$_LANG['networkissuespriority'] = "Prioritás";
$_LANG['networkissuesprioritycritical'] = "Kritikus";
$_LANG['networkissuespriorityhigh'] = "Magas";
$_LANG['networkissuesprioritylow'] = "Alacsony";
$_LANG['networkissuesprioritymedium'] = "Közepes";
$_LANG['networkissuesstatusinprogress'] = "Folyamatban";
$_LANG['networkissuesstatusinvestigating'] = "Vizsgálat";
$_LANG['networkissuesstatusopen'] = "Nyitott";
$_LANG['networkissuesstatusoutage'] = "Üzemszünet";
$_LANG['networkissuesstatusreported'] = "Bejelentett";
$_LANG['networkissuesstatusresolved'] = "Megoldott";
$_LANG['networkissuesstatusscheduled'] = "Tervezett";
$_LANG['networkissuestitle'] = "Hálózati problémák";
$_LANG['networkissuestypeother'] = "Egyéb";
$_LANG['networkissuestypeserver'] = "Szerver";
$_LANG['networkissuestypesystem'] = "Rendszer";
$_LANG['newpassword'] = "Új jelszó";
$_LANG['nextpage'] = "Következő oldal";
$_LANG['no'] = "Nem";
$_LANG['nocarddetails'] = "Nem létező kártya adatok";
$_LANG['none'] = "Nincs";
$_LANG['norecordsfound'] = "Nincs találat";
$_LANG['or'] = "vagy";
$_LANG['orderadditionalrequiredinfo'] = "További szükséges információk";
$_LANG['orderaddon'] = "Kiegészítő";
$_LANG['orderaddondescription'] = "Ezek a kiegészítők léteznek ehhez a termékhez. Válassza ki a kívánt kiegészítőt.";
$_LANG['orderavailable'] = "Elérhető";
$_LANG['orderavailableaddons'] = "Kattintson ide az elérhető extrák megtekintéséhez";
$_LANG['orderbillingcycle'] = "Számlázási ciklus";
$_LANG['ordercategories'] = "Kategóriák";
$_LANG['orderchangeaddons'] = "Kiegészítők módosítáa";
$_LANG['orderchangeconfig'] = "Beállítási lehetősége módosítása";
$_LANG['orderchangedomain'] = "Domain Módosítása";
$_LANG['orderchangenameservers'] = "Csak névszerverek módosítása";
$_LANG['orderchangeproduct'] = "Termék módosítása";
$_LANG['ordercheckout'] = "Megrendelés";
$_LANG['orderchooseaddons'] = "Termék kiegészítő választása";
$_LANG['orderchooseapackage'] = "Válasszon csomagot";
$_LANG['ordercodenotfound'] = "A beírt promóciós kód nem létezik.";
$_LANG['ordercompletebutnotpaid'] = "Figyelem! A rendelés befejezve, de még nincs kifizetve és aktiválva.<br />Kattintson a linkre a számla megtekintéséhez és a fizetéshez.";
$_LANG['orderconfigpackage'] = "Konfigurálható beállítások";
$_LANG['orderconfigure'] = "Konfigurálás";
$_LANG['orderconfirmation'] = "Rendelés megerősítés";
$_LANG['orderconfirmorder'] = "Rendelés megerősítése";
$_LANG['ordercontinuebutton'] = "Kattintson ide a folytatáshoz >>";
$_LANG['orderdesc'] = "Leírás";
$_LANG['orderdescription'] = "Új megrendelés leadása";
$_LANG['orderdiscount'] = "Kedvezmény";
$_LANG['orderdomain'] = "Domain";
$_LANG['orderdomainoption1part1'] = "Kérem, hogy";
$_LANG['orderdomainoption1part2'] = "regisztráljon egy domain nevet részemre.";
$_LANG['orderdomainoption2'] = "Meglévő domain nevem névszervereit módosítom, vagy máshol regisztrálok.";
$_LANG['orderdomainoption3'] = "Szeretném, ha átregisztrálná a domain nevemet a";
$_LANG['orderdomainoption4'] = "Ingyenes aldomaint kérek.";
$_LANG['orderdomainoptions'] = "Domain opciók";
$_LANG['orderdomainregistration'] = "Domain regisztráció";
$_LANG['orderdomainregonly'] = "Domain regisztráció";
$_LANG['orderdomaintransfer'] = "Domain átregisztráció";
$_LANG['orderdontusepromo'] = "Ne használja a Promóciós kódot";
$_LANG['ordererroraccepttos'] = "Kérem, fogadja el a Szerződési Feltételeket";
$_LANG['ordererrordomainalreadyexists'] = "A megadott domain már regisztrálva van nálunk - előbb meg kell szüntetnie, mielőtt újra megrendelné";
$_LANG['ordererrordomaininvalid'] = "A megadott domain érvénytelen";
$_LANG['ordererrordomainnotld'] = "Adja meg a domain végződést (pl.: hu, com, eu)";
$_LANG['ordererrordomainnotregistered'] = "Nem tud olyan domain nevet áthozni, amely nincs regisztrálva";
$_LANG['ordererrordomainregistered'] = "A megadott domain név már használatban van";
$_LANG['ordererrornameserver1'] = "Kérjük adja meg: névszerver 1";
$_LANG['ordererrornameserver2'] = "Kérjük adja meg: névszerver 2";
$_LANG['ordererrornodomain'] = "Nem adta meg a domain nevet";
$_LANG['ordererrorpassword'] = "Nem adott meg jelszót";
$_LANG['ordererrorserverhostnameinuse'] = "A megadott hosztnév már használatban van. Kérjük, válasszon másikat.";
$_LANG['ordererrorservernohostname'] = "Meg kell adnia egy hosztnevet a szerveren";
$_LANG['ordererrorservernonameservers'] = "Meg kell adnia mindkét névszerver előtagját";
$_LANG['ordererrorservernorootpw'] = "Meg kell adnia a kívánt root jelszót";
$_LANG['ordererrorsubdomaintaken'] = "A megadott aldomain már foglalt - próbálja újra";
$_LANG['ordererrortransfersecret'] = "Meg kell adnia a titkosított áthozatalt";
$_LANG['ordererroruserexists'] = "Már létezik egy felhasználó ezzel az e-mail címmel";
$_LANG['orderexistinguser'] = "Meglévő ügyfél vagyok, szeretném ezt a rendelést a fiókomhoz hozzáadni";
$_LANG['orderfailed'] = "A rendelés meghiúsult";
$_LANG['orderfinalinstructions'] = "Ha bármilyen kérdése van a rendelésével kapcsolatban, kérjük, nyisson egy hibajegyet az ügyfélfiókjából és adja meg a rendelése azonosító számát.";
$_LANG['orderfree'] = "INGYENES!";
$_LANG['orderfreedomainappliesto'] = "csak a következő kiegészítőkre alkalmazva";
$_LANG['orderfreedomaindescription'] = "kiválasztott fizetési feltételek";
$_LANG['orderfreedomainonly'] = "Ingyen Domain";
$_LANG['orderfreedomainregistration'] = "Ingyenes domain regisztráció";
$_LANG['ordergotoclientarea'] = "Kattintson ide a fiókjába való belépéshez";
$_LANG['orderinvalidcodeforbillingcycle'] = "Ez a kód nem használható a választott fizetési periódushoz.";
$_LANG['orderlogininfo'] = "Bejelentkezési információk";
$_LANG['orderlogininfopart1'] = "Kérjük, írja be azt a jelszót, amit használni kíván, hogy bejelentkezzen az ügyfélkapura";
$_LANG['orderlogininfopart2'] = ". Ezek a belépési adatok különböznek az egyes szolgáltatások hozzáférési adataitól.";
$_LANG['ordernewuser'] = "Új ügyfél vagyok, új fiókot szeretnék létrehozni";
$_LANG['ordernoproducts'] = "Nem találhatók termékek";
$_LANG['ordernotes'] = "Megjegyzések / Kiegészítő információk";
$_LANG['ordernotesdescription'] = "Itt megadhat bármilyen kiegészítő információt, vagy megjegyzést a rendelésével kapcsolatban...";
$_LANG['ordernowbutton'] = "Megrendelés";
$_LANG['ordernumberis'] = "Az Ön rendelési száma:";
$_LANG['orderpaymentmethod'] = "Fizetési mód";
$_LANG['orderpaymentterm12month'] = "12 hónapos díj";
$_LANG['orderpaymentterm1month'] = "Havidíj";
$_LANG['orderpaymentterm24month'] = "24 hónapos díj";
$_LANG['orderpaymentterm3month'] = "3 hónapos díj";
$_LANG['orderpaymentterm6month'] = "6 hónapos díj";
$_LANG['orderpaymenttermannually'] = "Évente";
$_LANG['orderpaymenttermbiennially'] = "Kétévente";
$_LANG['orderpaymenttermfreeaccount'] = "Ingyenes fiók";
$_LANG['orderpaymenttermmonthly'] = "Havonta";
$_LANG['orderpaymenttermonetime'] = "Egyszeri díj";
$_LANG['orderpaymenttermquarterly'] = "Negyedévente";
$_LANG['orderpaymenttermsemiannually'] = "Félévente";
$_LANG['orderprice'] = "Ár";
$_LANG['orderproduct'] = "Termék/Szolgáltatás";
$_LANG['orderprogress'] = "Folyamatban";
$_LANG['orderpromoexpired'] = "A kuponkód amit megadott már lejárt";
$_LANG['orderpromoinvalid'] = "A kuponkód amit megadott nem használható fel egyetlen elemre sem az Ön megrendelésében";
$_LANG['orderpromomaxusesreached'] = "A megadott kuponkódot már használták";
$_LANG['orderpromotioncode'] = "Kuponkód";
$_LANG['orderpromovalidatebutton'] = "kód érvényesítése";
$_LANG['orderprorata'] = "Pro Rata";
$_LANG['orderreceived'] = "Köszönjük megrendelését. Hamarosan egy megerősítő e-mailt fog kapni.";
$_LANG['orderregisterdomain'] = "Új domain regisztrációja";
$_LANG['orderregperiod'] = "Regisztrációs időszak";
$_LANG['ordersecure'] = "Ez a megrendelőlap biztonságos környezetből származik és segít megvédeni a csalóktól az Ön jelenlegi IP címét";
$_LANG['ordersecure2'] = "már bejelentkezett.";
$_LANG['orderserverhostname'] = "Szerver Hosztnév";
$_LANG['orderservernameservers'] = "Névszerverek";
$_LANG['orderservernameserversdescription'] = "Az itt megadott előtagok meghatározzák az alapértelmezett névszervereket a szervernek pl. ns1.tedomained.com és ns2.tedomained.com";
$_LANG['orderservernameserversprefix1'] = "Előtag 1";
$_LANG['orderservernameserversprefix2'] = "Előtag 2";
$_LANG['orderserverrootpassword'] = "Root Jelszó";
$_LANG['ordersetupfee'] = "Egyszeri díj";
$_LANG['orderstartover'] = "Újrakezdés";
$_LANG['ordersubdomaininuse'] = "A megadott aldomain már használatban van";
$_LANG['ordersubtotal'] = "Részösszeg";
$_LANG['ordersummary'] = "Rendelés összefoglalása";
$_LANG['ordertaxcalculations'] = "Adó számítások";
$_LANG['ordertaxstaterequired'] = "Meg kell adnia az államát az adó kiszámításához";
$_LANG['ordertitle'] = "Rendelés";
$_LANG['ordertos'] = "Általános szolgáltatási feltételek";
$_LANG['ordertosagreement'] = "Elolvastam és elfogadom az";
$_LANG['ordertotalduetoday'] = "Most fizetendő";
$_LANG['ordertotalrecurring'] = "Folyamatosan fizetendő";
$_LANG['ordertransferdomain'] = "Meglévő domain név áthozatala";
$_LANG['ordertransfersecret'] = "Titkos áthozatal";
$_LANG['ordertransfersecretexplanation'] = "Kérjük, adja meg a Titkos Domain Áthozatalt amit a domain név jelenlegi regisztrátorától kaphat meg. ";
$_LANG['orderusesubdomain'] = "Aldomain használata";
$_LANG['orderyears'] = "Éve";
$_LANG['orderyourinformation'] = "Az Ön adatai";
$_LANG['orderyourorder'] = "Megrendelései";
$_LANG['organizationname'] = "Szervezet neve";
$_LANG['outofstock'] = "Elfogyott";
$_LANG['outofstockdescription'] = "Jelenleg kifogytunk ebből a termékből, tehát a rendelések fel lettek függesztve amíg nagyobb készlet nem áll rendelkezésre. További információkért lépjen kapcsolatba velünk.";
$_LANG['page'] = "Oldal";
$_LANG['pageof'] = "/";
$_LANG['please'] = "Kérem";
$_LANG['pleasewait'] = "Kérem várjon...";
$_LANG['presalescontactdescription'] = "Itt felteheti kérdéseit vásárlás előtt";
$_LANG['previouspage'] = "Előző oldal";
$_LANG['proformainvoicenumber'] = "Proforma számla #";
$_LANG['promoexistingclient'] = "Önnek lennie kell egy aktív terméknek/szolgáltatásnak, hogy használni tudja ezt a kódot";
$_LANG['promoonceperclient'] = "Ez a kód csak egyszer használható ügyfelenként";
$_LANG['pwstrengthfail'] = "A megadott jelszó nem elég erős - kérjük, adjon meg egy összetetteb jelszót";
$_LANG['quicknav'] = "Gyors Navigáció";
$_LANG['recordsfound'] = "Találat";
$_LANG['recurring'] = "Ismétlődő";
$_LANG['recurringamount'] = "Ismétlődő összeg";
$_LANG['every'] = "Minden";
$_LANG['registerdomain'] = "Domain Regisztráció";
$_LANG['registerdomaindesc'] = "Írja be a domain nevet amit regisztrálni szeretne és ellenőrizze a domain elérhetőségét.";
$_LANG['registerdomainname'] = "Domain név regisztráció";
$_LANG['relatedservice'] = "Kapcsolódó szolgáltatás";
$_LANG['rssfeed'] = "Hírfolyam";
$_LANG['securityanswerrequired'] = "Meg kell adnia a biztonsági választ";
$_LANG['securitybothnotmatch'] = "Válasza és a megerősítő válasz nem egyezik";
$_LANG['securitycurrentincorrect'] = "Az aktuális kérdés és válasz helytelen";
$_LANG['serverchangepassword'] = "Jelszó módosítása";
$_LANG['serverchangepasswordintro'] = "Itt módosíthatja termékei/szolgáltatásai jelszavát (Megjegyzés: Ez nem befolyásolja a Ügyfél fiók jelszavát)";
$_LANG['serverchangepasswordconfirm'] = "Jelszó megerősítése";
$_LANG['serverchangepasswordenter'] = "Új jelszó megadása";
$_LANG['serverchangepasswordfailed'] = "Jelszó változtatás sikertelen!";
$_LANG['serverchangepasswordsuccessful'] = "Jelszó sikeresen megváltoztatva!";
$_LANG['serverchangepasswordupdate'] = "Frissít";
$_LANG['serverhostname'] = "Hosztnév";
$_LANG['serverlogindetails'] = "Bejelentkezési adatok";
$_LANG['servername'] = "Szerver";
$_LANG['serverns1prefix'] = "NS1 Előtag";
$_LANG['serverns2prefix'] = "NS2 Előtag";
$_LANG['serverpassword'] = "Jelszó";
$_LANG['serverrootpw'] = "Root Jelszó";
$_LANG['serverstatusdescription'] = "Szervereink aktuális állapotának megtekintése";
$_LANG['serverstatusnoservers'] = "Jelenleg nincsen megfigyelhető szerver";
$_LANG['serverstatusnotavailable'] = "Nem elérhető";
$_LANG['serverstatusoffline'] = "Offline";
$_LANG['serverstatusonline'] = "Online";
$_LANG['serverstatusphpinfo'] = "PHP Infó";
$_LANG['serverstatusserverload'] = "Szerver terhelés";
$_LANG['serverstatustitle'] = "Szerverek állapota";
$_LANG['serverstatusuptime'] = "Üzemidő";
$_LANG['serverusername'] = "Felhasználónév";
$_LANG['show'] = "Mutat";
$_LANG['ssladmininfo'] = "Adminisztratív Elérhetőség";
$_LANG['ssladmininfodetails'] = "Az alábbi kapcsolattartási információ nem jelenik meg a tanúsítványon - ezt csak arra használjuk, hogy kapcsolatba lépjünk veled a rendeléssel kapcsoaltban. Az SSL-tanúsítvány és a jövőbeli emlékeztetők lesznek kiküldve az alábbi e-mail címre.";
$_LANG['sslcertapproveremail'] = "Tanúsítvány Jóváhagyó E-mail";
$_LANG['sslcertapproveremaildetails'] = "Most ki kell választania az alábbi lehetőségek közül, hová szeretné küldeni a tanúsítvány jóváhagyási kérelmét.";
$_LANG['sslcertinfo'] = "SSL-tanúsítvány Információ";
$_LANG['pleasechooseone'] = "Kérjük, válasszon egyet...";
$_LANG['sslcerttype'] = "Tanúsítványtípus";
$_LANG['sslconfigcomplete'] = "A konfiguráció teljes";
$_LANG['sslconfigcompletedetails'] = "Az SSL-tanúsítvány konfiguráció befejeződött és el lett küldve a Tanúsítvány hatósághoz érvényesítésre. Önnek kapnia kell egy e-mailt tőlük hamarosan a jóváhagyásról.";
$_LANG['sslconfsslcertificate'] = "SSL-tanúsítvány konfigurálása";
$_LANG['sslcsr'] = "CSR";
$_LANG['sslerrorapproveremail'] = "Ki kell választania egy megerősítő e-mail címet";
$_LANG['sslerrorentercsr'] = "Meg kell adnia a tanúsítvány aláírási kérelmet (CSR)";
$_LANG['sslerrorselectserver'] = "Ki kell választania a szerver típusát";
$_LANG['sslinvalidlink'] = "Érvénytelen link követés. Kérjem, lépjen vissza és próbálja újra.";
$_LANG['sslorderdate'] = "Rendelés dátuma";
$_LANG['sslserverinfo'] = "Szerver információk";
$_LANG['sslserverinfodetails'] = "Érvényes \"CSR\" (tanúsítvány aláírási kérelem)-el kell rendelkezni az SSL-tanúsítvány beállításához. A CSR egy titkosított része egy szövegnek amit a webszerver generál ahol az SSL-tanúsítvány telepítve lesz. Ha még nem rendelkezik CSR-el, generálnia kell egyet, vagy meg kell kérnie tárhelyszolgáltatóját, hogy generáljon egyet Önnek. Továbbá kérjük, győződjön meg róla, hogy helyes adatokat adott meg, mert az SSL-tanúsítvány kiállítása után már nem módosíthatók.";
$_LANG['sslservertype'] = "Web Szerver típus";
$_LANG['sslstatus'] = "Konfiguráció állapota";
$_LANG['statscreditbalance'] = "Fiók kredit egyenleg";
$_LANG['statsdueinvoicesbalance'] = "Esedékes számlák egyenlege";
$_LANG['statsnumdomains'] = "Domainek száma";
$_LANG['statsnumproducts'] = "Termékek/Szolgáltatások száma";
$_LANG['statsnumreferredsignups'] = "Ajánlott regisztrálók száma";
$_LANG['statsnumtickets'] = "Hibajegyek száma";
$_LANG['submitticketdescription'] = "Kapcsolatba léphet ügyfélszolgálatunkkal, ha bármilyen kérdése van vagy hibát szeretne bejelenteni";
$_LANG['supportclickheretocontact'] = "kattintson ide, hogy kapcsolatba lépjen velünk";
$_LANG['supportpresalesquestions'] = "Ha viszonteladói kérdése van";
$_LANG['supportticketinvalid'] = "Hiba történt. A kért hibajegy nem található.";
$_LANG['supportticketsallowedextensions'] = "Engedélyezett fájltípusok";
$_LANG['supportticketschoosedepartment'] = "Válasszon részleget";
$_LANG['supportticketsclient'] = "Ügyfél";
$_LANG['supportticketsclientemail'] = "E-mail cím";
$_LANG['supportticketsclientname'] = "Név";
$_LANG['supportticketsdate'] = "Dátum";
$_LANG['supportticketsdepartment'] = "Részleg";
$_LANG['supportticketsdescription'] = "Meglévő hibajegyek megtekintése";
$_LANG['supportticketserror'] = "Hiba";
$_LANG['supportticketserrornoemail'] = "Nem adta meg az e-mail címét";
$_LANG['supportticketserrornomessage'] = "Nem adott meg üzenetet";
$_LANG['supportticketserrornoname'] = "Nem adta meg a nevét";
$_LANG['supportticketserrornosubject'] = "Nem adta meg a tárgyat";
$_LANG['supportticketsfilenotallowed'] = "A fájltípus, amit feltöltene nem engedélyezett.";
$_LANG['supportticketsheader'] = "Ha nem talál választ problémájára a tudásbázisban, küldjön egy Hibajegyet a megfelelő szervezeti ágazat kiválasztásával.";
$_LANG['supportticketsnotfound'] = "Nem található a hibajegy";
$_LANG['supportticketsopentickets'] = "Nyitott hibajegy";
$_LANG['supportticketspagetitle'] = "Hibajegyek";
$_LANG['supportticketsposted'] = "Elküldött";
$_LANG['supportticketsreply'] = "Válasz";
$_LANG['supportticketsstaff'] = "Ügyfélszolgálat";
$_LANG['supportticketsstatus'] = "Állapot";
$_LANG['supportticketsstatusanswered'] = "Megválaszolt";
$_LANG['supportticketsstatusclosed'] = "Lezárt";
$_LANG['supportticketsstatuscloseticket'] = "Ha megoldódott, kattintson ide a hibajegy lezáráshoz";
$_LANG['supportticketsstatuscustomerreply'] = "Ügyfél-Válasz";
$_LANG['supportticketsstatusinprogress'] = "Folyamatban";
$_LANG['supportticketsstatusonhold'] = "Függőben";
$_LANG['supportticketsstatusopen'] = "Nyitott";
$_LANG['supportticketssubject'] = "Tárgy";
$_LANG['supportticketssubmitticket'] = "Hibajegy küldése";
$_LANG['supportticketssystemdescription'] = "A hibajegy rendszer lehetővé teszi számukra, hogy választ adjunk problémáira és kérdéseire a lehető leggyorsabban. Amikor válaszolunk egy Hibajegyére, e-mailen keresztül értesítjük Önt.";
$_LANG['supportticketsticketattachments'] = "Mellékletek";
$_LANG['supportticketsticketcreated'] = "Hibajegy létrehozva";
$_LANG['supportticketsticketcreateddesc'] = "Hibajegyét sikeresen létrehoztuk. Egy e-mailt küldünk az Ön címére a hibajegy adataival. Ha megszeretné tekinteni hibajegyét, most megteheti.";
$_LANG['supportticketsticketid'] = "Hibajegy AZ";
$_LANG['supportticketsticketsubject'] = "Tárgy";
$_LANG['supportticketsticketsubmit'] = "Küldés";
$_LANG['supportticketsticketurgency'] = "Sürgős";
$_LANG['supportticketsticketurgencyhigh'] = "Magas";
$_LANG['supportticketsticketurgencylow'] = "Alacsony";
$_LANG['supportticketsticketurgencymedium'] = "Közepes";
$_LANG['supportticketsuploadfailed'] = "Nem sikerült feltölteni a csatolt fájlt";
$_LANG['supportticketsviewticket'] = "Hibajegy megtekintése";
$_LANG['telesignincorrectpin'] = "Hibás Pin!";
$_LANG['telesigninitiatephone'] = "Nem tudtuk telefon-ellenőrzést kezdeményezni az Ön számára. Kérjük, lépjen kapcsolatba velünk.";
$_LANG['telesigninvalidnumber'] = "Érvénytelen telefonszám";
$_LANG['telesigninvalidpin'] = "A megadott PIN érvénytelen!";
$_LANG['telesigninvalidpin2'] = "A megadott PIN érvénytelen volt.";
$_LANG['telesigninvalidpinmessage'] = "PIN kód ellenőrzés sikertelen";
$_LANG['telesignmessage'] = "Telefon ellenőrzés elindítva a következő számra %s. Kérjük várjon...";
$_LANG['telesignphonecall'] = "Telefonhívás";
$_LANG['telesignpin'] = "Írja be a PIN-kódot:";
$_LANG['telesignsms'] = "Sms";
$_LANG['telesignsmstextmessage'] = "Köszönjük, hogy igénybe vette az SMS ellenőrzési rendszerünk. Az Ön kódja: %s Kérjük, írja be a kódot a számítógépet!";
$_LANG['telesigntitle'] = "TeleSign telefon ellenőrzés.";
$_LANG['telesigntype'] = "Válasszon ellenőrzési típust ehhez a számhoz %s:";
$_LANG['telesignverificationcanceled'] = "Átmeneti probléma lépett fel a telefon ellenőrzési szolgáltatásban és a telefonellenőrzést ideiglenesen töröltük.";
$_LANG['telesignverificationproblem'] = "Probléma volt a telefon ellenőrzés szolgáltatással és az Ön rendelése nem lett érvényesítve. Kérjük, később próbálja meg újra.";
$_LANG['telesignverify'] = "Az Ön telefonszáma %s amit le kell ellenőrizni a rendelés befejezéséhez.";
$_LANG['ticketratingexcellent'] = "Kiváló";
$_LANG['ticketratingpoor'] = "Gyenge";
$_LANG['ticketratingquestion'] = "Hogyan értékelné ezt a választ?";
$_LANG['ticketreatinggiven'] = "Ön már értékelte ezt a választ";
$_LANG['transferdomain'] = "Domain áthozatal";
$_LANG['transferdomaindesc'] = "Átszeretné hozni hozzánk a domainjét? Ha igen, írja be alulra a domain nevet a kezdéshez.";
$_LANG['transferdomainname'] = "Domain név áthozatal";
$_LANG['updatecart'] = "Kosár frissítése";
$_LANG['upgradechooseconfigoptions'] = "Frissítés/visszalépés lehetőségeinek beállítása ennél a terméknél.";
$_LANG['upgradechoosepackage'] = "Válassza ki a kívánt csomagot amire frissíteni/visszalépni szeretne a jelenlegi csomagról az alábbi lehetőségek közül.";
$_LANG['upgradecurrentconfig'] = "Jelenlegi konfiguráció";
$_LANG['upgradedowngradeconfigoptions'] = "Frissítés/visszalépés lehetőségek";
$_LANG['upgradenewconfig'] = "Új konfiguráció";
$_LANG['upgradenochange'] = "Nincs változás";
$_LANG['upgradeproductlogic'] = "A frissítési ár kiszámítása a jelenlegi és a frissíteni kívánt termék különbözetéből és az új számlázandó termék azonos időszakából adódik";
$_LANG['upgradesummary'] = "Az alábbiakban összefoglaljuk a frissített rendelést.";
$_LANG['usedefaultcontact'] = "Alapértelmezett kapcsolat használata (Lásd fentebb)";
$_LANG['varilogixfraudcall_callnow'] = "Hívjon most!";
$_LANG['varilogixfraudcall_description'] = "A csalást megelőző intézkedés részeként, mi most fel fogjuk hívni azon a  telefonszámon amit megadott a risztrációja során és kérjük hogy írja be a fenti PIN kódot. Kérjük, jegyezze fel a PIN kódot és amikor készen áll a telefonhívásra, kattintson az alábbi gombra.";
$_LANG['varilogixfraudcall_error'] = "Hiba történt, és nem tudjuk felhívni Önt a megadott telefonszámon, hogy visszaigazoljuk rendelését. Kérjük, lépjen kapcsolatba ügyfélszolgáltaunkkal, hogy a lehető legrövidebb időn belül véglegesítsük rendelését.";
$_LANG['varilogixfraudcall_fail'] = "A hívás, hogy ellenőrizzük a megrendelését nem sikerült. Ez azért történhetett meg, mert hibásan adta meg a telefonszámát vagy fekete listán szerepel a rendszerünkben. Kérem, lépjen kapcsolatba ügyfélszolgálatunkkal amilyen gyorsan csak tud, hogy befejezhesse rendelését.";
$_LANG['varilogixfraudcall_failed'] = "Sikertelen";
$_LANG['varilogixfraudcall_pincode'] = "PIN kód";
$_LANG['varilogixfraudcall_title'] = "VariLogix CsalásHívás";
$_LANG['viewcart'] = "Kosár megtekintése";
$_LANG['welcomeback'] = "Üdvözöljük";
$_LANG['whoisresults'] = "WHOIS eredmények";
$_LANG['yes'] = "Igen";
$_LANG['yourdetails'] = "Az Ön adatai";

# Version 4.1

$_LANG['clientareafiles'] = "Csatolt fájlok";
$_LANG['clientareafilesdate'] = "Hozzáadás dátuma";
$_LANG['clientareafilesfilename'] = "Fájlnév";

$_LANG['pwreset'] = "Elfelejtett Jelszó alaphelyzetbe állítása";
$_LANG['pwresetdesc'] = "Ha elfelejtette jelszavát itt alaphelyzetbe állíthatja. Ha kitölti a regisztrált e-mail címével (és jól válaszol a fiók biztonsági kérdésére ha be van állítva), egy leírást fogunk küldeni, hogyan állíthatja vissza jelszavát.";
$_LANG['pwresetemailrequired'] = "Kérjük, adja meg e-mail címét";
$_LANG['pwresetemailnotfound'] = "Nem található ügyfél fiók a megadott e-mail címmel";
$_LANG['pwresetsecurityquestionrequired'] = "Ahogy van egy biztonsági kérdés beállítva az ügyfélfiókjára, alább meg kell adnia a választ erre a kérdésre.";
$_LANG['pwresetsecurityquestionincorrect'] = "A biztonsági kérdésre adott válasz nem egyezik meg a fiókjában megadott válasszal";
$_LANG['pwresetsubmit'] = "Küldés";
$_LANG['pwresetvalidationsent'] = "Hitelesítő levél elküldve";
$_LANG['pwresetvalidationcheckemail'] = "Az új jelszó kiállítása megkezdődött. Kérjük, ellenőrizze email fiókját, melyben megtalálja a további teendőket.";
$_LANG['pwresetkeyinvalid'] = "A hitelesítő link érvénytelen, próbálja újra!";
$_LANG['pwresetkeyexpired'] = "A hitelesítő link érvényessége lejárt, kérjen újat!";
$_LANG['pwresetvalidationsuccess'] = "Jelszó visszaállítás sikeres";

$_LANG['overagescharges'] = "Túllépési díj";
$_LANG['overagestotaldiskusage'] = "Teljes lemezhasználat";
$_LANG['overagestotalbwusage'] = "Teljes sávszélesség-használat";

$_LANG['affiliatescommissionspending'] = "Függőben lévő jutalékok";
$_LANG['affiliatescommissionsavailable'] = "Elérhető jutalékok egyenlege";
$_LANG['affiliatessignups'] = "Regisztrálók száma";
$_LANG['affiliatesconversionrate'] = "Konverziós ráta";

$_LANG['configoptionqtyminmax'] = "%s a minimális követelmény a %s és maximum a %s";

$_LANG['creditcardnostore'] = "Jelölje be a jelölőnégyzetet, ha nem akarja, hogy hitelkártya adatait eltároljuk  a folyamatos számlázáshoz";
$_LANG['creditcarddelete'] = "Mentett kártyaadatok törlése";
$_LANG['creditcarddeleteconfirmation'] = "A tárolt hitelkártya adatit eltávolítottuk fiókjából";
$_LANG['creditcardupdatenotpossible'] = "Hitelkártya adatait jelenleg nem tudtuk frissíteni. Kérjük, próbálja meg később újra.";

$_LANG['invoicepaymentsuccessconfirmation'] = "Köszönjük! A fizetés sikeres volt.";
$_LANG['invoicepaymentfailedconfirmation'] = "Sajnos a fizetési kísérlet sikertelen volt.<br />Próbálja újra vagy vegye fel velünk a kapcsolatot!";

# Version 4.2

$_LANG['promoappliedbutnodiscount'] = "A megadott promóciós kódot a rendszer elfogadta, de nincs az Ön kosarában olyan termék amire érvényesíteni lehetne - kérjük, ellenőrizze a promóció feltételeit";

$_LANG['upgradeerroroverdueinvoice'] = "Jelenleg nem frissítheti vagy nem léphet vissza kisebb csomagba ennél a terméknél, mert a számla már ki lett állítva a következő megújítás alkalmára.<br /><br />A folytatáshoz, kérjük, először fizesse ki már meglévő számláját, azután már azonnal frissítheti vagy visszaléphet egy másik csomagba. Különbözetet felszámoljuk vagy visszatérítjük Önnek..";

$_LANG['subaccountactivate'] = "Al-fiók aktiválása";
$_LANG['subaccountactivatedesc'] = "Jelölje be, ha al-fiókként szeretné beállítani, ügyfélfiók hozzáféréssel";
$_LANG['subaccountpermissions'] = "Al-fiók engedélyek";
$_LANG['subaccountpermsprofile'] = "Fióktulajdonos adatainak módosítása";
$_LANG['subaccountpermscontacts'] = "Kapcsolatok kezelése és megtekintése";
$_LANG['subaccountpermsproducts'] = "Termékek és szolgáltatások megtekintése és Services";
$_LANG['subaccountpermsmanageproducts'] = "Termék jelszavak kezelése és megtekintése";
$_LANG['subaccountpermsdomains'] = "Domainek megtekintése";
$_LANG['subaccountpermsmanagedomains'] = "Domain beállítások kezelése";
$_LANG['subaccountpermsinvoices'] = "Számlák megtekintése és fizetéses";
$_LANG['subaccountpermstickets'] = "Hibajegyek beküldése és megtekintése";
$_LANG['subaccountpermsaffiliates'] = "Affiliate fiók megtekintése és kezelése";
$_LANG['subaccountpermsemails'] = "E-mailek megtekintése";
$_LANG['subaccountpermsorders'] = "Új rendelések, módosítások, törlések leadása";
$_LANG['subaccountpermissiondenied'] = "Nincs megfelelő jogosultsága az oldal megtekintéséhez";
$_LANG['subaccountallowedperms'] = "Az Ön jogosultságai:";
$_LANG['subaccountcontactmaster'] = "Lépjen kapcsolatba a mesterfiók tulajdonossal, ha úgy érzi, hogy ez hiba.";

$_LANG['knowledgebasealsoread'] = "Olvasott";

$_LANG['orderpaymenttermtriennially'] = "Hároméves";
$_LANG['orderpaymentterm36month'] = "36 havi díj";

$_LANG['domainrenewals'] = "Domain Megújítások";
$_LANG['domaindaysuntilexpiry'] = "Napok száma a lejáratig";
$_LANG['domainrenewalsnoneavailable'] = "Nincsen megújításra jogosult domainje a fiókjában";
$_LANG['domainrenewalspastgraceperiod'] = "Elmúlt megújítási időszak";
$_LANG['domainrenewalsingraceperiod'] = "Utolsó lehetőség a megújításra!";
$_LANG['domainrenewalsdays'] = "Nap";
$_LANG['domainrenewalsdaysago'] = "Napja";

$_LANG['invoicespartialpayments'] = "Részösszeg fizetése";
$_LANG['invoicestotaldue'] = "Összesen fizetendő";

$_LANG['masspaytitle'] = "Több számla fizetése";
$_LANG['masspaydescription'] = "Az alábbiakban összefoglaljuk a kiválasztott számlákat és a teljes összeget a kifizetésükhöz. A számlák kifizetéséhez válassza ki alább a kívánt fizetési módot, majd kattintson a küldésre.";
$_LANG['masspayselected'] = "Kiválasztottak fizetése";
$_LANG['masspayall'] = "Összes kifizetése";
$_LANG['masspaymakepayment'] = "Fizetés";

# Version 4.3

$_LANG['searchenterdomain'] = "Írja be a keresendő domaint";
$_LANG['searchfilter'] = "Szűrő";

$_LANG['suspendreason'] = "Felfüggesztés oka";
$_LANG['suspendreasonoverdue'] = "Lejárt fizetések";

$_LANG['vpsnetmanagement'] = "VPS Kezelés";
$_LANG['vpsnetpowermanagement'] = "Energiagazdálkodás";
$_LANG['poweron'] = "Bekapcsol";
$_LANG['poweroffforced'] = "Kikapcsol (Kényszerített)";
$_LANG['powerreboot'] = "Újraindít";
$_LANG['powershutdown'] = "Leállít";
$_LANG['vpsnetcpugraphs'] = "Processzor grafikonok";
$_LANG['vpsnetnetworkgraphs'] = "Hálózati grafikonok";
$_LANG['vpsnethourly'] = "Óránként";
$_LANG['vpsnetdaily'] = "Napi";
$_LANG['vpsnetweekly'] = "Heti";
$_LANG['vpsnetmonthly'] = "Havi";
$_LANG['view'] = "Megtekint";
$_LANG['vpsnetbackups'] = "Biztonsági mentés beállításai";
$_LANG['vpsnetgenbackup'] = "Biztonsági mentés generálása";
$_LANG['vpsnetrestorebackup'] = "Korábbi biztonsági mentés visszaállítása";
$_LANG['vpsnetrestorebackupwarning'] = "A biztonsági mentés visszaállítása felülírja az Ön VPS szerverét";
$_LANG['vpsnetnobackups'] = "Nem találhatók biztonsági mentések";
$_LANG['vpsnetrunning'] = "Fut";
$_LANG['vpsnetnotrunning'] = "Nem fut";
$_LANG['vpsnetpowercycling'] = "A feszültség ingadozik";
$_LANG['vpsnetcloud'] = "Felhő";
$_LANG['vpsnettemplate'] = "Sablon";
$_LANG['vpsnetstatus'] = "Rendszer Státusz";
$_LANG['vpsnetbwusage'] = "Sávszélesség használat";

$_LANG['twitterlatesttweets'] = "Legutóbbi Tweet-ek";
$_LANG['twitterfollow'] = "Kövessen a Twitteren";
$_LANG['twitterfollowus'] = "Kövessen minket";
$_LANG['twitterfollowuswhy'] = "hogy mindig naprakész legyen híreinkről és ajánlatainkról";

$_LANG['chatlivehelp'] = "Élő Segítség";

$_LANG['domainrelease'] = "Domain kiadás";
$_LANG['domainreleasedescription'] = "Írjon be egy új TAG-ot ide, hogy domain nevét másik regisztrátorhoz vigye át";
$_LANG['domainreleasetag'] = "Új regisztrátor Tag";

# Ajax Order Form

$_LANG['orderformtitle'] = "Megrendelőlap";

$_LANG['signup'] = "Regisztrálj!";
$_LANG['loading'] = "Töltés...";

$_LANG['ordersummarybegin'] = "A bevásárló kosár üres<br/>Kérjük, válasszon egy terméket a kezdéshez...";

$_LANG['cartchooseproduct'] = "Termék választása";
$_LANG['cartconfigurationoptions'] = "Konfigurációs beállítások";

$_LANG['ordererrorsoccurred'] = "Az alábbi hibák történtek, és korrigálni kell őket, mielőtt a pénztárhoz lépne:";
$_LANG['ordererrortermsofservice'] = "El kell fogadni az ÁSZF-et";
$_LANG['ordertostickconfirm'] = "Pipálja ki a négyzetet, hogy megerősítse, elfogadj a";

$_LANG['cartnewcustomer'] = "Új ügyfél vagyok";
$_LANG['cartexistingcustomer'] = "Meglévő ügyfél vagyok";

$_LANG['cartpromo'] = "Promóció";
$_LANG['cartenterpromo'] = "Promóciós kód megadása";
$_LANG['cartremovepromo'] = "Promóció eltávolítása";

$_LANG['cartrecurringcharges'] = "Rendszeres díjak";

$_LANG['cartenterdomain'] = "Kérjük, adja meg a domaint amit alább használni szeretne.";

$_LANG['cartdomainavailableoptions'] = "Gratulálunk, ez a Domain elérhető!";
$_LANG['cartdomainavailableregister'] = "Kérjük, regisztráljon egy domaint";
$_LANG['cartdomainavailablemanual'] = "Magam regisztrálom külön";

$_LANG['cartdomainunavailableoptions'] = "Sajnáljuk ez domain foglalt. Ha Ön a tulajdonosa válasszon az alábbi lehetőségek közül...";
$_LANG['cartdomainunavailabletransfer'] = "Kérem, hozza át a domainem";
$_LANG['cartdomainunavailablemanual'] = "Ez már az én domainem és szeretném frissíteni a névszervereit";

$_LANG['cartdomaininvalid'] = "A megadott domain nem érvényes. Csak a www. utáni részt kell megadnia a végződéssel együtt";

# Version 4.4

$_LANG['dlinvalidlink'] = "Érvénytelen hivatkozást követett. Kérjük, lépjen kapcsolatba ügyfélszolgálatunkkal";

$_LANG['domaindnsmanagementlaunch'] = "DNS kezelő indítása";
$_LANG['domainemailforwardinglaunch'] = "Levéltovábbító indítása";

# Version 4.5

$_LANG['domaindnspriority'] = "Prioritás";
$_LANG['domaindnsmxonly'] = "Prioritás rekord csak az MX-hez";

$_LANG['orderpromoprestart'] = "Ez a promóció még nem indult el, nézzen vissza később.";

$_LANG['ticketmerge'] = "ÖSSZEVONVA";

$_LANG['quote'] = "Árajánlat";
$_LANG['quotestitle'] = "Ajánlataim";
$_LANG['quoteview'] = "Megtekint";
$_LANG['quotedownload'] = "Letölt";
$_LANG['quoteacceptbtn'] = "Ajánlat elfogadása";
$_LANG['quotedlpdfbtn'] = "PDF letöltés";
$_LANG['quotediscountheading'] = "Kedvezmény (%)";
$_LANG['noquotes'] = "Jelenleg nincsenek elmentett árajánlatok a fiókban.<br />Az árajánlat kéréséhez kérjük nyisson egy hibajegyet.";
$_LANG['quotenumber'] = "Árajánlat #";
$_LANG['quotesubject'] = "Tárgy";
$_LANG['quotedatecreated'] = "Létrehozás dátuma";
$_LANG['quotevaliduntil'] = "Érvényes";
$_LANG['quotestage'] = "Állapot";
$_LANG['quoterecipient'] = "Címzett";
$_LANG['quoteqty'] = "Mennyiség";
$_LANG['quotedesc'] = "Leírás";
$_LANG['quoteunitprice'] = "Egységár";
$_LANG['quotediscount'] = "Engedmény %";
$_LANG['quotelinetotal'] = "Összesen";
$_LANG['quotestagedraft'] = "Piszkozat";
$_LANG['quotestagedelivered'] = "Kézbesítve";
$_LANG['quotestageonhold'] = "Tartva";
$_LANG['quotestageaccepted'] = "Elfogadva";
$_LANG['quotestagelost'] = "Lejárat";
$_LANG['quotestagedead'] = "Lejárat";
$_LANG['quoteref'] = "Re Ajánlat #";
$_LANG['quotedeposit'] = "Befizetés";
$_LANG['quotefinalpayment'] = "Befizetés egyenlege";

$_LANG['invoiceoneoffpayment'] = "Egyszeri kifizetés legyen";
$_LANG['invoicesubscriptionpayment'] = "Készítsen automatikus Ismétlődő Előfizetést";

$_LANG['invoicepaymentpendingreview'] = "Köszönjük! A fizetés sikeres volt, hamarosan alkalmazni fogjuk számlájára is amint a 2CheckOut felülvizsgálati folyamata befejeződött.<br /><br /> Ez eltarhat néhány óráig, így szíves türelmét kérjük.";

$_LANG['step'] = "%s lépés";
$_LANG['cartdomainexists'] = "Ez a domain már létezik az adatbázisunkban, így nem rendelhető meg újra";
$_LANG['cartcongratsdomainavailable'] = "Gratulálunk, %s regisztrálható!";
$_LANG['cartregisterhowlong'] = "Milyen időtartamra regisztrálná?";
$_LANG['cartdomaintaken'] = "Sajnáljuk, %s már foglalt";
$_LANG['carttransfernotregistered'] = "%s úgy tűnik még nem regisztrálták";
$_LANG['carttransferpossible'] = "Gratulálunk, át tudjuk hozni a %s hozzánk, csak %s";
$_LANG['cartotherdomainsuggestions'] = "Talán ezek a domainek érdekelhetik Önt....";
$_LANG['cartdomainsconfiginfo'] = "A következő lehetőségek és beállítások érhetőek el az Ön által választott domainhez. A kötelező mezőket *-al jelöltük.";
$_LANG['cartnameserverchoice'] = "Névszerver kiválasztása";
$_LANG['cartnameserverchoicedefault'] = "Alapértelmezett névszerver használata saját tárhelyeinkhez";
$_LANG['cartnameserverchoicecustom'] = "Egyéni névszerver használata";
$_LANG['cartfollowingaddonsavailable'] = "A következő kiegészítők érhetőek el az Ön aktív termékéhez és szolágatásához.";
$_LANG['cartregisterdomainchoice'] = "Új domain regisztrálása";
$_LANG['carttransferdomainchoice'] = "Domain átregisztrációja egy másik szolgáltatótól";
$_LANG['cartexistingdomainchoice'] = "Meglévő domain nevemet használnám, és a névszervereket módosítanám";
$_LANG['cartsubdomainchoice'] = "Aldomain használata %s-től";
$_LANG['carterrordomainconfigskipped'] = "Vissza kell térnie és ki kell töltenie az alábbi szükséges mező(ke)t a domain konfigurációhoz";
$_LANG['cartproductchooseoptions'] = "Lehetőség kiválasztása";
$_LANG['cartproductselection'] = "Termékek kiválasztása";
$_LANG['cartreviewcheckout'] = "Áttekintés és Fizetés";
$_LANG['cartchoosecycle'] = "Válasszon számlázási ciklust";
$_LANG['cartavailableaddons'] = "Elérhető kiegészítők";
$_LANG['cartsetupfees'] = "Telepítési díj";
$_LANG['cartchooseanotherproduct'] = "Másik termék választása";
$_LANG['cartaddandcheckout'] = "Hozzáadom a kosaramhoz és irány a pénztár";
$_LANG['cartchooseanothercategory'] = "Másik kategória választása";
$_LANG['carttryanotherdomain'] = "Próbáljon másik domain-t";
$_LANG['cartmakedomainselection'] = "Kérjük, válasszon az alábbi opciókból, és adja meg, melyik domaint szeretné használni a tárhely szolgáltatással együtt.";
$_LANG['cartfraudcheck'] = "Csalás ellenőrzés";

$_LANG['newcustomer'] = "Új ügyfél";
$_LANG['existingcustomer'] = "Meglévő ügyfél";
$_LANG['newcustomersignup'] = "<strong>Még nem regisztrált?</strong> %sKattintson ide a regisztrációhoz...%s";

$_LANG['upgradeonselectedoptions'] = "(A kiválasztott lehetőségekkel)";
$_LANG['recurringpromodesc'] = "Ez a promóciós kód tartalmaz egy %s ismétlődő kedvezményt.<br />(Ez a kedvezmény vonatkozik a jövőbeni termék megújítás teljes árára is)";

# Version 4.5.2

$_LANG['ajaxcartcheckout'] = "Ugrás egyenesen a pénztárhoz &raquo;";
$_LANG['ordersummarybegin'] = "A bevásárló kosár üres<br/>Kérjük, válasszon egy terméket a kezdéshez...";
$_LANG['ajaxcartconfigreqnotice'] = "Jó úton halad, hogy regisztráljon nálunk, de előbb ki kell választania egy domaint mielőtt a kiválasztott terméket a kosarához adná...";

# Version 5.0.0

$_LANG['cancelrequestdomain'] = "Megszakítja a domain megújítást?";
$_LANG['cancelrequestdomaindesc'] = "Önnek van egy aktív domain regisztrációja ami erre a termékre mutat.<br />Ennek a domainnek a megújítása %s-án amelynek költsége %s per %s év<br /><br />Ha a domaint is le szeretné mondani, és hagyni akarja, hogy lejárjon a jelenlegi regisztráció végén egyszerűen jelölje be alább.";
$_LANG['cancelrequestdomainconfirm'] = "Megerősítem, nem szeretném megújítani a domaint";

$_LANG['startingfrom'] = "Kezdve";

$_LANG['orderpromopriceoverride'] = "Ár felülírás";
$_LANG['orderpromofreesetup'] = "Ingyenes Beállítás";

$_LANG['thereisaproblem'] = "Hoppá, probléma lépett fel...";
$_LANG['problemgoback'] = "Menjen vissza és próbálja újra";

$_LANG['quantity'] = "Mennyiség";
$_LANG['cartqtyenterquantity'] = "Több mint 1-et szeretne ebből a termékből? Írja be a mennyiséget ide:";
$_LANG['cartqtyupdate'] = "Frissít";
$_LANG['invoiceqtyeach'] = "/minden egyes";

$_LANG['nschoicedefault'] = "Alapértelmezett névszerverek használata";
$_LANG['nschoicecustom'] = "Egyéni névszerver használata (írja be alább)";

$_LANG['jumpto'] = "Ugrás a";
$_LANG['top'] = "Fel";

$_LANG['domaincontactusexisting'] = "Meglévő fiókkapcsolat használata";
$_LANG['domaincontactusecustom'] = "Egyedi információkat adhat meg alább";
$_LANG['domaincontactchoose'] = "Válasszon kapcsolatot";
$_LANG['domaincontactprimary'] = "elsődleges profiladatok";

$_LANG['invoicepdfgenerated'] = "PDF létrehozás be";

$_LANG['domainrenewalsbeforerenewlimit'] = "A minimális haladó megújítás %s nap";

$_LANG['promonewsignupsonly'] = "Ez a promóciós kód csak új ügyfelek számára használható";

# Bulk Domain Management

$_LANG['domainbulkmanagement'] = "Tömeges Kezelési Műveletek";
$_LANG['domainbulkmanagementchangesaffect'] = "A változások a következő domaiekre lettek érvényesítve:";
$_LANG['domainbulkmanagementchangeaffect'] = "Ez a változás a következő domainekre lettek alkalmazva:";
$_LANG['domaincannotbemanaged'] = "nem lehet automatikusan kezelni - kérjük, lépjen kapcsolatba ügyfélszolgálatunkkal, bármilyen változtatással kapcsolatban amit szeretne megcsinálni";
$_LANG['domainbulkmanagementnotpossible'] = "Sajnos ezeket a beállításokat jelenleg nem lehet az ügyfélfiókból végrehajtani. Kérjük, lépjen kapcsolatba ügyfélszolgálatunkkal, bármilyen változtatással kapcsolatban amit szeretne megcsinálni.";

$_LANG['domainmanagens'] = "Névszerver kezelése";

$_LANG['domainautorenewstatus'] = "Automatikus megújítás állapota";
$_LANG['domainautorenewinfo'] = "Az automatikus megújítás segít megvédeni az Ön domainjét. Ha Ön ezt engedélyezi, automatikusan küldünk egy megújítási számlát pár héttel a domain lejárta előtt és megújítjuk a domaint ha a fizetés sikeresen megtörténik.";
$_LANG['domainautorenewrecommend'] = "Javasoljuk, tartsa engedélyezve az auto megújítátást, nehogy elveszítse domainjét.";

$_LANG['domainreglockstatus'] = "Regisztrátor Zár állapota";
$_LANG['domainreglockinfo'] = "Regisztrátor Zár (más néven Lopás védelem) biztosítja Domainjét illetéktelen átvitelektől (transzfer).";
$_LANG['domainreglockrecommend'] = "Javasoljuk tartsa engedélyezve, hacsak át nem szeretné vitetni Domain nevét máshova.";
$_LANG['domainreglockenable'] = "Regisztrátor Zár engedélyezése";
$_LANG['domainreglockdisable'] = "Regisztrátor Zár tiltása";

$_LANG['domaincontactinfoedit'] = "Kapcsolati információk szerkesztése";

$_LANG['domainmassrenew'] = "Domain megújítása";

# reCAPTCHA

$_LANG['captchatitle'] = "Spam Bot ellenőrzés";
$_LANG['captchaverify'] = "Kérjük, az alábbi szövegdobozban adja meg a képen látott karaktereket. Ez arra szolgál, hogy megelőzzük az automatikus elküldéseket.";
$_LANG['captchaverifyincorrect'] = "A megadott karakterek nem egyeznek meg a képen láthatókkal. Kérem, próbálja újra.";
$_LANG['recaptcha-invalid-site-private-key'] = "Hiba történt, kérjük lépjen kapcsolatba ügyfélszolgálatunkkal (hibakód: cap1)";
$_LANG['recaptcha-invalid-request-cookie'] = "Hiba történt, kérjük, próbálja újra (hibakód: cap2)";
$_LANG['recaptcha-incorrect-captcha-sol'] = "A megadott karakterek nem egyeznek meg az ellenőrzőkóddal. Kérjük, próbálja meg újra.";

# Product Bundles

$_LANG['bundledeal'] = "Csomagos Ajánlat!";
$_LANG['bundlevaliddateserror'] = "A csomag nem elérhető";
$_LANG['bundlevaliddateserrordesc'] = "Ez a csomag vagy még nem aktív vagy már lejárt. Ha Ön úgyérzi ez az üzenet egy hiba, kérjük lépjen kapcsolatba ügyfélszolgálatunkkal.";
$_LANG['bundlemaxusesreached'] = "A csomag nem elérhető";
$_LANG['bundlemaxusesreacheddesc'] = "Ez a csomagos ajánlat elérte a megengedett maximális felhasználást, így sajnos már nem elérhető. Kérjük, lépjen kapcsolatba velünk, hogy megvitassuk, ha érdeklik szolgáltatásaink.";
$_LANG['bundlereqsnotmet'] = "A csomagos ajánlat követelményei nem teljesültek";
$_LANG['bundlewarningpromo'] = "A kiválasztott csomag nem használható fel más promócióval vagy ajánlattal";
$_LANG['bundlewarningproductcycle'] = "A kiválasztott csomag megköveteli, hogy kiválassza a számlázási ciklust '%s' a termékhez %s, hogy jogosult legyen";
$_LANG['bundlewarningproductconfopreq'] = "A kiválasztott csomag megköveteli, hogy kiválassza '%s' a '%s' annak érdekében, hogy jogosult legyen";
$_LANG['bundlewarningproductconfopyesnoenable'] = "A kiválasztott csomag megköveteli, hogy engedélyezze a lehetőségét a '%s' annak érdekében, hogy jogosult legyen";
$_LANG['bundlewarningproductconfopyesnodisable'] = "A kiválasztott csomag megköveteli, hogy tötölje a '%s' lehetőséget annak érdekében, hogy jogosult legyen";
$_LANG['bundlewarningproductconfopqtyreq'] = "A kiválasztott csomag megköveteli, hogy kiválassza a '%s' menyniségét '%s' annak érdekében, hogy jogosult legyen";
$_LANG['bundlewarningproductaddonreq'] = "A kiválasztott csomag megköveteli, hogy kiválassza a '%s'  kiegészítőt a termékhez %s hogy jogosultak legyenek";
$_LANG['bundlewarningdomainreq'] = "A kiválasztott csomag megköveteli, hogy regisztráljon vagy áthozzon egy domaint a termék %s való jogosultsághoz";
$_LANG['bundlewarningdomaintld'] = "A kiválasztott csomag megköveteli, hogy kiválassza a domain kiegészítőkkel '%s' domainhez %s való jogosultsághoz";
$_LANG['bundlewarningdomainregperiod'] = "A kiválasztott csomag megköveteli, hogy kiválassza a regisztrációs periódust '%s' domainhez %s való jogosultsághoz";
$_LANG['bundlewarningdomainaddon'] = "A kiválasztott csomag megköveteli, hogy kiválassza a '%s' kiegészítőt a domainhez %s való jogosultsághoz";

# New Client Area Template  Lines

$_LANG['navservices'] = "Szolgáltatások";
$_LANG['navservicesorder'] = "Új szolgáltatás megrendelése";
$_LANG['navdomains'] = "Domainek";
$_LANG['navrenewdomains'] = "Domain(ek) megújítása";
$_LANG['navregisterdomain'] = "Új domain regisztrálása";
$_LANG['navtransferdomain'] = "Domain áthozatala hozzánk";
$_LANG['navwhoislookup'] = "Whois keresés";
$_LANG['navbilling'] = "Számlázás";
$_LANG['navsupport'] = "Ügyfélszolgálat";
$_LANG['navtickets'] = "Hibajegyek";
$_LANG['navopenticket'] = "Hibajegy küldése";
$_LANG['navmanagecc'] = "Hitelkártyák kezelése";
$_LANG['navemailssent'] = "Elküldött e-mailek";

$_LANG['hello'] = "Szia";
$_LANG['account'] = "Fiók";
$_LANG['login'] = "Bejelentkezés";
$_LANG['register'] = "Regisztráció";
$_LANG['forgotpw'] = "Elfelejtett jelszó?";
$_LANG['editaccountdetails'] = "Fiókadatok szerkesztése";

$_LANG['clientareanavccdetails'] = "Hitelkártya adatai";
$_LANG['clientareanavcontacts'] = "Kapcsolattartók/Al-fiókok";

$_LANG['manageyouraccount'] = "Saját Fiók kezelése";
$_LANG['accountoverview'] = "Fiók áttekintése";
$_LANG['paymentmethod'] = "Fizetési mód";
$_LANG['paymentmethoddefault'] = "Alapértelmezett használata (Minden rendeléshez)";
$_LANG['productmanagementactions'] = "Kezelési tevékenységek";
$_LANG['clientareanoaddons'] = "Nincsenek megvásárolt kiegészítők";
$_LANG['downloadssearch'] = "Letöltések keresése";
$_LANG['emailviewmessage'] = "Üzenetek megtekintése";
$_LANG['resultsperpage'] = "Találatok egy oldalon";
$_LANG['accessdenied'] = "Hozzáférés megtagadva";
$_LANG['search'] = "Keresés";
$_LANG['cancel'] = "Mégsem";
$_LANG['clientareabacklink'] = "&laquo; Vissza";
$_LANG['backtoserviceslist'] = "&laquo; Vissza a szolgáltatásokhoz";
$_LANG['backtodomainslist'] = "&laquo; Vissza a domain listához";

$_LANG['clientareahomeorder'] = "Látogasson el a megrendelőlaphoz ahol böngészhet termékeink és szolgáltatásaink közt. Meglévő ügyfeleink is vásárolhatnak opcionális extrákat és kiegészítőket itt.";
$_LANG['clientareahomelogin'] = "Már regisztrált? Ha igen kattintson az alábbi gombra, hogy bejelnetkezhessen az ügyfélfiókjába ahol kezelheti fiókját.";
$_LANG['clientareahomeorderbtn'] = "Ugrás a Megrendelőlaphoz";
$_LANG['clientareahomeloginbtn'] = "Biztonságos belépés";

$_LANG['clientareaproductsintro'] = "Itt találja az összes náluk regisztrált szolgáltatását.";
$_LANG['clientareaproductdetailsintro'] = "Áttekintő a tőlünk rendelt termékekeről/szolgáltatásokról.";
$_LANG['clientareadomainsintro'] = "Ezek az összes domainek amik ebben fiókba vannak reigsztrálva.";
$_LANG['invoicesintro'] = "Alább megtekintheti a teljes számlatörténetét.";
$_LANG['quotesintro'] = "Itt megtalálhatja az összes Önnek készített ajánlatunk.";
$_LANG['emailstagline'] = "Itt található egy másolat a legújabb elküldött e-mailünkről...";
$_LANG['supportticketsintro'] = "Bármilyen érdeklődés nyomon követése és elküldése...";
$_LANG['addfundsintro'] = "Előzetes pénzbefizetés";
$_LANG['registerintro'] = "Fiók létrehozása . . .";
$_LANG['masspayintro'] = "Az alábbi összes számla kifizetése egy egyszerű művelettel a fizetési mód kiválasztásával";
$_LANG['domaincheckerintro'] = "Ha domainje elérhető, kezdje webtárhely keresését itt...";
$_LANG['networkstatusintro'] = "Szolgáltatás Állapot Információk és Hálózati Közlemények";

$_LANG['creditcardyourinfo'] = "Számlázási adatok";
$_LANG['ourlatestnews'] = "Legfrissebb híreink";
$_LANG['ccexpiringsoon'] = "Hitelkártyája hamarosan lejár";
$_LANG['ccexpiringsoondesc'] = "Hitelkártyája hamarosan lejár, kérjük, győződjön meg róla %skártya adtok frissítése%s valünk, amint tudod";
$_LANG['availcreditbal'] = "Elérhető kredit egyenleg";
$_LANG['availcreditbaldesc'] = "Az Ön kredit egyenlege %s és ez automatikusan alklmazható bármilyen új számlára";
$_LANG['youhaveoverdueinvoices'] = "Önnek %s lejárt számlája van";
$_LANG['overdueinvoicesdesc'] = "Tárhelye felfüggesztésének elkerülése érdekében rendezze fizetetlen számláit. %sFizetés &raquo;%s";
$_LANG['supportticketsnoneopen'] = "Nincsnek nyitott hibajegyek";
$_LANG['invoicesnoneunpaid'] = "Jelenleg nincsenek kifizetetlen számlái";

$_LANG['registerdisablednotice'] = "A regisztrációhoz, kérjük <strong><a href=\"cart.php\">rendeljen</a></strong>";

$_LANG['pwstrength'] = "Jelszó erőssége";
$_LANG['pwstrengthenter'] = "Adja meg a jelszavát";
$_LANG['pwstrengthweak'] = "Gyenge";
$_LANG['pwstrengthmoderate'] = "Közepes";
$_LANG['pwstrengthstrong'] = "Erős";

$_LANG['managing'] = "Kezelés";
$_LANG['information'] = "Információ";
$_LANG['withselected'] = "A kiválasztottakkal";
$_LANG['managedomain'] = "Domain kezelése";
$_LANG['changenameservers'] = "Névszerver módosítása";
$_LANG['clientareadomainmanagedns'] = "DNS kezelése";
$_LANG['clientareadomainmanageemailfwds'] = "Email továbbítók kezelése";
$_LANG['moduleactionsuccess'] = "Sikeresen végrehajtva!";
$_LANG['moduleactionfailed'] = "Nem sikerült...";

$_LANG['domaininfoexp'] = "Jobboldalon megtekintheti a domain részleteit. A fenti fülek segítségével kezelheti domainjét.";
$_LANG['domainrenewexp'] = "Engedélyezze az automatikus megújítást, hogy automatikusan megküldhessük Önnek a megújításra került számlát mielőtt a domain lejár";
$_LANG['domainnsexp'] = "Meghatározhatja honnan pontolódjon át a domain ide. Kérjük, vegye figyelembe, hogy a változtatások aktiválódása akár 24 órát is igénybe vehet.";
$_LANG['domainlockingexp'] = "Zárja le a domaint, hogy megakadályozza a domain átvitelét annélkül, hogy Ön engedélyezné";
$_LANG['domaincurrentlyunlocked'] = "A Domin jelenleg feloldva!";
$_LANG['domaincurrentlyunlockedexp'] = "Engedélyeznie kellene a regisztrátor zárat, hacsak nem akarja áthozni a domaint.";
$_LANG['searchmultipletlds'] = "Több domainvégződés ellenőrzése";

$_LANG['networkstatustitle'] = "Hálózat állapota";
$_LANG['networkstatusnone'] = "Jelenleg nem található %s Hálózati probléma";
$_LANG['serverstatusheadingtext'] = "Az alábbiakban egy valósidejű áttekintés található a szerverinkről ahol ellenőrizheti ha valami ismert probléma lépett fel";

$_LANG['clientareacancelreasonrequired'] = "Meg kell indokolnia a lemondási kérelmét!";

$_LANG['addfundsdescription'] = "Addjon pénz a fiókjához, hogy elkerülje a sok kis tranzakciót és automatikusan gondoskodjon az Ön újonnan generált számláiról.";
$_LANG['addfundsnonrefundable'] = "* Az összes betét vissza nem térítendő.";

$_LANG['creditcardexpirydateinvalid'] = "A lejárati dátumot MM/YY formátumban kell megadni, és a múltbeli dátum nem lehet";

$_LANG['domaincheckerchoosedomain'] = "Domain választása...";
$_LANG['domaincheckerchecknewdomain'] = "Új domain elérhetőségének ellenőrzése";
$_LANG['domaincheckerdomainexample'] = " pl. tedomained.com";
$_LANG['domaincheckerinvalidtld'] = "nem valós végződés - TLD. Próbálja újra.";
$_LANG['domaincheckerhostingonly'] = "Csak tárhely rendelése";
$_LANG['domaincheckeravailtransfer'] = "Elérhető áthozatalra";
$_LANG['domaincheckerenterdomain'] = "Kezdje meg webtárhely élményét nálunk azzal, hogy megadja a domain nevet amit reigsztrálni, áthozni szeretne, vagy szimplán vásároljon tárhelyszolgáltatást alább...";
$_LANG['domaincheckerbulkinvaliddomain'] = "Egy vagy több domain amit megadott érvénytelen volt, így kihagytuk a keresési eredményből";

$_LANG['kbquestionsearchere'] = "Kérdése van? Keressen itt.";
$_LANG['contactus'] = "Kapcsolat";

$_LANG['opennewticket'] = "Új hibajegy";
$_LANG['searchtickets'] = "Írjon be egy hibajegy azonosítót vagy tárgyat";
$_LANG['supportticketspriority'] = "Prioritás";
$_LANG['supportticketsubmitted'] = "Beküldve";
$_LANG['supportticketscontact'] = "Kapcsolat";
$_LANG['supportticketsticketlastupdated'] = "Frissítve";

$_LANG['upgradedowngradepackage'] = "Frissítés/Visszalépés";
$_LANG['upgradedowngradechooseproduct'] = "Válasszon Terméket";

$_LANG['jobtitlereqforcompany'] = "(Kötelező, ha a Szervezet neve be van állítva)";

$_LANG['downloadproductrequired'] = "Az elem letöltéséhez szükséges, hogy Önnek a következő termék/szolgáltatásból aktív példánya legyen:";

$_LANG['affiliatesignuptitle'] = "Pénz kifizetése az ajánlott ügyfelek után";
$_LANG['affiliatesignupintro'] = "Aktiválja affiliate fiókját, és kezdjen el pénzt keresni ma ...";
$_LANG['affiliatesignupinfo1'] = "Jutalékot fizetünk minden egyes regisztráció után ami az Ön egyedi regisztrációs linkjén keresztül történik.";
$_LANG['affiliatesignupinfo2'] = "Nyomon követjük cookie-k használatával azokat a felhasználókat akiknek ajánlottál minket , így a felhasználók akiket ajánlottál nem kell, hogy azonnal vásároljanak, hogy megkaphasd a jutalékod. A cookie-k élettartama maximum 90 nap a első látogtástól számítva.";
$_LANG['affiliatesignupinfo3'] = "Ha szeretne többet megtudni, kérjük, forduljon hozzánk.";

# Version 5.1

$_LANG['copyright'] = "Szerzői jog";
$_LANG['allrightsreserved'] = "Minden jog fenntartva";
$_LANG['supportticketsclose'] = "Hibajegy bezárása";
$_LANG['affiliatesinitialthen'] = "Inicializálás aztán";
$_LANG['invoicesoutstandingbalance'] = "Tartozás";

$_LANG['cpanellogin'] = "Bejelentkezés a cPanel-be";
$_LANG['cpanelwhmlogin'] = "Bejelentkezés a WHM-be";
$_LANG['cpanelwebmaillogin'] = "Bejelentkezés a Webmail-be";
$_LANG['enkompasslogin'] = "Bejelentkezés az Enkompass-ba";
$_LANG['plesklogin'] = "Bejelentkezés a Plesk Vezérlőpultba";
$_LANG['helmlogin'] = "Bejelentkezés a Helm Vezérlőpultba";
$_LANG['hypervmrestart'] = "VPS Szerver Újraindítása";
$_LANG['siteworxlogin'] = "Bejelentkezés a SiteWorx Vezérlőpultba";
$_LANG['nodeworxlogin'] = "Bejelentkezés a NodeWorx Vezérlőpultba";
$_LANG['veportallogin'] = "Belépés a vePortal-ba";
$_LANG['virtualminlogin'] = "Bejelentkezés a Vezérlőpultba";
$_LANG['websitepanellogin'] = "Bejelentkezés a Vezérlőpultba";
$_LANG['whmsoniclogin'] = "Bejelentkezés a Vezérlőpultba";
$_LANG['xpanelmaillogin'] = "Bejelentkezés a Webmail-be";
$_LANG['xpanellogin'] = "Bejelentkezés az XPanel-be";
$_LANG['heartinternetlogin'] = "Bejelentkezés a Vezérlőpultba";
$_LANG['gamecplogin'] = "Bejelentkezés a GameCP-be";
$_LANG['fluidvmrestart'] = "VPS Szerver Újraindítása";
$_LANG['enomtrustedesc'] = "A TRUSTe Vezérlőpult tartalmazza a telepítési varázslót, hogy megkapja az Adatvédelmi Irányelveket és futhasson.";
$_LANG['enomtrustelogin'] = "Bejelentkezés a TrustE Vezérlőpultba";
$_LANG['directadminlogin'] = "Bejelentkezés a DirectAdmin-ba";
$_LANG['centovacastlogin'] = "Bejelentkezés a Centova Cast-ba";
$_LANG['castcontrollogin'] = "Bejelentkezés a Vezérlőpultba";

$_LANG['sslconfigurenow'] = "Beállítás most";
$_LANG['sslprovisioningdate'] = "SSL Létesítés dátuma";
$_LANG['globalsignvoucherscode'] = "Az Ön OneClickSSL Voucher kódja";
$_LANG['globalsignvouchersnotissued'] = "Még nem Issued";

$_LANG['domaintrffailreasonunavailable'] = "A hiba oka nem elérhető";

$_LANG['clientareaprojects'] = "Projektjeim";

$_LANG['clientgroupdiscount'] = "Ügyfél Kedvezmény";
$_LANG['billableitemshours'] = "Óra";
$_LANG['billableitemshour'] = "Óra";

$_LANG['invoicefilename'] = "Számla-";
$_LANG['quotefilename'] = "Ajánlat-";

# Licensing Addon

$_LANG['licensingkey'] = "Liszensz Kulcs";
$_LANG['licensingvaliddomains'] = "Érvényes Domainek";
$_LANG['licensingvalidips'] = "Érvényes IP-k";
$_LANG['licensingvaliddirectory'] = "Érvényes Könyvtár";
$_LANG['licensingstatus'] = "Liszensz állapot";
$_LANG['licensingreissue'] = "Liszensz újra kibocsátása";
$_LANG['licensingreissued'] = "Az érvényes Domain, IP és Könyvtár megtalálható és el lesz mentve a liszensz következő liszensz használatának alkalmával.";

# Domain Addons

$_LANG['domainaddons'] = "Kiegészítők";
$_LANG['domainaddonsinfo'] = "A következő kiegészítők érhetők el az Ön domainjeihez...";
$_LANG['domainaddonsdnsmanagement'] = "DNS Hoszt Rekord Kezelés";
$_LANG['domainaddonsidprotectioninfo'] = "Védje meg személyes adatait és csökkentse a spam kockázatát az Azonosító védelem engedélyezésével.";
$_LANG['domainaddonsdnsmanagementinfo'] = "Külső DNS Hoszting segíthet honlapjának gyorsításában és javítja az elérhetőségét csökkentett redudanciával.";
$_LANG['domainaddonsemailforwardinginfo'] = "Készítsen e-mail továbbítást e-mail címeiről egy Ön által választott e-mail fiókra, hogy nyomon tudja követni az összes e-mail címét egy fiók segítségével.";
$_LANG['domainaddonsbuynow'] = "Vásárlás most";
$_LANG['domainaddonsperyear'] = "/év";
$_LANG['domainaddonscancelareyousure'] = "Biztos benne, hogy le szeretné tiltani vagy törölni ez a domain kiegészítőt?";
$_LANG['domainaddonsconfirm'] = "Törlés megerősítése";
$_LANG['domainaddonscancelsuccess'] = "Kiegészítő sikeresen kikapcsolva!";
$_LANG['domainaddonscancelfailed'] = "A kiegészítő kikapcsolása sikertelen. Kérjük, lépjen kapcsolatba ügyfélszolgálatunkkal.";

# Version 5.2

$_LANG['yourclientareahostingaddons'] = "A következő kiegészítői vannak ehhez a termékhez.";
$_LANG['loginrequired'] = "Bejelentkezés szükséges";
$_LANG['unsubscribe'] = "Leiratkozás";
$_LANG['emailoptout'] = "Hírlevél Opt-out";
$_LANG['newsletterunsubscribe'] = "Hírlevél leiratkozás";
$_LANG['emailoptoutdesc'] = "Pipálja be, ha leszeretne iratkozni hírlevelünkről";
$_LANG['alreadyunsubscribed'] = "Ön már leiratkozott hírleveleinkről.";
$_LANG['newsletterresubscribe'] = "Ha újra fel akar iratkozni hírlevelünkre bármikor megteheti azt az %sAdataim%s részlegen az ügyfélterületünkön.";
$_LANG['unsubscribehashinvalid'] = "A leiratkozás sikertelen volt, kérjük, lépjen kapcsolatba ügyfélszoláatunkkal.";
$_LANG['unsubscribesuccess'] = "Sikeresen leiratkozott";
$_LANG['newsletterremoved'] = "Köszönjük, Az Ön e-mail címe el lett távolítva a levelezőlistánkról.";
$_LANG['erroroccured'] = "Hiba történt";
$_LANG['pwresetsuccessdesc'] = "A jelszavát visszaállítottuk. %sKattintson ide%s, hogy továbblépjen az ügyfélterületre...";
$_LANG['pwresetenternewpw'] = "Kérjük, adja meg a kívánt új jelszót.";
$_LANG['ordererrorsbudomainbanned'] = "Az aldomain előtag amit megadott nem engedélyezett - próbáljon meg egy másikat";

$_LANG['ticketfeedbacktitle'] = "Visszajelzés kérése a hibajegyről";

$_LANG['nosupportdepartments'] = "Nem található támogatási részleg. Kérjük, próbálja meg később.";

$_LANG['feedbackclosed'] = "Visszajelzés küldése nem lehetséges, amíg a hibajegyet le nem zárják";
$_LANG['feedbackprovided'] = "Már küldtek egy visszajelzést erre a hibajegyre";
$_LANG['feedbackthankyou'] = "Köszönjük, hogy időt szánt észrevételei visszajelzésére.";
$_LANG['feedbackreceived'] = "Beadványát fogadtuk";
$_LANG['feedbackdesc'] = "Kérjük, szánjon egy kis időt arra, hogy kitölti az alábbi kérdőívet a támogatói csapatunkkal kapcsolatos élményeiről.";
$_LANG['feedbackclickreview'] = "A hibajegy felülvizsgálatához kattintson ide";
$_LANG['feedbackopenedat'] = "Megnyitva";
$_LANG['feedbacklastreplied'] = "utolsó válasz";
$_LANG['feedbackstaffinvolved'] = "Résztvevő Staff";
$_LANG['feedbacktotalduration'] = "teljes időtartam";
$_LANG['feedbackpleaserate1'] = "Kérjük, értékelje (egy skálán 1-től 10-ig) mennyire elégedett";
$_LANG['feedbackpleasecomment1'] = "Kérjük, fejtse ki, hogy mennyire elégedett";
$_LANG['feedbackhandled'] = "kezelte ezt a támogatási kérelmet";
$_LANG['feedbackworst'] = "legrosszabb";
$_LANG['feedbackbest'] = "Kiválló";
$_LANG['feedbackimprove'] = "Hogy tehetnénk jobbá a tapasztalait a jövőben?";
$_LANG['pleaserate2'] = "kezelte ezt a támogatási kérelmet";
$_LANG['returnclient'] = "Vissza az ügyfélfiókba";

$_LANG['clientareanavsecurity'] = "Biztonsági beállítások";
$_LANG['twofactorauth'] = "Két-tényezős Hitelesítés";
$_LANG['twofaenable'] = "Két-tényezős Hitelesítés engedélyezése";
$_LANG['twofadisable'] = "Két-tényezős Hitelesítés letiltása";
$_LANG['twofaenableclickhere'] = "Kattintson ide az engedélyezéshez";
$_LANG['twofadisableclickhere'] = "Kattintson ide a letiltáshoz";
$_LANG['twofaenforced'] = "Az Ön biztonsága érdekében, megkérjük engedélyezze a Két-tényezős Hitelesítés mielőtt folytatná. Ez az oldal végigvezeti Önt a beállítás folyamatáról.";
$_LANG['twofasetup'] = "Két-tényezős Hitelesítés Beállítása Folyamat";
$_LANG['twofasetupgetstarted'] = "Kezdés";
$_LANG['twofaactivationintro'] = "Két-tényezős Hitelesítés egy extra védelmet ad a bejelentkezéseihez. Ha engedélyezve és konfigurálva van, minden egyes alkalommal amikor bejelentkezik meg kell adnia mind a felhasználónevét és jelszavát, valamint egy második tényezőt, mint például egy biztonsági kódot.";
$_LANG['twofaactivationmultichoice'] = "A folytatáshoz válassza ki alább a kívánt Két-tényezős Hitelesítés módszerét.";
$_LANG['twofadisableintro'] = "Ha ki szeretné kapcsolni a  kérjük, erősítse meg a jelszavát az alábbi mezőben.";
$_LANG['twofaactivationerror'] = "Hiba történt amikor megpróbáltuk aktiválni az Ön fiókjára a  -t. Kérjük, próbálja újra.";
$_LANG['twofamoduleerror'] = "Hiba történt a modul betöltése közben. Kérjük, próbája újra.";
$_LANG['twofaactivationcomplete'] = "Két-tényezős Hitelesítés beállítása sikeres!";
$_LANG['twofadisableconfirmation'] = "Két-tényezős Hitelesítés most már le van tiltva az Ön fiókjára.";
$_LANG['twofabackupcodeis'] = "Az Ön tartalék kódja";
$_LANG['twofanewbackupcodeis'] = "Az ön új tartalék kódja";
$_LANG['twofabackupcodelogin'] = "Adja meg a tartalék kódot a bejelentkezéshez";
$_LANG['twofabackupcodeexpl'] = "Írja le egy papírra és tartsa biztonságban.<br /> Erre szüksége lehet, ha valaha elveszítené a második tényezős készülékét, vagy nem lenne elérhető Önnek.";
$_LANG['twofaconfirmpw'] = "Adja meg a jelszavát";
$_LANG['twofa2ndfactorreq'] = "A második tényező megadása is szükséges a bejelentkezés befejezéséhez.";
$_LANG['twofa2ndfactorincorrect'] = "A második tényező amit megadott helytelen. Kérjük, próbálja újra.";
$_LANG['twofabackupcodereset'] = "A tartalékkóddal való bejelentkezés sikeres volt.<br />A tartalékkódot csak egyszer lehet használni. Ez a kód most törölésre kerül.";
$_LANG['twofacantaccess2ndfactor'] = "Nem fér hozzá második tényezős készülékéhez?";
$_LANG['twofaloginusingbackupcode'] = "Belépés tartalékkód használatával";
$_LANG['twofageneralerror'] = "Hiba történt a modul betöltése közben. Kérjük, próbája újra.";

$_LANG['continue'] = "Folytatás";
$_LANG['disable'] = "Letiltás";
$_LANG['manage'] = "Kezel";
