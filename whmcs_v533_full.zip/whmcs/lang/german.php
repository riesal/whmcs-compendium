<?php
/**
 * WHMCS Language File
 * German (de)
 *
 * Please Note: These language files are overwritten during software updates
 * and therefore editing of these files directly is not advised. Instead we
 * recommend that you use overrides to customise the text displayed in a way
 * which will be safely preserved through the upgrade process.
 *
 * For instructions on overrides, please visit:
 *   http://docs.whmcs.com/Language_Overrides
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

if (!defined("WHMCS")) die("This file cannot be accessed directly");

$_LANG['isocode'] = "de";

$_LANG['accountinfo'] = "Account Information";
$_LANG['accountstats'] = "Account Statistiken";
$_LANG['addfunds'] = "Guthaben / Vorauszahlung hinzufügen";
$_LANG['addfundsamount'] = "Betrag";
$_LANG['addfundsmaximum'] = "Maximaler Einzahlungsbetrag";
$_LANG['addfundsmaximumbalance'] = "Maximales Guthaben";
$_LANG['addfundsmaximumbalanceerror'] = "Maximales Guthaben ist";
$_LANG['addfundsmaximumerror'] = "Maximaler Einzahlungsbetrag ist";
$_LANG['addfundsminimum'] = "Minimaler Einzahlungsbetrag";
$_LANG['addfundsminimumerror'] = "Minimaler Einzahlungsbetrag ist";
$_LANG['addmore'] = "Add More";
$_LANG['addtocart'] = "Zum Warenkorb hinzufügen";
$_LANG['affiliatesactivate'] = "Aktiviere Partneraccount";
$_LANG['affiliatesamount'] = "Betrag";
$_LANG['affiliatesbalance'] = "Aktueller Saldo";
$_LANG['affiliatesbullet1'] = "Anfangsbonus in Ihrem Partnerkonto";
$_LANG['affiliatesbullet2'] = "von jeder Zahlung der Kunden, die Sie vermittelt haben. Dies gilt für die gesamte Dauer des Abonnements.";
$_LANG['affiliatescommission'] = "Kommission";
$_LANG['affiliatesdescription'] = "Klicken Sie hier, um Vermittlungspartner (Affiliate) zu werden, oder um Ihre Einkünfte zu sehen";
$_LANG['affiliatesdisabled'] = "Wir bieten zur Zeit kein Partnerprogramm an.";
$_LANG['affiliatesearn'] = "Verdienen";
$_LANG['affiliatesearningstodate'] = "Einkommen insgesamt bis heute";
$_LANG['affiliatesfootertext'] = "Wenn Sie jemanden mit Ihrer einzigartigen Vermittlungs-ID an unsere Webseite weiterleiten, wird auf diesem Computer ein Cookie mit der Vermittlungs-ID abgelegt. Wenn dieser Besucher später zurückkehrt und eine Dienstleistung bucht erhalten Sie die Kommission ebenfalls";
$_LANG['affiliateshostingpackage'] = "Hosting Paket";
$_LANG['affiliatesintrotext'] = "Aktivieren Sie Ihr Partnerkonto (Affiliate) heute:";
$_LANG['affiliateslinktous'] = "Link zu uns";
$_LANG['affiliatesnosignups'] = "Sie haben bis heute noch keine Registrierungen erhalten";
$_LANG['affiliatesrealtime'] = "Diese Statistiken werden in Echtzeit angezeigt und werden laufend aktualisiert";
$_LANG['affiliatesreferallink'] = "Ihr einzigartiger Partnerlink";
$_LANG['affiliatesreferals'] = "Ihre Vermittlungen";
$_LANG['affiliatesregdate'] = "Registrierungsdatum";
$_LANG['affiliatesrequestwithdrawal'] = "Überweisungsauftrag";
$_LANG['affiliatessignupdate'] = "Registrierungsdatum";
$_LANG['affiliatesstatus'] = "Status";
$_LANG['affiliatestitle'] = "Partner";
$_LANG['affiliatesvisitorsreferred'] = "Zahl der vermittelten Besucher";
$_LANG['affiliateswithdrawalrequestsuccessful'] = "Ihr Überweisungsauftrag wurde übermittelt. Sie werden in Kürze kontaktiert.";
$_LANG['affiliateswithdrawn'] = "Insgesamt abgehobener Betrag";
$_LANG['all'] = "Alle";
$_LANG['alreadyregistered'] = "Sind Sie bereits Kunde?";
$_LANG['announcementsdescription'] = "Neuigkeiten und Ankündigungen";
$_LANG['announcementsnone'] = "Es gibt keine Ankündigungen";
$_LANG['announcementsrss'] = "RSS Feed anzeigen";
$_LANG['announcementstitle'] = "Ankündigungen";
$_LANG['bannedbanexpires'] = "Ablauf der Sperrung";
$_LANG['bannedbanreason'] = "Sperrungsgrund";
$_LANG['bannedhasbeenbanned'] = "wurde gesperrt";
$_LANG['bannedtitle'] = "Gesperrte IP";
$_LANG['bannedyourip'] = "Ihre IP";
$_LANG['cartaddons'] = "Zusatzpakete / Produkterweiterungen";
$_LANG['cartbrowse'] = "Produkte & Services";
$_LANG['cartconfigdomainextras'] = "Domain-Extras konfigurieren";
$_LANG['cartconfigoptionsdesc'] = "Bei diesem Produkt gibt es weitere Optionen zur Konfiguration. Bitte wählen Sie die Option aus, die Sie hinzufügen möchten.";
$_LANG['cartconfigserver'] = "Server konfigurieren";
$_LANG['cartcustomfieldsdesc'] = "Für dieses Produkt benötigen wir weitere Informationen zur Ausführung des Auftrages.";
$_LANG['cartdomainsconfig'] = "Domainkonfiguration";
$_LANG['cartdomainsconfigdesc'] = "Hier können Sie ihre Domainkonfiguration vornehmen, Erweiterungen hinzufügen und benötigte Informationen eingeben.";
$_LANG['cartdomainshashosting'] = "Hosting vorhanden";
$_LANG['cartdomainsnohosting'] = "Noch kein Hosting-Paket!? Klicken Sie bitte hier.";
$_LANG['carteditproductconfig'] = "Konfiguration anpassen";
$_LANG['cartempty'] = "Ihr Warenkorb ist leer.";
$_LANG['cartemptyconfirm'] = "Warenkorb wirklich leeren?";
$_LANG['cartexistingclientlogin'] = "Kundenanmeldung";
$_LANG['cartexistingclientlogindesc'] = "Wenn Sie bereits Kunde sind melden Sie sich bitte an. Ihre Bestellung wird dann automatisch Ihrem Kundenkonto zugeordnet.";
$_LANG['cartnameserversdesc'] = "Wenn Sie eigene Nameserver benutzen möchten geben Sie diese bitte hier an. Standardmäßig stellen wir unsere Nameserver zur Verfügung.";
$_LANG['cartproductaddons'] = "Zusatzpakete / Produkterweiterungen";
$_LANG['cartproductaddonschoosepackage'] = "Produktauswahl";
$_LANG['cartproductaddonsnone'] = "Keine Erweiterung für das gewählte Produkt verfügbar.";
$_LANG['cartproductconfig'] = "Produktkonfiguration";
$_LANG['cartproductdesc'] = "Hier sehen Sie die von Ihnen gewählten Produkte und Optionen.";
$_LANG['cartproductdomain'] = "Domains";
$_LANG['cartproductdomainchoose'] = "Bitte auswählen";
$_LANG['cartproductdomaindesc'] = "Das von Ihnen gewählte Produkt erfordert die Registrierung eines Domainnamens. Bitte wählen Sie eine Option.";
$_LANG['cartproductdomainuseincart'] = "Domain aus meinem Warenkorb benutzen";
$_LANG['cartremove'] = "Entfernen";
$_LANG['cartremoveitemconfirm'] = "Aus Ihrem Warenkorb entfernen?";
$_LANG['carttaxupdateselections'] = "MwSt. wird abhängig vom Land berechnet. Bitte hier zur Neuberechnung klicken.";
$_LANG['carttaxupdateselectionsupdate'] = "Aktualisieren";
$_LANG['carttitle'] = "Mein Warenkorb";
$_LANG['changessavedsuccessfully'] = "Changes Saved Successfully!";
$_LANG['checkavailability'] = "Verfügbarkeit prüfen";
$_LANG['checkout'] = "zur Kasse";
$_LANG['choosecurrency'] = "Choose Currency";
$_LANG['choosedomains'] = "Domains auswählen";
$_LANG['clickheretologin'] = "Klicken Sie hier zur Anmeldung";
$_LANG['clientareaaccountaddons'] = "Account Zusatzpakete / Optionen";
$_LANG['clientareaactive'] = "Aktiv";
$_LANG['clientareaaddfundsdisabled'] = "We do not allow depositing funds in advance with us at the current time.";
$_LANG['clientareaaddfundsnotallowed'] = "Sie benötigen mindestens eine aktive Bestellung um ein Guthaben hinzuzufügen!";
$_LANG['clientareaaddon'] = "Zusatzpaket";
$_LANG['clientareaaddonorderconfirmation'] = "Vielen Dank. Das untenstehende Zusatzpaket wurde zur Bestellung hinzugefügt. Bitte wählen Sie nun die gewünschte Zahlungsmethode";
$_LANG['clientareaaddonpricing'] = "Preise";
$_LANG['clientareaaddonsfor'] = "Zusatzpakete für";
$_LANG['clientareaaddress1'] = "Adresse 1";
$_LANG['clientareaaddress2'] = "Adresse 2";
$_LANG['clientareabwlimit'] = "Datentransfer Limits";
$_LANG['clientareabwusage'] = "Datentransfer Verbrauch";
$_LANG['clientareacancel'] = "Kundenaccount löschen";
$_LANG['clientareacancelconfirmation'] = "Vielen Dank. Der Stornierungsauftrag wurde übermittelt. Falls Sie diesen Auftrag aus Versehen geschickt haben, senden Sie uns bitte umgehend ein Supportticket, bevor wir Ihren Account löschen.";
$_LANG['clientareacancelinvalid'] = "Fehler! Der Auftrag zur Stornierung dieses Accounts ist bereits in Bearbetung oder der Account konnte nicht gefunden werden.";
$_LANG['clientareacancellationendofbillingperiod'] = "Bei Ablauf der aktuellen Periode";
$_LANG['clientareacancellationimmediate'] = "Sofort";
$_LANG['clientareacancellationtype'] = "Stornierungstyp";
$_LANG['clientareacancelled'] = "Storniert";
$_LANG['clientareacancelproduct'] = "Auftrag zur Stornierung von";
$_LANG['clientareacancelreason'] = "Grund für die Stornierung";
$_LANG['clientareacancelrequest'] = "Auftrag zur Account-Stornierung";
$_LANG['clientareacancelrequestbutton'] = "Auftrag stornieren";
$_LANG['clientareachangepassword'] = "Passwort ändern";
$_LANG['clientareachangesuccessful'] = "Ihre Angaben wurden erfolgreich aktualisiert";
$_LANG['clientareachoosecontact'] = "Kontakt wählen";
$_LANG['clientareacity'] = "Ort";
$_LANG['clientareacompanyname'] = "Firma";
$_LANG['clientareaconfirmpassword'] = "Passwort bestätigen";
$_LANG['clientareacontactsemails'] = "Email-Einstellungen";
$_LANG['clientareacontactsemailsdomain'] = "Domain-Email - Erneuerungshinweise, Registrierungsbestätigungen etc.";
$_LANG['clientareacontactsemailsgeneral'] = "Allgemeine Email - Bekanntmachungen, Passworterinnerungen etc. ";
$_LANG['clientareacontactsemailsinvoice'] = "Rechnungs-Email - Rechnungen, Mahnungen etc.";
$_LANG['clientareacontactsemailsproduct'] = "Produkt-Email - Bestellungen, Willkommens-Emails etc.";
$_LANG['clientareacontactsemailssupport'] = "Support-Email - Supportticket Benachrichtigungen";
$_LANG['clientareacountry'] = "Land";
$_LANG['clientareacurrentsecurityanswer'] = "Bitte geben Sie Ihre korrekte Antwort ein";
$_LANG['clientareacurrentsecurityquestion'] = "Bitte geben Sie Ihre aktuelle Sicherheitsfrage ein";
$_LANG['clientareadeletecontact'] = "Kontakt löschen";
$_LANG['clientareadeletecontactareyousure'] = "Diesen Kontakt wirklich löschen?";
$_LANG['clientareadescription'] = "Klicken Sie hier um Ihr Profil zu ändern, Rechnungsinformationen anzuzeigen und zusätzliche Dienstleistungen zu bestellen";
$_LANG['clientareadisklimit'] = "Speicherplatz Limits";
$_LANG['clientareadiskusage'] = "Speicherplatz Verbrauch";
$_LANG['clientareadomainexpirydate'] = "Ablaufdatum";
$_LANG['clientareadomainnone'] = "Keine Domains bei uns registriert";
$_LANG['clientareaemail'] = "Email-Adresse";
$_LANG['clientareaemails'] = "Korrespondenz";
$_LANG['clientareaemailsdate'] = "Versanddatum";
$_LANG['clientareaemailsintrotext'] = "Unten finden Sie den Verlauf aller Nachrichten, die wir an Sie geschickt haben. Sie können bequem die gesamte Korrespondenz anzeigen, falls Sie unsere Emails nicht mehr zur Verfügung haben.";
$_LANG['clientareaemailssubject'] = "Nachricht Betreff";
$_LANG['clientareaerroraddress1'] = "Sie haben keine Adresszeile 1 eingegeben";
$_LANG['clientareaerroraddress12'] = "Ihr Adresse kann nur Buchstaben, Zahlen und Leerzeichen enthalten";
$_LANG['clientareaerrorbannedemail'] = "Diese Emailadresse ist bei uns nicht erlaubt. Bitte geben Sie eine andere Emailadresse an.";
$_LANG['clientareaerrorcity'] = "Sie haben keinen Ort eingegeben";
$_LANG['clientareaerrorcity2'] = "Ihr Ort kann nur Buchstaben und Leerzeichen enthalten";
$_LANG['clientareaerrorcountry'] = "Bitte wählen Sie Ihr Land aus der Auswahlliste";
$_LANG['clientareaerroremail'] = "Sie haben keine Emailadresse eingegeben";
$_LANG['clientareaerroremailinvalid'] = "Die angegebene Emailadresse ist ungültig";
$_LANG['clientareaerrorfirstname'] = "Sie haben keinen Vornamen eingegeben";
$_LANG['clientareaerrorfirstname2'] = "Ihr Vorname kann nur Buchstaben enthalten";
$_LANG['clientareaerrorisrequired'] = "ist erforderlich";
$_LANG['clientareaerrorlastname'] = "Sie haben keinen Nachnamen eingegeben";
$_LANG['clientareaerrorlastname2'] = "Ihr Nachname kann nur Buchstaben enthalten";
$_LANG['clientareaerroroccured'] = "Es gab einen Fehler, bitte versuchen Sie es später erneut.";
$_LANG['clientareaerrorpasswordconfirm'] = "Sie haben das Passwort nicht bestätigt";
$_LANG['clientareaerrorpasswordnotmatch'] = "Die Passwortbestätigung ist nicht gleich wie das Passwort";
$_LANG['clientareaerrorphonenumber'] = "Sie haben keine Telefonnummer eingegeben";
$_LANG['clientareaerrorphonenumber2'] = "Ihre Telefonnummer kann nur Zahlen und Leerzeichen enthalten";
$_LANG['clientareaerrorpostcode'] = "Sie haben keine Postleitzahl eingegeben";
$_LANG['clientareaerrorpostcode2'] = "Ihre Postleitzahl kann nur Buchstaben, Zahlen und Leerzeichen enthalten";
$_LANG['clientareaerrors'] = "Folgende Fehler sind aufgetreten:";
$_LANG['clientareaerrorstate'] = "Sie haben kein Bundesland / Region angegeben";
$_LANG['clientareaexpired'] = "Abgelaufen";
$_LANG['clientareafirstname'] = "Vorname";
$_LANG['clientareafraud'] = "Betrugsversuch";
$_LANG['clientareafullname'] = "Name";
$_LANG['clientareaheader'] = "Willkommen in unserem Kundencenter. Hier können Sie Ihre persönlichen Daten anzeigen und aktualisieren, Ihre Hostingaccounts und Domains anzeigen, Supportanfragen absenden und zusätzliche Produkte & Dienstleistungen bestellen.";
$_LANG['clientareahostingaddons'] = "Zusatzpakete";
$_LANG['clientareahostingaddonsintro'] = "You have the following addons for this product.";
$_LANG['clientareahostingaddonsview'] = "Ansehen";
$_LANG['clientareahostingamount'] = "Betrag";
$_LANG['clientareahostingdomain'] = "Domain";
$_LANG['clientareahostingnextduedate'] = "Erneuerungsdatum";
$_LANG['clientareahostingpackage'] = "Paket";
$_LANG['clientareahostingregdate'] = "Registrierungsdatum";
$_LANG['clientarealastname'] = "Nachname";
$_LANG['clientarealastupdated'] = "Zuletzt aktualisiert";
$_LANG['clientarealeaveblank'] = "Leer lassen, außer Sie möchten Ihr Passwort ändern";
$_LANG['clientareamodifydomaincontactinfo'] = "Domain-Kontaktinformation ändern";
$_LANG['clientareamodifynameservers'] = "Nameserver ändern";
$_LANG['clientareamodifywhoisinfo'] = "WHOIS Kontaktinformationen ändern";
$_LANG['clientareanameserver'] = "Nameserver";
$_LANG['clientareanavaddcontact'] = "Kontakt hinzufügen";
$_LANG['clientareanavchangecc'] = "Kreditkartendetails anpassen";
$_LANG['clientareanavchangepw'] = "Passwort ändern";
$_LANG['clientareanavdetails'] = "Kundenprofil";
$_LANG['clientareanavdomains'] = "Domains";
$_LANG['clientareanavhome'] = "Kundencenter Home";
$_LANG['clientareanavlogout'] = "Abmelden";
$_LANG['clientareanavorder'] = "Produkte & Dienstleistungen bestellen";
$_LANG['clientareanavsecurityquestions'] = "Sicherheitsfrage ändern";
$_LANG['clientareanavservices'] = "Meine Services";
$_LANG['clientareanavsupporttickets'] = "Supporttickets";
$_LANG['clientareanocontacts'] = "Keine Kontaktdaten gefunden";
$_LANG['clientareapassword'] = "Passwort";
$_LANG['clientareapending'] = "In Bearbeitung";
$_LANG['clientareapendingtransfer'] = "Transfer in Bearbeitung";
$_LANG['clientareaphonenumber'] = "Tel.";
$_LANG['clientareapostcode'] = "PLZ";
$_LANG['clientareaproductdetails'] = "Produkteinzelheiten";
$_LANG['clientareaproducts'] = "Produkte & Dienstleistungen";
$_LANG['clientareaproductsnone'] = "Keine Produkte & Dienstleistungen bestellt";
$_LANG['clientarearegistrationperiod'] = "Registrierungsperiode";
$_LANG['clientareasavechanges'] = "Änderungen speichern";
$_LANG['clientareasecurityanswer'] = "Bitte geben Sie eine Antwort ein";
$_LANG['clientareasecurityconfanswer'] = "Bitte bestätigen Sie Ihre Antwort";
$_LANG['clientareasecurityquestion'] = "Bitte wählen Sie eine Sicherheitsfrage";
$_LANG['clientareaselectcountry'] = "Land auswählen";
$_LANG['clientareasetlocking'] = "Sperre setzen";
$_LANG['clientareastate'] = "Bundesland / Region";
$_LANG['clientareastatus'] = "Status";
$_LANG['clientareasuspended'] = "Ausgesetzt";
$_LANG['clientareaterminated'] = "Storniert";
$_LANG['clientareaticktoenable'] = "zum Aktivieren bitte ankreuzen";
$_LANG['clientareatitle'] = "Kundenlogin";
$_LANG['clientareaunlimited'] = "Unbegrenzt";
$_LANG['clientareaupdatebutton'] = "Aktualisieren";
$_LANG['clientareaupdateyourdetails'] = "Persönliche Daten ändern";
$_LANG['clientareaused'] = "Verbraucht";
$_LANG['clientareaviewaddons'] = "Mögliche Zusatzpakete / Optionen anzeigen";
$_LANG['clientareaviewdetails'] = "Einzelheiten anzeigen";
$_LANG['clientlogin'] = "Kundenlogin";
$_LANG['clientregisterheadertext'] = "Um ein neues Konto zu eröffnen füllen Sie bitte nachstehendes Formular aus. Die benötigten Felder sind mit * markiert.";
$_LANG['clientregistertitle'] = "Registrieren";
$_LANG['clientregisterverify'] = "Registrierung überprüfen";
$_LANG['clientregisterverifydescription'] = "Bitte geben Sie den Code auf dem Bild in dieses Feld ein. Dies ist ein Sicherheitsmechanismus.";
$_LANG['clientregisterverifyinvalid'] = "Der von Ihnen eingegebene Code ist nicht identisch mit dem Code auf dem Bild.";
$_LANG['closewindow'] = "Fenster schließen";
$_LANG['completeorder'] = "Kaufen";
$_LANG['confirmnewpassword'] = "Neues Passwort bestätigen";
$_LANG['contactemail'] = "Email";
$_LANG['contacterrormessage'] = "Sie haben keine Nachricht eingegeben";
$_LANG['contacterrorname'] = "Sie haben keinen Namen angegeben";
$_LANG['contacterrorsubject'] = "Sie haben keinen Betreff angegeben";
$_LANG['contactheader'] = "Um uns zu kontaktieren füllen Sie bitte nachstehendes Formular aus";
$_LANG['contactmessage'] = "Nachricht";
$_LANG['contactname'] = "Name";
$_LANG['contactsend'] = "Nachricht senden";
$_LANG['contactsent'] = "Ihre Nachricht wurde abgeschickt";
$_LANG['contactsubject'] = "Betreff";
$_LANG['contacttitle'] = "Kontaktieren Sie uns";
$_LANG['continueshopping'] = "Einkauf fortsetzen";
$_LANG['creditcard'] = "Mit Kreditkarte bezahlen";
$_LANG['creditcard3dsecure'] = "Als Teil unserer Sicherheitsvorkehrungen gegen Mißbrauch werden Sie nun gebeten, Ihre 'Verified by Visa' oder 'Mastercard SecureCode' Identifikation durchzuführen, sofern Sie für diese Dienste freigeschaltet sind.";
$_LANG['creditcardcardexpires'] = "Ablaufdatum";
$_LANG['creditcardcardissuenum'] = "Rechnungsnummer";
$_LANG['creditcardcardnumber'] = "Kreditkartennummer";
$_LANG['creditcardcardstart'] = "Startdatum";
$_LANG['creditcardcardtype'] = "Kreditkartentyp";
$_LANG['creditcardccvinvalid'] = "Der Kartensicherheitscode ist ungültig";
$_LANG['creditcardconfirmation'] = "Vielen Dank! Ihre Kreditkartenzahlung wurde akzeptiert und Ihre Karte mit dem Betrag belastet. Sie erhalten in Kürze eine Bestätigung per Email.";
$_LANG['creditcardcvvnumber'] = "CVV/CVC2 Nummer";
$_LANG['creditcardcvvwhere'] = "Wo finde ich das?";
$_LANG['creditcarddeclined'] = "Die angegebene Kreditkarte wurde vom Finanzinstitut abgewiesen. Bitte versuchen Sie eine andere Kreditkarte oder kontaktieren Sie uns.";
$_LANG['creditcarddetails'] = "Kreditkartendetails";
$_LANG['creditcardenterexpirydate'] = "Sie haben kein Ablaufdatum (Exp. Date) angegeben";
$_LANG['creditcardenternewcard'] = "Neue Kreditkarte unten eingeben";
$_LANG['creditcardenternumber'] = "Sie haben Ihre Kartennummer nicht eingegeben";
$_LANG['creditcardinvalid'] = "Die angegebene Kreditkarte wurde vom Finanzinstitut als ungültig abgewiesen. Bitte versuchen Sie eine andere Kreditkarte oder kontaktieren Sie uns.";
$_LANG['creditcardnumberinvalid'] = "Die Kreditkartennummer wie von Ihnen eingegeben ist ungültig";
$_LANG['creditcardsecuritynotice'] = "Um Risiken zu minimieren findet die Datenübermittlung an das Kreditinstitut verschlüsselt statt.";
$_LANG['creditcarduseexisting'] = "Existierende Kreditkarte verwenden";
$_LANG['customfieldvalidationerror'] = "Wert ist ungültig";
$_LANG['days'] = "Tage";
$_LANG['defaultbillingcontact'] = "Rechnungsempfänger";
$_LANG['domainalternatives'] = "Versuchen Sie folgende Alternativen:";
$_LANG['domainavailable'] = "Frei! Jetzt bestellen";
$_LANG['domainavailable1'] = "Glückwunsch!";
$_LANG['domainavailable2'] = "ist noch frei!";
$_LANG['domainavailableexplanation'] = "Um die Domain zu registrieren klicken Sie bitte untenstehenden Link";
$_LANG['domainbulksearch'] = "Erweiterte Domainsuche";
$_LANG['domainbulksearchintro'] = "Mit der 'Erweiterten Domainsuche' können Sie bis zu 20 Domains auf einmal abfragen.  Geben Sie in nachstehendes Formular die Domains ein, eine per Zeile, ohne 'www.' oder 'http://' , aber bitte inklusive der Domainendung (TLD).";
$_LANG['domainbulktransferdescription'] = "Sie können heute noch Ihre bestehenden Domains zu uns transferieren. Um zu beginnen geben Sie bitte die Domains, eine per Zeile, in das folgende Feld ein, ohne 'www.' oder 'http://'.";
$_LANG['domainbulktransfersearch'] = "Massen-Domaintransfer";
$_LANG['domaincheckerdescription'] = "Überprüfen der Verfügbarkeit einer Domain";
$_LANG['domaincontactinfo'] = "Kontaktinformationen";
$_LANG['domaincurrentrenewaldate'] = "aktuelles Erneuerungsdatum";
$_LANG['domaindnsaddress'] = "Adresse";
$_LANG['domaindnshostname'] = "Hostname";
$_LANG['domaindnsmanagement'] = "DNS-Verwaltung";
$_LANG['domaindnsmanagementdesc'] = "Leiten Sie Ihre Domain auf eine Webseite weiter, indem Sie auf die IP-Adresse verweisen, oder leiten Sie sie auf eine andere Seite weiter, oder leiten Sie sie auf eine temporäre Seite weiter (bekannt als 'Domain Parking'), und mehr. Diese Einträge sind auch bekannt als Subdomains.";
$_LANG['domaindnsrecordtype'] = "Registrierungstyp";
$_LANG['domainemailforwarding'] = "Email-Weiterleitung";
$_LANG['domainemailforwardingdesc'] = "Wenn der weiterleitende Emailserver feststellt, dass die anzusprechende Emailadresse ungültig ist, so werden wir den Weiterleitungseintrag automatisch deaktivieren. Bitte prüfen Sie die Emailadresse, auf die weitergeleitet werden soll, bevor Sie sie wieder aktivieren. Die Änderungen an bestehenden Weiterleitungseinträgen werden nicht in unter einer Stunde wirksam sein.";
$_LANG['domainemailforwardingforwardto'] = "Weiterleiten an";
$_LANG['domainemailforwardingprefix'] = "Prefix";
$_LANG['domaineppcode'] = "EPP/Authcode";
$_LANG['domaineppcodedesc'] = "Wir benötigen zum Providerwechsel einen sogenannten Authcode. Diesen erhalten Sie von Ihrem alten Provider.";
$_LANG['domaineppcoderequired'] = "Bitte geben Sie den EPP/Authcode ein.";
$_LANG['domainerror'] = "Bei der Anfrage gab es einen Fehler:";
$_LANG['domainerrornodomain'] = "Bitte geben Sie einen gültigen Domainnamen ein";
$_LANG['domainerrortoolong'] = "Die eingegebene Domain ist zu lang. Domains können maximal 67 Zeichen lang sein.";
$_LANG['domaingeteppcode'] = "EPP/Authcode holen";
$_LANG['domaingeteppcodeemailconfirmation'] = "Die EPP/Authcode Anfrage war erfolgreich. Wir senden ihn an die Inhaberadresse Ihrer Domain.";
$_LANG['domaingeteppcodeexplanation'] = "Der EPP/Authcode ist kurz gesagt ein Passwort für eine Domain. Dies stellt sicher dass nur der Inhaber der Domain diese auch umziehen kann. Sie benötigen den EPP/Authcode zum Provider-Transfer.";
$_LANG['domaingeteppcodefailure'] = "Fehler bei der Anfrage des EPP/Authcode:";
$_LANG['domaingeteppcodeis'] = "EPP/Authcode lautet:";
$_LANG['domainidprotection'] = "Identitätsschutz";
$_LANG['domainintrotext'] = "Geben Sie bitte den zu suchenden Domainnamen an und klicken Sie 'Suchen', um zu prüfen ob die gewünschte Domain noch frei ist.";
$_LANG['domainlookupbutton'] = "Suchen";
$_LANG['domainmanagementtools'] = "Verwaltungstools";
$_LANG['domainminyears'] = "Min. Jahre";
$_LANG['domainmoreinfo'] = "Mehr Informationen";
$_LANG['domainname'] = "Domain Name";
$_LANG['domainnameserver1'] = "Nameserver 1";
$_LANG['domainnameserver2'] = "Nameserver 2";
$_LANG['domainnameserver3'] = "Nameserver 3";
$_LANG['domainnameserver4'] = "Nameserver 4";
$_LANG['domainnameserver5'] = "Nameserver 5";
$_LANG['domainnameservers'] = "Nameserver";
$_LANG['domainordernow'] = "Jetzt bestellen!";
$_LANG['domainorderrenew'] = "Domain Verlängerung";
$_LANG['domainprice'] = "Preis";
$_LANG['domainregisterns'] = "Nameserver registrieren";
$_LANG['domainregisternscurrentip'] = "aktuelle IP-Adresse";
$_LANG['domainregisternsdel'] = "Nameserver löschen";
$_LANG['domainregisternsdelsuccess'] = "Der Nameserver wurde erfolgreich gelöscht.";
$_LANG['domainregisternsexplanation'] = "An dieser Stelle können Sie Ihre Nameserver verwalten (eg. NS1.ihredomain.com, NS2.ihredomain.com...).";
$_LANG['domainregisternsip'] = "IP-Adresse";
$_LANG['domainregisternsmod'] = "Nameserver-IP ändern";
$_LANG['domainregisternsmodsuccess'] = "Der Nameserver wurde erfolgreich geändert.";
$_LANG['domainregisternsnewip'] = "neue IP-Adresse";
$_LANG['domainregisternsns'] = "Nameserver";
$_LANG['domainregisternsreg'] = "Nameserver registrieren";
$_LANG['domainregisternsregsuccess'] = "Der Nameserver wurde erfolgreich registriert.";
$_LANG['domainregistrantchoose'] = "Bitte wählen Sie den zu benutzenden Kontakt";
$_LANG['domainregistrantinfo'] = "Domaininhaber";
$_LANG['domainregistrarlock'] = "Registrarsperre";
$_LANG['domainregistrarlockdesc'] = "Registrarsperre aktivieren (empfohlen). Unerlaubte Domainübertragungen / Transfers werden so verhindert.";
$_LANG['domainregistration'] = "Domainregistrierung";
$_LANG['domainregistryinfo'] = "Domainregistry Information";
$_LANG['domainregnotavailable'] = "keine Angabe";
$_LANG['domainrenew'] = "Domain verlängern";
$_LANG['domainrenewal'] = "Domain Verlängerung";
$_LANG['domainrenewalprice'] = "Erneuerung";
$_LANG['domainrenewdesc'] = "Tipp: Sichern Sie sich Ihre Domain gleich für mehrere Jahre!";
$_LANG['domainsautorenew'] = "automatische Verlängerung";
$_LANG['domainsautorenewdisable'] = "automatische Verlängerung deaktivieren";
$_LANG['domainsautorenewdisabled'] = "Deaktiviert";
$_LANG['domainsautorenewdisabledwarning'] = "Die automatische Verlängerung ist deaktiviert. Sofern die Domain nicht manuell verlängert wird, wird diese am Ende der Laufzeit freigegeben.";
$_LANG['domainsautorenewenable'] = "automatische Verlängerung aktivieren";
$_LANG['domainsautorenewenabled'] = "Aktiv";
$_LANG['domainsautorenewstatus'] = "aktueller Status";
$_LANG['domainsimplesearch'] = "Standard Domainsuche";
$_LANG['domainspricing'] = "Domainpreise";
$_LANG['domainsregister'] = "Registrieren";
$_LANG['domainsrenew'] = "Erneuern";
$_LANG['domainsrenewnow'] = "Renew Now";
$_LANG['domainstatus'] = "Status";
$_LANG['domainstransfer'] = "Transfer";
$_LANG['domaintitle'] = "Freie Domainsuche";
$_LANG['domaintld'] = "TLD";
$_LANG['domaintransfer'] = "Domaintransfer";
$_LANG['domainunavailable'] = "Besetzt";
$_LANG['domainunavailable1'] = "Tut uns Leid!";
$_LANG['domainunavailable2'] = "ist bereits vergeben!";
$_LANG['domainviewwhois'] = "Whois-Report anzeigen";
$_LANG['downloaddescription'] = "Description";
$_LANG['downloadloginrequired'] = "Zugriff verweigert! Zum Download müssen Sie angemeldet sein.";
$_LANG['downloadname'] = "Download";
$_LANG['downloadpurchaserequired'] = "Zugriff verweigert! Für den Download müssen Sie das dazugehörige Produkt erwerben.";
$_LANG['downloadscategories'] = "Kategorien";
$_LANG['downloadsdescription'] = "Downloads";
$_LANG['downloadsfiles'] = "Dateien";
$_LANG['downloadsfilesize'] = "Dateigröße";
$_LANG['downloadsintrotext'] = "In der Downloadbibliothek finden Sie Dokumente & Software, die für Sie nützlich sein könnten.";
$_LANG['downloadspopular'] = "Most Popular Downloads";
$_LANG['downloadsnone'] = "Es gibt keine Downloads";
$_LANG['downloadstitle'] = "Downloads";
$_LANG['email'] = "Email";
$_LANG['emptycart'] = "Warenkorb leeren";
$_LANG['existingpassword'] = "vorhandenes Passwort";
$_LANG['existingpasswordincorrect'] = "Ihr vorhandenes Passwort war nicht korrekt.";
$_LANG['firstpaymentamount'] = "Betrag für die erste Zahlung";
$_LANG['flashtutorials'] = "Flashtutorials";
$_LANG['flashtutorialsdescription'] = "Klicken Sie hier um Flashtutorials zum Hosting-Controlpanel anzuzeigen";
$_LANG['flashtutorialsheadertext'] = "Unsere Flashtutorials sind hier, um Ihnen bei der Nutzung des Hosting-Controlpanels zu helfen. Wählen Sie eines der unten stehenden Schritt-für-Schritt-Tutorials, um die entsprechende Aufgabe zu bewältigen.";
$_LANG['forwardingtogateway'] = "Bitte warten Sie, sie werden weitergeleitet ...";
$_LANG['globalsystemname'] = "Support";
$_LANG['globalyouarehere'] = "Sie sind hier";
$_LANG['go'] = "Los";
$_LANG['headertext'] = "Willkommen im Kundenzentrum";
$_LANG['hometitle'] = "Home";
$_LANG['imagecheck'] = "Geben Sie bitte aus Sicherheitsgründen unten stehende 5 Zeichen ein.";
$_LANG['invoiceaddcreditamount'] = "Bitte Betrag angeben";
$_LANG['invoiceaddcreditapply'] = "Guthaben zuweisen";
$_LANG['invoiceaddcreditdesc1'] = "Ihr Kreditkartenguthaben";
$_LANG['invoiceaddcreditdesc2'] = "Sie können dies über untenstehendes Formular einer Rechnung zuweisen.";
$_LANG['invoiceaddcreditoverbalance'] = "Sie können nicht mehr als den geschuldeten Betrag zuweisen.";
$_LANG['invoiceaddcreditovercredit'] = "Sie können nicht mehr Guthaben zuweisen, als Sie haben!";
$_LANG['invoicenumber'] = "Rechnung ";
$_LANG['invoiceofflinepaid'] = "Offline Kreditkartenzahlungen werden manuell ausgeführt. Sie erhalten eine Bestätigung per Email, sobald die Zahlung erledigt ist.";
$_LANG['invoicerefnum'] = "Vorgangsnummer";
$_LANG['invoices'] = "Rechnungen";
$_LANG['invoicesamount'] = "Betrag";
$_LANG['invoicesattn'] = "z.H.";
$_LANG['invoicesbacktoclientarea'] = "<< Zurück zum Kundenzentrum";
$_LANG['invoicesbalance'] = "Restbetrag";
$_LANG['invoicesbefore'] = "vorher";
$_LANG['invoicescancelled'] = "Storniert";
$_LANG['invoicescollections'] = "Sammlungen";
$_LANG['invoicescredit'] = "Guthaben";
$_LANG['invoicesdatecreated'] = "Rechnungsdatum";
$_LANG['invoicesdatedue'] = "Fälligkeitsdatum";
$_LANG['invoicesdescription'] = "Beschreibung";
$_LANG['invoicesdownload'] = "Vollständige PDF-Rechnung anzeigen";
$_LANG['invoicesdue'] = "Fällige Rechnungen";
$_LANG['invoiceserror'] = "Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.";
$_LANG['invoicesinvoicedto'] = "Verrechnet an";
$_LANG['invoicesinvoicenotes'] = "Rechnungsbemerkungen";
$_LANG['invoicesnoinvoices'] = "Keine Rechnungen";
$_LANG['invoicesnotes'] = "Bemerkungen";
$_LANG['invoicesoutstandinginvoices'] = "Fällige Rechnungen";
$_LANG['invoicespaid'] = "Bezahlt";
$_LANG['invoicespaynow'] = "Jetzt bezahlen";
$_LANG['invoicespayto'] = "Bezahlen an";
$_LANG['invoicesrefunded'] = "Rückerstattet";
$_LANG['invoicesstatus'] = "Status";
$_LANG['invoicessubtotal'] = "Sub Total";
$_LANG['invoicestax'] = "MwSt.";
$_LANG['invoicestaxindicator'] = "Zeigt einen Steuerposten an";
$_LANG['invoicestitle'] = "Rechnung Nr. ";
$_LANG['invoicestotal'] = "Total";
$_LANG['invoicestransactions'] = "Transaktion";
$_LANG['invoicestransamount'] = "Betrag";
$_LANG['invoicestransdate'] = "Transaktionsdatum";
$_LANG['invoicestransgateway'] = "Gateway";
$_LANG['invoicestransid'] = "Transaktions-ID";
$_LANG['invoicestransnonefound'] = "Keine zugehörige Transaktion gefunden";
$_LANG['invoicesunpaid'] = "Unbezahlt";
$_LANG['invoicesview'] = "Rechnung anzeigen";
$_LANG['jobtitle'] = "Bezeichnung";
$_LANG['kbsuggestions'] = "Vorschlag aus der Knowledgebase";
$_LANG['kbsuggestionsexplanation'] = "Der folgende Eintrag wurde in der Knowledgebase gefunden und passt vielleicht zur Ihrer Anfrage. Bitte schauen Sie vor dem Öffnen einer Support-Anfrage in die Knowledgebase.";
$_LANG['knowledgebasearticles'] = "Artikel";
$_LANG['knowledgebasecategories'] = "Kategorien";
$_LANG['knowledgebasedescription'] = "Durchsuchen Sie die Knowledgebase nach oft gestellten Fragen";
$_LANG['knowledgebasefavorites'] = "Zu Favoriten hinzufügen";
$_LANG['knowledgebasehelpful'] = "War diese Antwort hilfreich?";
$_LANG['knowledgebaseintrotext'] = "Die Knowledgebase ist in Kategorien unterteilt. Wählen Sie eine der untenstehenden Kategorien oder durchsuchen Sie die Knowledgebase.";
$_LANG['knowledgebasemore'] = "Mehr";
$_LANG['knowledgebaseno'] = "Nein";
$_LANG['knowledgebasenoarticles'] = "Keine Artikel gefunden";
$_LANG['knowledgebasenorelated'] = "es gibt keine verwandten Artikel";
$_LANG['knowledgebasepopular'] = "Populärste";
$_LANG['knowledgebaseprint'] = "Artikel drucken";
$_LANG['knowledgebaserating'] = "Bewertung:";
$_LANG['knowledgebaseratingtext'] = "Benutzer fanden dies hilfreich";
$_LANG['knowledgebaserelated'] = "Verwandte Artikel";
$_LANG['knowledgebasesearch'] = "Suchen";
$_LANG['knowledgebasetitle'] = "Knowledgebase";
$_LANG['knowledgebaseviews'] = "Anzeigen";
$_LANG['knowledgebasevote'] = "Stimme";
$_LANG['knowledgebasevotes'] = "Stimmen";
$_LANG['knowledgebaseyes'] = "Ja";
$_LANG['language'] = "Sprache";
$_LANG['latefee'] = "Mahngebühr";
$_LANG['latefeeadded'] = "hinzugefügt";
$_LANG['latestannouncements'] = "Letzte Ankündigungen";
$_LANG['loginbutton'] = "Login";
$_LANG['loginemail'] = "Emailadresse";
$_LANG['loginforgotten'] = "Haben Sie Ihr Passwort vergessen?";
$_LANG['loginforgotteninstructions'] = "Passwort per Email schicken";
$_LANG['loginincorrect'] = "Die Emailadresse oder das Passwort sind nicht korrekt. Bitte versuchen Sie es erneut.";
$_LANG['loginintrotext'] = "Sie müssen sich einloggen um diese Seite anzuzeigen. Die Login-Daten unterscheiden sich von denen Ihrer Serververwaltung oder Ihres FTP-Zugangs.";
$_LANG['loginpassword'] = "Passwort";
$_LANG['loginrememberme'] = "Login speichern";
$_LANG['logoutcontinuetext'] = "Klicken Sie hier um fortzufahren";
$_LANG['logoutsuccessful'] = "Sie sind abgemeldet";
$_LANG['logouttitle'] = "Abmelden";
$_LANG['maxmind_anonproxy'] = "Wir erlauben keine Bestellungen über anonyme Proxys";
$_LANG['maxmind_callingnow'] = "Wir rufen nun die von Ihnen angegebene Telefonnummer an. Das ist Teil unseres Sicherheitssystems. Sie erhalten am Telefon einen vierstelligen Sicherheitscode den Sie unten eingeben müssen, um die Bestellung abzuschließen.";
$_LANG['maxmind_countrymismatch'] = "Die IP-Adresse Ihres Landes stimmt nicht mit der IP der Rechnungsadresse überein. Wir können Ihre Bestellung leider nicht akzeptieren";
$_LANG['maxmind_error'] = "Fehler";
$_LANG['maxmind_faileddescription'] = "Der eingegebene Code ist falsch. Falls es sich dabei um einen Systemfehler handelt, füllen Sie bitte ein Supportticket aus";
$_LANG['maxmind_highfraudriskscore'] = "Unser System hat ein hohes Risiko für diese Bestellung ermittelt und den Vorgang abgebrochen";
$_LANG['maxmind_highriskcountry'] = "Wir akzeptieren keine Bestellungen aus Ihrem Land, weil das Risiko für Mißbrauch zu hoch ist";
$_LANG['maxmind_incorrectcode'] = "Falscher Code";
$_LANG['maxmind_pincode'] = "Pin Code";
$_LANG['maxmind_rejectemail'] = "Wir erlauben keine Bestellungen, die von einer gratis Emailadresse kommen. Bitte versuchen Sie es erneut mit einer anderen Emailadresse";
$_LANG['maxmind_title'] = "MaxMind";
$_LANG['more'] = "Mehr";
$_LANG['morechoices'] = "mehr Auswahl";
$_LANG['networkissuesaffecting'] = "Betreffend";
$_LANG['networkissuesaffectingyourservers'] = "Bitte beachten: Vorkommnisse, die den Server mit Ihrem Account betreffen, werden mit goldfarbenem Hintergrund hervorgehoben.";
$_LANG['networkissuesdate'] = "Datum";
$_LANG['networkissuesdescription'] = "Zustand des Netzwerkes und Vorkommnisse / geplante Arbeiten daran anzeigen";
$_LANG['networkissueslastupdated'] = "Zuletzt aktualisiert";
$_LANG['networkissuesnonefound'] = "Keine Netzwerkvorkommnisse gefunden";
$_LANG['networkissuespriority'] = "Priorität";
$_LANG['networkissuesprioritycritical'] = "Kritisch";
$_LANG['networkissuespriorityhigh'] = "Hoch";
$_LANG['networkissuesprioritylow'] = "Niedrig";
$_LANG['networkissuesprioritymedium'] = "Mittel";
$_LANG['networkissuesstatusinprogress'] = "Im Fortschritt";
$_LANG['networkissuesstatusinvestigating'] = "In Prüfung";
$_LANG['networkissuesstatusopen'] = "Offen";
$_LANG['networkissuesstatusoutage'] = "Ausfall";
$_LANG['networkissuesstatusreported'] = "Verzeichnet";
$_LANG['networkissuesstatusresolved'] = "Gelöst";
$_LANG['networkissuesstatusscheduled'] = "Geplant";
$_LANG['networkissuestitle'] = "Netzwerk Vorkommnisse";
$_LANG['networkissuestypeother'] = "Anderes";
$_LANG['networkissuestypeserver'] = "Server";
$_LANG['networkissuestypesystem'] = "System";
$_LANG['newpassword'] = "Neues Passwort";
$_LANG['nextpage'] = "Nächste Seite";
$_LANG['no'] = "Nein";
$_LANG['nocarddetails'] = "Keine bestehenden Kartendetails gefunden";
$_LANG['none'] = "Keine";
$_LANG['norecordsfound'] = "Keine Aufzeichnung gefunden";
$_LANG['or'] = "or";
$_LANG['orderadditionalrequiredinfo'] = "Zusätzlich benötigte Angaben";
$_LANG['orderaddon'] = "Zusatzpaket / Option";
$_LANG['orderaddondescription'] = "Die folgenden Zusatzpakete / Optionen sind zu diesem Produkt erhältlich. Bitte wählen Sie die Option aus, die Sie hinzufügen möchten.";
$_LANG['orderavailable'] = "Erhältlich";
$_LANG['orderavailableaddons'] = "Klicken Sie hier um mögliche Zusatzpakete / Optionen einzusehen";
$_LANG['orderbillingcycle'] = "Verrechnungszyklus";
$_LANG['ordercategories'] = "Kategorien";
$_LANG['orderchangeaddons'] = "Zusatzpakete ändern";
$_LANG['orderchangeconfig'] = "Konfigurierbare Optionen ändern";
$_LANG['orderchangedomain'] = "Domain ändern";
$_LANG['orderchangenameservers'] = "Nur DNS Nameserver ändern";
$_LANG['orderchangeproduct'] = "Produkt ändern";
$_LANG['ordercheckout'] = "zur Kasse";
$_LANG['orderchooseaddons'] = "Wählen Sie Produkt-Zusatzpakete / -Optionen";
$_LANG['orderchooseapackage'] = "Paketauswahl";
$_LANG['ordercodenotfound'] = "Der eingegebene Promotion-Code existiert nicht";
$_LANG['ordercompletebutnotpaid'] = "Achtung! Ihre Bestellung wurde abgeschlossen, aber noch nicht bezahlt. Bis zur Bezahlung wird Ihr Auftrag nicht aktiviert. Klicken Sie auf untenstehenden Link für Ihre Rechnungen.";
$_LANG['orderconfigpackage'] = "Optionen";
$_LANG['orderconfigure'] = "Konfigurieren";
$_LANG['orderconfirmation'] = "Bestellungsbestätigung";
$_LANG['orderconfirmorder'] = "Bestellung bestätigen";
$_LANG['ordercontinuebutton'] = "Klicken um weiter zu machen >>";
$_LANG['orderdesc'] = "Beschreibung";
$_LANG['orderdescription'] = "Geben Sie eine neue Bestellung bei uns auf";
$_LANG['orderdiscount'] = "Rabatt";
$_LANG['orderdomain'] = "Domain";
$_LANG['orderdomainoption1part1'] = "Ich beauftrage";
$_LANG['orderdomainoption1part2'] = "eine neue Domain für mich zu registrieren.";
$_LANG['orderdomainoption2'] = "Ich werde die Nameserver meiner Domain selber ändern lassen oder selber eine neue Domain registrieren.";
$_LANG['orderdomainoption3'] = "Ich möchte meine Domain transferieren zu";
$_LANG['orderdomainoption4'] = "Ich möchte eine gratis Subdomain verwenden.";
$_LANG['orderdomainoptions'] = "Domainoptionen";
$_LANG['orderdomainregistration'] = "Domainregistrierung";
$_LANG['orderdomainregonly'] = "Nur Domainregistrierung bestellen";
$_LANG['orderdomaintransfer'] = "Domaintransfer";
$_LANG['orderdontusepromo'] = "Promotion-Code nicht verwenden";
$_LANG['ordererroraccepttos'] = "Sie müssen die allgemeinen Vertragsbedingungen (AGB) akzeptieren";
$_LANG['ordererrordomainalreadyexists'] = "Die Domain, die Sie eingegeben haben, ist bereits bei uns registriert. Sie müssen den Auftrag vorher abbrechen, bevor Sie eine neue Bestellung durchführen können.";
$_LANG['ordererrordomaininvalid'] = "Die eingegebene Domain ist ungültig";
$_LANG['ordererrordomainnotld'] = "Sie müssen eine Domainendung (TLD) angeben";
$_LANG['ordererrordomainnotregistered'] = "Sie können keine Domain transferieren, die nicht bereits registriert ist";
$_LANG['ordererrordomainregistered'] = "Die eingegebene Domain ist bereits registriert";
$_LANG['ordererrornameserver1'] = "Sie müssen Nameserver 1 eingeben";
$_LANG['ordererrornameserver2'] = "Sie müssen Nameserver 2 eingeben";
$_LANG['ordererrornodomain'] = "Sie haben keine Domain eingegeben";
$_LANG['ordererrorpassword'] = "Sie haben kein Passwort eingegeben";
$_LANG['ordererrorserverhostnameinuse'] = "The hostname you entered is already in use. Please choose another.";
$_LANG['ordererrorservernohostname'] = "Sie müssen einen Hostnamen für Ihren Server eingeben";
$_LANG['ordererrorservernonameservers'] = "Sie müssen einen Prefix für beide Nameserver eingeben";
$_LANG['ordererrorservernorootpw'] = "Sie müssen das gewünschte Root-Passwort eingeben";
$_LANG['ordererrorsubdomaintaken'] = "Die Subdomain ist bereits vergeben. Bitte versuchen Sie es erneut.";
$_LANG['ordererrortransfersecret'] = "Sie müssen einen Transferschlüssel (Transfer Secret) eingeben";
$_LANG['ordererroruserexists'] = "Ein Kunde mit dieser Emailadresse existiert bereits";
$_LANG['orderexistinguser'] = "Ich bin bereits Kunde und möchte diese Bestellung zu meinem Konto hinzufügen";
$_LANG['orderfailed'] = "Bestellungsfehler ";
$_LANG['orderfinalinstructions'] = "Wenn Sie Fragen zu Ihrer Bestellung haben, füllen Sie bitte ein Supportticket im Kudenzentrum aus und fügen Sie bitte Ihre Bestellnummer bei.";
$_LANG['orderfree'] = "Gratis!";
$_LANG['orderfreedomainappliesto'] = "betreffend nur die folgenden Domainendungen (TLD)";
$_LANG['orderfreedomaindescription'] = "zur ausgewählten Zahlungsmethode";
$_LANG['orderfreedomainonly'] = "Gratis Domain";
$_LANG['orderfreedomainregistration'] = "Gratis Domainregistrierung";
$_LANG['ordergotoclientarea'] = "Klicken Sie hier um zum Kundenzentrum zu gelangen";
$_LANG['orderinvalidcodeforbillingcycle'] = "Dieser Code kann nicht auf die aktuelle Periode angewendet werden";
$_LANG['orderlogininfo'] = "Login Angaben";
$_LANG['orderlogininfopart1'] = "Bitte geben Sie Ihr Passwort an, um zum folgenden Bereich zu gelangen";
$_LANG['orderlogininfopart2'] = "Kundenzentrum. Dies sind andere Loginangaben als Benutzername & Passwort vom cPanel.";
$_LANG['ordernewuser'] = "Ich bin ein neuer Kunde und möchte gerne ein Konto eröffnen";
$_LANG['ordernoproducts'] = "Keine Produkte gefunden";
$_LANG['ordernotes'] = "Notizen / Zusätzliche Information";
$_LANG['ordernotesdescription'] = "Hier können Sie zusätzliche Bemerkungen oder Informationen anführen, die Sie zusammen mit Ihrer Bestellung angeben möchten...";
$_LANG['ordernowbutton'] = "Jetzt bestellen";
$_LANG['ordernumberis'] = "Ihre Bestellnummer ist:";
$_LANG['orderpaymentmethod'] = "Zahlungsmethode";
$_LANG['orderpaymentterm12month'] = "Preis 12 Monate";
$_LANG['orderpaymentterm1month'] = "Preis 1 Monat";
$_LANG['orderpaymentterm24month'] = "Preis 1 Jahr";
$_LANG['orderpaymentterm3month'] = "Preis 3 Monate";
$_LANG['orderpaymentterm6month'] = "Preis 6 Monate";
$_LANG['orderpaymenttermannually'] = "Jährlich";
$_LANG['orderpaymenttermbiennially'] = "Alle 2 Jahre";
$_LANG['orderpaymenttermfreeaccount'] = "Gratis Account";
$_LANG['orderpaymenttermmonthly'] = "Monatlich";
$_LANG['orderpaymenttermonetime'] = "Einmal";
$_LANG['orderpaymenttermquarterly'] = "Vierteljährlich";
$_LANG['orderpaymenttermsemiannually'] = "Halbjährlich";
$_LANG['orderprice'] = "Preis";
$_LANG['orderproduct'] = "Produkte & Dienstleistungen";
$_LANG['orderprogress'] = "Fortschritt";
$_LANG['orderpromoexpired'] = "Der eingegebene Promotion-Code ist bereits abgelaufen";
$_LANG['orderpromoinvalid'] = "Der eingegebene Promotion-Code lässt sich auf keine der Produkte anwenden";
$_LANG['orderpromomaxusesreached'] = "Der eingegebene Promotion-Code wurde bereits verwendet";
$_LANG['orderpromotioncode'] = "Promotion-Code";
$_LANG['orderpromovalidatebutton'] = "Code überprüfen >>";
$_LANG['orderprorata'] = "Pro Rata";
$_LANG['orderreceived'] = "Vielen Dank für die Bestellung. Sie erhalten in Kürze eine Bestätigung per Email.";
$_LANG['orderregisterdomain'] = "eine neue Domain registrieren";
$_LANG['orderregperiod'] = "Registrierungsperiode";
$_LANG['ordersecure'] = "Ihre Daten werden verschlüsselt übertragen. Zu Ihrer Sicherheit wird Ihre IP-Adresse";
$_LANG['ordersecure2'] = "gespeichert.";
$_LANG['orderserverhostname'] = "Server Hostname";
$_LANG['orderservernameservers'] = "DNS Nameserver";
$_LANG['orderservernameserversdescription'] = "Die Prefixe die Sie hier eingeben sind die Nameserver für den Server z.B. ns1.ihredomain.com and ns2.ihredomain.com";
$_LANG['orderservernameserversprefix1'] = "Prefix 1";
$_LANG['orderservernameserversprefix2'] = "Prefix 2";
$_LANG['orderserverrootpassword'] = "Root-Passwort";
$_LANG['ordersetupfee'] = "Aufschaltgebühr";
$_LANG['orderstartover'] = "Erneut beginnen";
$_LANG['ordersubdomaininuse'] = "Die eingegebene Subdomain wird bereits verwendet";
$_LANG['ordersubtotal'] = "Zwischensumme total";
$_LANG['ordersummary'] = "Gesamtsumme der Bestellung";
$_LANG['ordertaxcalculations'] = "MwSt. Berechnung";
$_LANG['ordertaxstaterequired'] = "Sie müssen ein Bundesland zur Berechnung der MwSt. angeben";
$_LANG['ordertitle'] = "Bestellung";
$_LANG['ordertos'] = "AGB";
$_LANG['ordertosagreement'] = "Ich habe die AGB gelesen und bin damit einverstanden";
$_LANG['ordertotalduetoday'] = "Heute fälliger Gesamtbetrag";
$_LANG['ordertotalrecurring'] = "Gesamter Wiederholungszyklus-Betrag";
$_LANG['ordertransferdomain'] = "Eine existierende Domain transferieren";
$_LANG['ordertransfersecret'] = "Transfer-Schlüssel";
$_LANG['ordertransfersecretexplanation'] = "Ein Domain Transfer-Schlüssel (Transfer Secret) muß bei Ihrem aktuellen Domainregistrar beantragt werden.";
$_LANG['orderusesubdomain'] = "Subdomain verwenden";
$_LANG['orderyears'] = "Jahr(e)";
$_LANG['orderyourinformation'] = "Ihre Angaben";
$_LANG['orderyourorder'] = "Ihre Bestellung";
$_LANG['organizationname'] = "Name des Unternehmens oder der Organisation";
$_LANG['outofstock'] = "Leider nicht verfügbar!";
$_LANG['outofstockdescription'] = "Dieser Artikel ist gerade nicht verfügbar. Daher kann Ihre Bestellung für diesen Artikel nicht ausgeführt werden. Für weitere Informationen wenden Sie sich bitte an unseren Support.";
$_LANG['page'] = "Seite";
$_LANG['pageof'] = "von";
$_LANG['please'] = "Bitte";
$_LANG['pleasewait'] = "Bitte warten...";
$_LANG['presalescontactdescription'] = "Bitte stellen Sie hier Ihre Fragen, die Sie vor der Bestellung haben";
$_LANG['previouspage'] = "Vorhergehende Seite";
$_LANG['proformainvoicenumber'] = "Proforma-Rechnung ";
$_LANG['promoexistingclient'] = "Sie müssen ein aktives Produkt / Service haben, um diesen Code zu verwenden";
$_LANG['promoonceperclient'] = "Dieser Code kann nur einmal pro Kunde verwendet werden";
$_LANG['pwstrengthfail'] = "Das von Ihnen angegebene Passwort ist nicht sicher genug - bitte geben Sie ein höher komplexes Passwort ein.";
$_LANG['quicknav'] = "Quick Navigation";
$_LANG['recordsfound'] = "Datensätze gefunden";
$_LANG['recurring'] = "Wiederholend";
$_LANG['recurringamount'] = "Betrag für die Verlängerungsperiode";
$_LANG['every'] = "Every";
$_LANG['registerdomain'] = "Domainregistrierung";
$_LANG['registerdomaindesc'] = "Geben Sie bitte den zu suchenden Domainnamen an und klicken Sie 'Suchen' um zu prüfen, ob die gewünschte Domain noch frei ist.";
$_LANG['registerdomainname'] = "Domain registrieren";
$_LANG['relatedservice'] = "Verwandte Services";
$_LANG['rssfeed'] = "Feed";
$_LANG['securityanswerrequired'] = "Sie müssen eine Sicherheitsantwort eingeben";
$_LANG['securitybothnotmatch'] = "Ihre Antwort und Bestätigungsantwort stimmen nicht überein";
$_LANG['securitycurrentincorrect'] = "Ihre derzeitige Frage und Antwort ist nicht korrekt";
$_LANG['serverchangepassword'] = "Passwort ändern";
$_LANG['serverchangepasswordintro'] = "From here you can change the password of the product/service (note: this does not affect your password for our client area)";
$_LANG['serverchangepasswordconfirm'] = "Passwort bestätigen";
$_LANG['serverchangepasswordenter'] = "Geben Sie ein neues Passwort ein.";
$_LANG['serverchangepasswordfailed'] = "Passwort konnte nicht geändert werden!";
$_LANG['serverchangepasswordsuccessful'] = "Passwort erfolgreich geändert!";
$_LANG['serverchangepasswordupdate'] = "Aktualisieren";
$_LANG['serverhostname'] = "Hostname";
$_LANG['serverlogindetails'] = "Login Details";
$_LANG['servername'] = "Server";
$_LANG['serverns1prefix'] = "Nameserver1 Prefix";
$_LANG['serverns2prefix'] = "Nameserver2 Prefix";
$_LANG['serverpassword'] = "Passwort";
$_LANG['serverrootpw'] = "Root-Passwort";
$_LANG['serverstatusdescription'] = "Verfügbarkeit unserer Server prüfen";
$_LANG['serverstatusnoservers'] = "Es sind keine Server für die Überwachung registriert";
$_LANG['serverstatusnotavailable'] = "Nicht erhältlich";
$_LANG['serverstatusoffline'] = "Offline";
$_LANG['serverstatusonline'] = "Online";
$_LANG['serverstatusphpinfo'] = "PHP Info";
$_LANG['serverstatusserverload'] = "Serverauslastung";
$_LANG['serverstatustitle'] = "Server Status";
$_LANG['serverstatusuptime'] = "Online seit";
$_LANG['serverusername'] = "Benutzername";
$_LANG['show'] = "Zeige";
$_LANG['ssladmininfo'] = "Administrativer Kontakt";
$_LANG['ssladmininfodetails'] = "Diese Daten werden im Zertifikat nicht angezeigt und werden genutzt, um Sie betreffend der Bereitstellung zu kontaktieren. Das SSL Zertifikat selbst sowie Erneuerungshinweise werden außerdem an diese Adresse versandt.";
$_LANG['sslcertapproveremail'] = "Bestätigungskontakt";
$_LANG['sslcertapproveremaildetails'] = "Bitte wählen Sie aus den nachstehenden Kontakten einen für die Zusendung der Bestätigungs-Email aus.";
$_LANG['sslcertinfo'] = "Informationen zum SSL Zertifikat";
$_LANG['pleasechooseone'] = "Please choose one...";
$_LANG['sslcerttype'] = "Zertifikatstyp";
$_LANG['sslconfigcomplete'] = "Konfiguration vollständig";
$_LANG['sslconfigcompletedetails'] = "Die Konfiguration ist nun vollständig und wird an den Aussteller (CA) zur Prüfung übergeben. Sie sollten in Kürze eine Email zur Bestätigung erhalten.";
$_LANG['sslconfsslcertificate'] = "SSL Zertifikat konfigurieren";
$_LANG['sslcsr'] = "CSR";
$_LANG['sslerrorapproveremail'] = "Bitten wählen Sie eine Emailadresse für die Bestätigung.";
$_LANG['sslerrorentercsr'] = "Sie müssen den 'Certificate Signing Request' (CSR) angeben.";
$_LANG['sslerrorselectserver'] = "Sie müssen einen Servertyp auswählen.";
$_LANG['sslinvalidlink'] = "Dieser Link ist nicht gültig!";
$_LANG['sslorderdate'] = "Bestelldatum";
$_LANG['sslserverinfo'] = "Server Informationen";
$_LANG['sslserverinfodetails'] = "Sie benötigen einen gültigen \"CSR\" (Certificate Signing Request) -Antrag, um das Zertifikat zu bearbeiten. Dieser CSR ist eine verschlüsselte Datei, die zur Ausstellung eines SSL-Zertifikates benötigt wird. Wenn Sie keine CSR-Datei besitzen müssen Sie eine generieren, oder durch Ihren Provider generieren lassen. Bitte achten Sie besonders auf die korrekte Angabe der benötigten Daten. Nach Ausstellung des Zertifikates können keine Änderungen mehr vorgenommen werden!";
$_LANG['sslservertype'] = "Webserver-Typ";
$_LANG['sslstatus'] = "Status";
$_LANG['statscreditbalance'] = "Account Zahlungsbilanz";
$_LANG['statsdueinvoicesbalance'] = "Ausstehende Rechnungsbilanz";
$_LANG['statsnumdomains'] = "Anzahl an Domains";
$_LANG['statsnumproducts'] = "Anzahl an Produkten / Services";
$_LANG['statsnumreferredsignups'] = "Anzahl an weitergeleiteten Kunden";
$_LANG['statsnumtickets'] = "Anzahl an Supporttickets";
$_LANG['submitticketdescription'] = "Schicken Sie eine Supportanfrage";
$_LANG['supportclickheretocontact'] = "Kontaktieren Sie uns";
$_LANG['supportpresalesquestions'] = "Wünschen Sie Informationen zu unseren Produkten & Dienstleistungen, bevor Sie bestellen?";
$_LANG['supportticketinvalid'] = "Ein Fehler ist aufgetreten. Das angeforderte Ticket wurde nicht gefunden. Bitte prüfen Sie die Ticket-ID.";
$_LANG['supportticketsallowedextensions'] = "Erlaubte Dateiendungen";
$_LANG['supportticketschoosedepartment'] = "Abteilung auswählen";
$_LANG['supportticketsclient'] = "Kunde";
$_LANG['supportticketsclientemail'] = "Email";
$_LANG['supportticketsclientname'] = "Name";
$_LANG['supportticketsdate'] = "Datum";
$_LANG['supportticketsdepartment'] = "Abteilung";
$_LANG['supportticketsdescription'] = "Hier finden Sie Ihre bereits bestehenden Tickets und können darauf antworten";
$_LANG['supportticketserror'] = "Fehler";
$_LANG['supportticketserrornoemail'] = "Sie haben keine Emailadresse eingegeben";
$_LANG['supportticketserrornomessage'] = "Sie haben keine Nachricht eingegeben";
$_LANG['supportticketserrornoname'] = "Sie haben keinen Namen angegeben";
$_LANG['supportticketserrornosubject'] = "Sie haben keinen Betreff angegeben";
$_LANG['supportticketsfilenotallowed'] = "Die Datei, die Sie hochladen wollten ist nicht erlaubt";
$_LANG['supportticketsheader'] = "Wenn Sie in der Knowledgebase keine Antwort auf Ihr Problem finden können, schicken Sie uns bitte ein Supportticket an die entsprechende Abteilung.";
$_LANG['supportticketsnotfound'] = "Ticket nicht gefunden";
$_LANG['supportticketsopentickets'] = "Offene Supporttickets";
$_LANG['supportticketspagetitle'] = "Supporttickets";
$_LANG['supportticketsposted'] = "Geschickt";
$_LANG['supportticketsreply'] = "Antworten";
$_LANG['supportticketsstaff'] = "Mitarbeiter";
$_LANG['supportticketsstatus'] = "Status";
$_LANG['supportticketsstatusanswered'] = "Beantwortet";
$_LANG['supportticketsstatusclosed'] = "Erledigt";
$_LANG['supportticketsstatuscloseticket'] = "Supportticket schließen";
$_LANG['supportticketsstatuscustomerreply'] = "Kundenantwort";
$_LANG['supportticketsstatusinprogress'] = "In Bearbeitung";
$_LANG['supportticketsstatusonhold'] = "Angehalten";
$_LANG['supportticketsstatusopen'] = "Offen";
$_LANG['supportticketssubject'] = "Betreff";
$_LANG['supportticketssubmitticket'] = "Ticket abschicken";
$_LANG['supportticketssystemdescription'] = "Das Supportticketsystem erlaubt uns auf Ihre Probleme und Anfragen möglichst rasch zu reagieren. Wenn wir auf ein Ticket antworten, erhalten Sie zusätzlich eine Nachricht per Email.";
$_LANG['supportticketsticketattachments'] = "Beilagen";
$_LANG['supportticketsticketcreated'] = "Ticket erstellt";
$_LANG['supportticketsticketcreateddesc'] = "Ein Ticket wurde erfolgreich erstellt und eine Kopie an Ihre Emailadresse geschickt. Klicken Sie auf die Ticket-ID um es anzuzeigen.";
$_LANG['supportticketsticketid'] = "Ticket Nr.";
$_LANG['supportticketsticketsubject'] = "Betreff";
$_LANG['supportticketsticketsubmit'] = "Ticket abschicken";
$_LANG['supportticketsticketurgency'] = "Dringlichkeit";
$_LANG['supportticketsticketurgencyhigh'] = "Hoch";
$_LANG['supportticketsticketurgencylow'] = "Niedrig";
$_LANG['supportticketsticketurgencymedium'] = "Mittel";
$_LANG['supportticketsuploadfailed'] = "Die Datei konnte nicht hochgeladen werden";
$_LANG['supportticketsviewticket'] = "Ticket anzeigen";
$_LANG['telesignincorrectpin'] = "Falscher Pin!";
$_LANG['telesigninitiatephone'] = "Wir können die Telefonüberprüfung für Ihre Nummer nicht durchführen. Bitte kontaktieren Sie uns.";
$_LANG['telesigninvalidnumber'] = "Ungültige Telefonnummer";
$_LANG['telesigninvalidpin'] = "Der von Ihnen angegebene PIN war ungültig!";
$_LANG['telesigninvalidpin2'] = "Der von Ihnen angegebene PIN war nicht gültig.";
$_LANG['telesigninvalidpinmessage'] = "PIN-Code Überprüfung fehlgeschlagen";
$_LANG['telesignmessage'] = "Telefonüberprüfung für die Nummer %s ist gestartet. Bitte warten...";
$_LANG['telesignphonecall'] = "Telefonanruf";
$_LANG['telesignpin'] = "Geben Sie Ihre PIN ein: ";
$_LANG['telesignsms'] = "SMS";
$_LANG['telesignsmstextmessage'] = "Danke, dass Sie unser SMS-Überprüfungssystem verwenden. Ihr Code ist: %s Bitte geben Sie diesen Code nun an Ihrem Computer ein!";
$_LANG['telesigntitle'] = "TeleSign Telefonüberprüfung.";
$_LANG['telesigntype'] = "Wählen Sie den Überprüfungstyp für die Nummer %s:";
$_LANG['telesignverificationcanceled'] = "Es besteht ein vorübergehendes Problem mit dem Telefonüberprüfungssystem, die Telefonüberprüfung wurde abgebrochen.";
$_LANG['telesignverificationproblem'] = "Es trat ein Problem mit dem Telefonüberprüfungssystem auf und Ihr Auftrag konnte nicht überprüft werden. Bitte versuchen Sie es später wieder.";
$_LANG['telesignverify'] = "Ihre Telefonnummer %s muss überprüft werden, um den Auftrag abzuschließen.";
$_LANG['ticketratingexcellent'] = "Ausgezeichnet";
$_LANG['ticketratingpoor'] = "Schlecht";
$_LANG['ticketratingquestion'] = "Wie würden Sie diese Antwort bewerten?";
$_LANG['ticketreatinggiven'] = "Sie haben diese Antwort bewertet";
$_LANG['transferdomain'] = "Domaintransfer";
$_LANG['transferdomaindesc'] = "Sie wollen Ihre Domain zu uns umziehen? Bitte geben Sie den Domainnamen ein um die Prüfung zu starten.";
$_LANG['transferdomainname'] = "Domain zu uns umziehen";
$_LANG['updatecart'] = "Warenkorb aktualisieren";
$_LANG['upgradechooseconfigoptions'] = "Optionen für dieses Paket, die Sie upgraden/downgraden möchten.";
$_LANG['upgradechoosepackage'] = "Wählen Sie das Hosting-Paket, das Sie upgraden/downgraden möchten.";
$_LANG['upgradecurrentconfig'] = "Aktuelle Konfiguration";
$_LANG['upgradedowngradeconfigoptions'] = "Optionen upgraden/downgraden";
$_LANG['upgradenewconfig'] = "Neue Konfiguration";
$_LANG['upgradenochange'] = "Keine Änderungen";
$_LANG['upgradeproductlogic'] = "Der Preis für das Upgrade errechnet sich aus dem noch nicht verwendeten Guthaben des laufenden Paketes und dem Preis für das neue Paket für dieselbe Periode";
$_LANG['upgradesummary'] = "Unten ist eine Zusammenfassung Ihres Upgrades.";
$_LANG['usedefaultcontact'] = "Standard-Kontakt benutzen (siehe oben)";
$_LANG['varilogixfraudcall_callnow'] = "Jetzt anrufen!";
$_LANG['varilogixfraudcall_description'] = "Unser Sicherheitssystem wird nun einen Anruf an die von Ihnen angegebene Telefonnummer tätigen und Sie darum bitten, obigen PIN-Code in Ihre Telefontastatur einzugeben. Bitte klicken Sie hier um den Anruf jetzt auszulösen.";
$_LANG['varilogixfraudcall_error'] = "Ein Fehler ist aufgetreten und wir konnten keinen Anruf an Ihre Telefonnummer tätigen. Bitte füllen Sie ein Supportticket aus um Ihre Bestellung manuell überprüfen zu lassen.";
$_LANG['varilogixfraudcall_fail'] = "Der Anruf um Ihre Bestellung zu bestätigen ist leider misslungen. Ein Grund könnte sein, dass die angegebene Telefonnummer ungültig ist oder dass Sie von unserem System in einer schwarzen Liste geführt werden. Bitte füllen Sie ein Supportticket aus um Ihre Bestellung manuell überprüfen zu lassen.";
$_LANG['varilogixfraudcall_failed'] = "Misslungen";
$_LANG['varilogixfraudcall_pincode'] = "PIN-Code";
$_LANG['varilogixfraudcall_title'] = "VariLogix Überprüfungsanruf";
$_LANG['viewcart'] = "Warenkorb ansehen";
$_LANG['welcomeback'] = "Willkommen zurück";
$_LANG['whoisresults'] = "WHOIS Results for";
$_LANG['yes'] = "Ja";
$_LANG['yourdetails'] = "Ihre Details";

# Version 4.1

$_LANG['clientareafiles'] = "Angehängte Dateien";
$_LANG['clientareafilesdate'] = "Hinzugefügt am";
$_LANG['clientareafilesfilename'] = "Dateiname";

$_LANG['pwreset'] = "Passwort-Reset";
$_LANG['pwresetdesc'] = "Wenn Sie ihr Passwort verloren haben, können Sie es hier zurücksetzen. Wenn Sie ihre Email eingeben (und die Geheimfrage beantworten, falls Sie eine haben), erhalten Sie Anweisungen, wie sie ihr Passwort rücksetzen können.";
$_LANG['pwresetemailrequired'] = "Sie haben ihre Email-Adresse nicht eingegeben";
$_LANG['pwresetemailnotfound'] = "Keine Daten zur Email gefunden";
$_LANG['pwresetsecurityquestionrequired'] = "Wenn Sie eine Geheimfrage eingegeben haben, beantworten Sie diese in dem Feld unten.";
$_LANG['pwresetsecurityquestionincorrect'] = "Die eingegebene Geheimfrage stimmt nicht mit der auf Ihrem Account festgelegten überein.";
$_LANG['pwresetsubmit'] = "Senden";
$_LANG['pwresetvalidationsent'] = "Bestätigungs-Email verschickt";
$_LANG['pwresetvalidationcheckemail'] = "Die Passwortrücksetzung wurde gestartet. Bitte überprüfen Sie ihre Emails für weitere Anweisungen.";
$_LANG['pwresetkeyinvalid'] = "Der Rücksetzungslink ist ungültig. Bitte erneut versuchen.";
$_LANG['pwresetkeyexpired'] = "Der Rücksetzungslink ist abgelaufen. Bitte erneut versuchen.";
$_LANG['pwresetvalidationsuccess'] = "Passwortrücksetzung erfolgreich";

$_LANG['overagescharges'] = "Zusatzgebühr";
$_LANG['overagestotaldiskusage'] = "Gesamte Speicherplatzverwendung";
$_LANG['overagestotalbwusage'] = "Gesamte Bandbreitennutzung";

$_LANG['affiliatescommissionspending'] = "Commissions Pending Maturation";
$_LANG['affiliatescommissionsavailable'] = "Available Commissions Balance";
$_LANG['affiliatessignups'] = "Anzahl Registrierungen";
$_LANG['affiliatesconversionrate'] = "Konversionsrate";

$_LANG['configoptionqtyminmax'] = "%s hat eine Mindestanforderung von %s und maximal %s";

$_LANG['creditcardnostore'] = "Machen sie hier einen Haken wenn Sie NICHT wollen, dass wir ihre Kreditkartendetails für wiederkehrende Rechnungen verwenden.";
$_LANG['creditcarddelete'] = "Gespeicherte Kreditkartendetails löschen.";
$_LANG['creditcarddeleteconfirmation'] = "Die gespeicherten Kreditkartendetails wurden nun von ihrem Account gelöscht.";
$_LANG['creditcardupdatenotpossible'] = "Kreditkartendetails können nicht verändert werden. Bitte versuchen sie es später erneut.";

$_LANG['invoicepaymentsuccessconfirmation'] = "Vielen Dank. Ihre Bezahlung war erfolgreich!";
$_LANG['invoicepaymentfailedconfirmation'] = "Unglücklicherweise ist ihr Bezahlungsversuch fehlgeschlagen.<br />Bitte versuchen Sie es erneut oder kontaktieren sie den Support.";

# Version 4.2

$_LANG['promoappliedbutnodiscount'] = "The promotion code you entered has been applied to your cart but no items qualify for the discount yet - please check the promotion terms";

$_LANG['upgradeerroroverdueinvoice'] = "You cannot currently upgrade or downgrade this product because an invoice has already been generated for the next renewal.<br /><br />To proceed, please first pay the outstanding invoice and then you will be able to upgrade or downgrade immediately following that and be charged the difference or credited as appropriate.";

$_LANG['subaccountactivate'] = "Activate Sub-Account";
$_LANG['subaccountactivatedesc'] = "Tick to configure as a sub-account with client area access";
$_LANG['subaccountpermissions'] = "Sub-Account Permissions";
$_LANG['subaccountpermsprofile'] = "Modify Master Account Profile";
$_LANG['subaccountpermscontacts'] = "View & Manage Contacts";
$_LANG['subaccountpermsproducts'] = "View Products & Services";
$_LANG['subaccountpermsmanageproducts'] = "View & Modify Product Passwords";
$_LANG['subaccountpermsdomains'] = "View Domains";
$_LANG['subaccountpermsmanagedomains'] = "Manage Domain Settings";
$_LANG['subaccountpermsinvoices'] = "View & Pay Invoices";
$_LANG['subaccountpermstickets'] = "View & Open Support Tickets";
$_LANG['subaccountpermsaffiliates'] = "View & Manage Affiliate Account";
$_LANG['subaccountpermsemails'] = "View Emails";
$_LANG['subaccountpermsorders'] = "Place New Orders/Upgrades/Cancellations";
$_LANG['subaccountpermissiondenied'] = "You do not have the required permissions to access this page";
$_LANG['subaccountallowedperms'] = "Your allowed permissions are:";
$_LANG['subaccountcontactmaster'] = "Contact the master account owner if you feel this to be an error.";

$_LANG['knowledgebasealsoread'] = "Also Read";

$_LANG['orderpaymenttermtriennially'] = "Triennially";
$_LANG['orderpaymentterm36month'] = "36 Month Price";

$_LANG['domainrenewals'] = "Domain Renewals";
$_LANG['domaindaysuntilexpiry'] = "Days Until Expiry";
$_LANG['domainrenewalsnoneavailable'] = "There are no domains elligible for renewal in your account";
$_LANG['domainrenewalspastgraceperiod'] = "Past Renewable Period";
$_LANG['domainrenewalsingraceperiod'] = "Last Chance to Renew!";
$_LANG['domainrenewalsdays'] = "Days";
$_LANG['domainrenewalsdaysago'] = "Days Ago";

$_LANG['invoicespartialpayments'] = "Partial Payments";
$_LANG['invoicestotaldue'] = "Total Due";

$_LANG['masspaytitle'] = "Mass Payment";
$_LANG['masspaydescription'] = "Below is a summary of the selected invoices and the total due to pay all of them. To submit payment please just choose your desired payment method below and then submit.";
$_LANG['masspayselected'] = "Pay Selected";
$_LANG['masspayall'] = "Pay All";
$_LANG['masspaymakepayment'] = "Make Payment";

# Version 4.3

$_LANG['searchenterdomain'] = "Enter Domain to Find";
$_LANG['searchfilter'] = "Filter";

$_LANG['suspendreason'] = "Suspension Reason";
$_LANG['suspendreasonoverdue'] = "Overdue on Payment";

$_LANG['vpsnetmanagement'] = "VPS Management";
$_LANG['vpsnetpowermanagement'] = "Power Management";
$_LANG['poweron'] = "Power On";
$_LANG['poweroffforced'] = "Power Off (Forced)";
$_LANG['powerreboot'] = "Reboot";
$_LANG['powershutdown'] = "Shutdown";
$_LANG['vpsnetcpugraphs'] = "CPU Graphs";
$_LANG['vpsnetnetworkgraphs'] = "Network Graphs";
$_LANG['vpsnethourly'] = "Hourly";
$_LANG['vpsnetdaily'] = "Daily";
$_LANG['vpsnetweekly'] = "Weekly";
$_LANG['vpsnetmonthly'] = "Monthly";
$_LANG['view'] = "View";
$_LANG['vpsnetbackups'] = "Backup Options";
$_LANG['vpsnetgenbackup'] = "Generate Backup";
$_LANG['vpsnetrestorebackup'] = "Restore Backup";
$_LANG['vpsnetrestorebackupwarning'] = "Restoring the backup will over write your VPS server";
$_LANG['vpsnetnobackups'] = "There are no backups";
$_LANG['vpsnetrunning'] = "Running";
$_LANG['vpsnetnotrunning'] = "Not Running";
$_LANG['vpsnetpowercycling'] = "Power is cycling";
$_LANG['vpsnetcloud'] = "Cloud";
$_LANG['vpsnettemplate'] = "Template";
$_LANG['vpsnetstatus'] = "System Status";
$_LANG['vpsnetbwusage'] = "Bandwidth Usage";

$_LANG['twitterlatesttweets'] = "Our Latest Tweets";
$_LANG['twitterfollow'] = "Follow Us on Twitter";
$_LANG['twitterfollowus'] = "Follow us";
$_LANG['twitterfollowuswhy'] = "to stay up to date with our latest news &amp; offers";

$_LANG['chatlivehelp'] = "Live Help";

$_LANG['domainrelease'] = "Release Domain";
$_LANG['domainreleasedescription'] = "Enter a new TAG here to move your domain name to another registrar";
$_LANG['domainreleasetag'] = "New Registrar Tag";

# Ajax Order Form

$_LANG['orderformtitle'] = "Order Form";

$_LANG['signup'] = "Signup";
$_LANG['loading'] = "Loading...";

$_LANG['ordersummarybegin'] = "Shopping Cart is Empty<br/>Please choose a product to begin...";

$_LANG['cartchooseproduct'] = "Choose Product";
$_LANG['cartconfigurationoptions'] = "Configuration Options";

$_LANG['ordererrorsoccurred'] = "The following errors occurred and must be corrected before checkout:";
$_LANG['ordererrortermsofservice'] = "The Terms of Service must be agreed to";
$_LANG['ordertostickconfirm'] = "Please tick to confirm you agree to the";

$_LANG['cartnewcustomer'] = "I'm a New Customer";
$_LANG['cartexistingcustomer'] = "I'm an Existing Customer";

$_LANG['cartpromo'] = "Promotion";
$_LANG['cartenterpromo'] = "Enter Promotion Code";
$_LANG['cartremovepromo'] = "Remove Promo";

$_LANG['cartrecurringcharges'] = "Recurring Charges";

$_LANG['cartenterdomain'] = "Please enter the domain you would like to use below.";

$_LANG['cartdomainavailableoptions'] = "Congratulations, this domain is available!";
$_LANG['cartdomainavailableregister'] = "Please register this domain for";
$_LANG['cartdomainavailablemanual'] = "I will register it myself seperately";

$_LANG['cartdomainunavailableoptions'] = "Sorry, this domain is already taken. If you are the owner, please choose an option below...";
$_LANG['cartdomainunavailabletransfer'] = "Please transfer my domain for";
$_LANG['cartdomainunavailablemanual'] = "I already own this domain and will update the nameservers";

$_LANG['cartdomaininvalid'] = "The domain you entered is not valid. Enter only the part after the www. and include the TLD";

# Version 4.4

$_LANG['dlinvalidlink'] = "Invalid Link Followed. Please Contact Support";

$_LANG['domaindnsmanagementlaunch'] = "Launch DNS Manager";
$_LANG['domainemailforwardinglaunch'] = "Launch Mail Forwarding Manager";

# Version 4.5

$_LANG['domaindnspriority'] = "Priority";
$_LANG['domaindnsmxonly'] = "Priority Record for MX Only";

$_LANG['orderpromoprestart'] = "This promotion has not yet started. Please try again later.";

$_LANG['ticketmerge'] = "MERGED";

$_LANG['quote'] = "Quote";
$_LANG['quotestitle'] = "My Quotes";
$_LANG['quoteview'] = "View";
$_LANG['quotedownload'] = "View/Download";
$_LANG['quoteacceptbtn'] = "Accept Quote";
$_LANG['quotedlpdfbtn'] = "Download PDF";
$_LANG['quotediscountheading'] = "Discount (%)";
$_LANG['noquotes'] = "There are currently no quotes saved under your account.<br />To request a quote, please open a ticket.";
$_LANG['quotenumber'] = "Quote #";
$_LANG['quotesubject'] = "Subject";
$_LANG['quotedatecreated'] = "Date Created";
$_LANG['quotevaliduntil'] = "Valid Until";
$_LANG['quotestage'] = "Stage";
$_LANG['quoterecipient'] = "Receipient";
$_LANG['quoteqty'] = "Qty";
$_LANG['quotedesc'] = "Description";
$_LANG['quoteunitprice'] = "Unit Price";
$_LANG['quotediscount'] = "Discount %";
$_LANG['quotelinetotal'] = "Total";
$_LANG['quotestagedraft'] = "Draft";
$_LANG['quotestagedelivered'] = "Delivered";
$_LANG['quotestageonhold'] = "On Hold";
$_LANG['quotestageaccepted'] = "Accepted";
$_LANG['quotestagelost'] = "Lost";
$_LANG['quotestagedead'] = "Dead";
$_LANG['quoteref'] = "Re Quote #";
$_LANG['quotedeposit'] = "Deposit";
$_LANG['quotefinalpayment'] = "Balance from Deposit";

$_LANG['invoiceoneoffpayment'] = "Make One Off Payment";
$_LANG['invoicesubscriptionpayment'] = "Create Automated Recurring Subscription";

$_LANG['invoicepaymentpendingreview'] = "Thank You! Your payment was successful and will be applied to your invoice as soon as 2CheckOut's Review Process has completed.<br /><br />This can take up to a few hours so your patience is appreciated.";

$_LANG['step'] = "Step %s";
$_LANG['cartdomainexists'] = "This domain already exists in our database so cannot be ordered again";
$_LANG['cartcongratsdomainavailable'] = "Congratulations, %s is available!";
$_LANG['cartregisterhowlong'] = "How long do you want to register this for?";
$_LANG['cartdomaintaken'] = "Sorry, %s is already taken";
$_LANG['carttransfernotregistered'] = "%s does not appear to be registered yet";
$_LANG['carttransferpossible'] = "Congratulations, we can transfer %s to us for just %s";
$_LANG['cartotherdomainsuggestions'] = "Other domains you might be interested in...";
$_LANG['cartdomainsconfiginfo'] = "The following options and settings are available for the domains you have chosen. Required fields are indicated with a *.";
$_LANG['cartnameserverchoice'] = "Nameserver Choice";
$_LANG['cartnameserverchoicedefault'] = "Use default nameservers for our hosting";
$_LANG['cartnameserverchoicecustom'] = "Use custom nameservers";
$_LANG['cartfollowingaddonsavailable'] = "The following addons are available for your active products & services.";
$_LANG['cartregisterdomainchoice'] = "Register a new domain";
$_LANG['carttransferdomainchoice'] = "Transfer your domain from another registrar";
$_LANG['cartexistingdomainchoice'] = "I will use my existing domain and update my nameservers";
$_LANG['cartsubdomainchoice'] = "Use a subdomain from %s";
$_LANG['carterrordomainconfigskipped'] = "You must go back and complete the required domain configuration fields above";
$_LANG['cartproductchooseoptions'] = "Choose Options";
$_LANG['cartproductselection'] = "Product Selection";
$_LANG['cartreviewcheckout'] = "Review & Checkout";
$_LANG['cartchoosecycle'] = "Choose Billing Cycle";
$_LANG['cartavailableaddons'] = "Available Addons";
$_LANG['cartsetupfees'] = "Setup Fees";
$_LANG['cartchooseanotherproduct'] = "Choose Another Product";
$_LANG['cartaddandcheckout'] = "Add to Cart & Checkout";
$_LANG['cartchooseanothercategory'] = "Choose Another Category";
$_LANG['carttryanotherdomain'] = "Try another domain";
$_LANG['cartmakedomainselection'] = "Please provide us with the domain you want to use with your hosting service by selecting an option from the selections below.";
$_LANG['cartfraudcheck'] = "Fraud Check";

$_LANG['newcustomer'] = "New Customer";
$_LANG['existingcustomer'] = "Existing Customer";
$_LANG['newcustomersignup'] = "Not Yet Registered? %sClick here to signup...%s";

$_LANG['upgradeonselectedoptions'] = "(On Selected Options)";
$_LANG['recurringpromodesc'] = "This promotion code also includes a %s Recurring Discount<br />(This discount will apply to future renewals of the product's total price)";

# Version 4.5.2

$_LANG['ajaxcartcheckout'] = "Jump straight to checkout &raquo;";
$_LANG['ordersummarybegin'] = "Shopping Cart is Empty<br/>Please choose a product to begin...";
$_LANG['ajaxcartconfigreqnotice'] = "You're on the way to signing up with us, but you must choose a domain before you can add the selected product to your cart...";

# Version 5.0.0

$_LANG['cancelrequestdomain'] = "Cancel Domain Renewal?";
$_LANG['cancelrequestdomaindesc'] = "You also have an active domain registration for the domain associated with this product<br />This domain is due to renew on %s at a cost of %s for %s Year/s<br /><br />If you would like to cancel the domain as well, and let it expire at the end of the current registration, then simply tick the box below.";
$_LANG['cancelrequestdomainconfirm'] = "I confirm I do not want to renew this domain again";

$_LANG['startingfrom'] = "Starting from";

$_LANG['orderpromopriceoverride'] = "Price Override";
$_LANG['orderpromofreesetup'] = "Free Setup";

$_LANG['thereisaproblem'] = "Oops, there's a problem...";
$_LANG['problemgoback'] = "Go back & try again";

$_LANG['quantity'] = "Quantity";
$_LANG['cartqtyenterquantity'] = "Want more than 1 of this item? Enter Quantity Here:";
$_LANG['cartqtyupdate'] = "Update";
$_LANG['invoiceqtyeach'] = "/ea";

$_LANG['nschoicedefault'] = "Use default nameservers";
$_LANG['nschoicecustom'] = "Use custom nameservers (enter below)";

$_LANG['jumpto'] = "Jump to";
$_LANG['top'] = "Top";

$_LANG['domaincontactusexisting'] = "Use existing account contact";
$_LANG['domaincontactusecustom'] = "Specify custom information below";
$_LANG['domaincontactchoose'] = "Choose Contact";
$_LANG['domaincontactprimary'] = "Primary Profile Data";

$_LANG['invoicepdfgenerated'] = "PDF Generated on";

$_LANG['domainrenewalsbeforerenewlimit'] = "Minimum Advance Renewal is %s Days";

$_LANG['promonewsignupsonly'] = "This promotion code is only valid for new customers";

# Bulk Domain Management

$_LANG['domainbulkmanagement'] = "Bulk Management Actions";
$_LANG['domainbulkmanagementchangesaffect'] = "The changes made below will affect the following domains:";
$_LANG['domainbulkmanagementchangeaffect'] = "This change will apply to the following domains:";
$_LANG['domaincannotbemanaged'] = "cannot be managed automatically - please contact support regarding any changes you want to make";
$_LANG['domainbulkmanagementnotpossible'] = "Unfortunately these settings cannot be edited from our client area at the current time. Please contact support regarding any changes you wanted to make.";

$_LANG['domainmanagens'] = "Manage Nameservers";

$_LANG['domainautorenewstatus'] = "Auto Renewal Status";
$_LANG['domainautorenewinfo'] = "Auto renew helps protect your domain. When enabled, we will automatically send you a renewal invoice a few weeks before your domain expires, and  renew the domain should payment be successful.";
$_LANG['domainautorenewrecommend'] = "We recommend keeping auto renew enabled to avoid losing your domain.";

$_LANG['domainreglockstatus'] = "Registrar Lock Status";
$_LANG['domainreglockinfo'] = "Registrar Lock (also known as Theft Protection) secures your Domain from unauthorized transfers.";
$_LANG['domainreglockrecommend'] = "We recommend that you keep this enabled, except when transferring your Domain Name away.";
$_LANG['domainreglockenable'] = "Enable Registrar Lock";
$_LANG['domainreglockdisable'] = "Disable Registrar Lock";

$_LANG['domaincontactinfoedit'] = "Edit Contact Information";

$_LANG['domainmassrenew'] = "Renew Domains";

# reCAPTCHA

$_LANG['captchatitle'] = "Spam Bot Verification";
$_LANG['captchaverify'] = "Please enter the characters you see in the image below into the text box provided. This is required to prevent automated submissions.";
$_LANG['captchaverifyincorrect'] = "The characters you entered didn't match the image shown. Please try again.";
$_LANG['recaptcha-invalid-site-private-key'] = "An error occurred, please contact support (error code: cap1)";
$_LANG['recaptcha-invalid-request-cookie'] = "An error occurred, please try again (error code: cap2)";
$_LANG['recaptcha-incorrect-captcha-sol'] = "The characters you entered didn't match the word verification. Please try again.";

# Product Bundles

$_LANG['bundledeal'] = "Bundle Deal!";
$_LANG['bundlevaliddateserror'] = "Bundle Unavailable";
$_LANG['bundlevaliddateserrordesc'] = "This bundle is either not yet active or has expired. If you feel this message to be an error, please contact support.";
$_LANG['bundlemaxusesreached'] = "Bundle Unavailable";
$_LANG['bundlemaxusesreacheddesc'] = "This bundle offer has reached the maximum number of uses allowed and so unfortunately is no longer available. Please contact us if you you're interested in our services to discuss.";
$_LANG['bundlereqsnotmet'] = "Bundle Requirements Not Met";
$_LANG['bundlewarningpromo'] = "The selected bundle cannot be used in conjunction with any other promotions or offers";
$_LANG['bundlewarningproductcycle'] = "The selected bundle requires you choose the billing cycle '%s' for product %s to qualify";
$_LANG['bundlewarningproductconfopreq'] = "The selected bundle requires you select '%s' for '%s' in order to qualify";
$_LANG['bundlewarningproductconfopyesnoenable'] = "The selected bundle requires you enable the option '%s' in order to qualify";
$_LANG['bundlewarningproductconfopyesnodisable'] = "The selected bundle requires you deselect the option '%s' in order to qualify";
$_LANG['bundlewarningproductconfopqtyreq'] = "The selected bundle requires you choose a quantity of '%s' for '%s' in order to qualify";
$_LANG['bundlewarningproductaddonreq'] = "The selected bundle requires you select the addon '%s' for product %s to qualify";
$_LANG['bundlewarningdomainreq'] = "The selected bundle requires you register or transfer a domain with the product %s to qualify";
$_LANG['bundlewarningdomaintld'] = "The selected bundle requires you choose a domain with the extension(s) '%s' for domain %s to qualify";
$_LANG['bundlewarningdomainregperiod'] = "The selected bundle requires you select the registration period '%s' for domain %s to qualify";
$_LANG['bundlewarningdomainaddon'] = "The selected bundle requires you select the addon '%s' for domain %s to qualify";

# New Client Area Template  Lines

$_LANG['navservices'] = "Services";
$_LANG['navservicesorder'] = "Order New Services";
$_LANG['navdomains'] = "Domains";
$_LANG['navrenewdomains'] = "Renew Domains";
$_LANG['navregisterdomain'] = "Register a New Domain";
$_LANG['navtransferdomain'] = "Transfer Domains to Us";
$_LANG['navwhoislookup'] = "Whois Lookup";
$_LANG['navbilling'] = "Billing";
$_LANG['navsupport'] = "Support";
$_LANG['navtickets'] = "Tickets";
$_LANG['navopenticket'] = "Open Ticket";
$_LANG['navmanagecc'] = "Manage Credit Card";
$_LANG['navemailssent'] = "Emails Sent";

$_LANG['hello'] = "Hello";
$_LANG['account'] = "Account";
$_LANG['login'] = "Login";
$_LANG['register'] = "Register";
$_LANG['forgotpw'] = "Forgot Password?";
$_LANG['editaccountdetails'] = "Edit Account Details";

$_LANG['clientareanavccdetails'] = "Credit Card Details";
$_LANG['clientareanavcontacts'] = "Kontakte verwalten";

$_LANG['manageyouraccount'] = "Manage Your Account";
$_LANG['accountoverview'] = "Account Overview";
$_LANG['paymentmethod'] = "Payment Method";
$_LANG['paymentmethoddefault'] = "Use Default (Set Per Order)";
$_LANG['productmanagementactions'] = "Management Actions";
$_LANG['clientareanoaddons'] = "Keine Zusatzpakete für diesen Account gefunden";
$_LANG['downloadssearch'] = "Search Downloads";
$_LANG['emailviewmessage'] = "View Message";
$_LANG['resultsperpage'] = "Results Per Page";
$_LANG['accessdenied'] = "Access Denied";
$_LANG['search'] = "Search";
$_LANG['cancel'] = "Cancel";
$_LANG['clientareabacklink'] = "<< Zurück";
$_LANG['backtoserviceslist'] = "&laquo; Back to Services List";
$_LANG['backtodomainslist'] = "&laquo; Back to Domains List";

$_LANG['clientareahomeorder'] = "Visit the Order Form to browse the Products & Services we offer. Existing customers can also purchase optional extras and addons here.";
$_LANG['clientareahomelogin'] = "Already registered with us? If so, click the button below to login to our client area from where you can manage your account.";
$_LANG['clientareahomeorderbtn'] = "Go to Order Form";
$_LANG['clientareahomeloginbtn'] = "Secure Client Login";

$_LANG['clientareaproductsintro'] = "These are all the services you have registered in this account.";
$_LANG['clientareaproductdetailsintro'] = "Here is an overview of your product/service with us.";
$_LANG['clientareadomainsintro'] = "These are all the domains you have registered in this account.";
$_LANG['invoicesintro'] = "Below you can review your entire invoice history with us.";
$_LANG['quotesintro'] = "Here are all the quotes we've generated for you.";
$_LANG['emailstagline'] = "Here's a copy of the recent emails we've sent you...";
$_LANG['supportticketsintro'] = "Submit and track any enquiries with us here...";
$_LANG['addfundsintro'] = "Deposit money in advance";
$_LANG['registerintro'] = "Create an account with us . . .";
$_LANG['masspayintro'] = "Pay all the invoices listed below in a single easy transaction by choosing a payment method";
$_LANG['domaincheckerintro'] = "Start your web hosting search here by checking if your domain is available...";
$_LANG['networkstatusintro'] = "Service Status Information and Network Announcements";

$_LANG['creditcardyourinfo'] = "Ihre Angaben";
$_LANG['ourlatestnews'] = "Our Latest News";
$_LANG['ccexpiringsoon'] = "Credit Card Expiring Soon";
$_LANG['ccexpiringsoondesc'] = "Your credit card is expiring soon so please ensure you %supdate your card details%s with us when you can";
$_LANG['availcreditbal'] = "Available Credit Balance";
$_LANG['availcreditbaldesc'] = "You have a credit balance of %s and this will be automatically applied to any new invoices";
$_LANG['youhaveoverdueinvoices'] = "You have %s Overdue Invoice(s)";
$_LANG['overdueinvoicesdesc'] = "To avoid service interuption, please pay your outstanding invoices as soon as possible. %sPay Now &raquo;%s";
$_LANG['supportticketsnoneopen'] = "There are currently no open support tickets";
$_LANG['invoicesnoneunpaid'] = "There are currently no unpaid invoices";

$_LANG['registerdisablednotice'] = "To register please place an <strong><a href=\"cart.php\">order</a></strong>";

$_LANG['pwstrength'] = "Password Strength";
$_LANG['pwstrengthenter'] = "Enter a Password";
$_LANG['pwstrengthweak'] = "Weak";
$_LANG['pwstrengthmoderate'] = "Moderate";
$_LANG['pwstrengthstrong'] = "Strong";

$_LANG['managing'] = "Managing";
$_LANG['information'] = "Information";
$_LANG['withselected'] = "With Selected";
$_LANG['managedomain'] = "Manage Domain";
$_LANG['changenameservers'] = "Change Nameservers";
$_LANG['clientareadomainmanagedns'] = "Manage DNS";
$_LANG['clientareadomainmanageemailfwds'] = "Manage Email Forwards";
$_LANG['moduleactionsuccess'] = "Action Completed Successfully!";
$_LANG['moduleactionfailed'] = "Action Failed";

$_LANG['domaininfoexp'] = "To the right you can find the details of your domain. You can manage your domain using the tabs above.";
$_LANG['domainrenewexp'] = "Enable auto renew to have us automatically send you a renewal invoice before your domain expires.";
$_LANG['domainnsexp'] = "You can change where your domain points to here. Please be aware changes can take up to 24 hours to propogate.";
$_LANG['domainlockingexp'] = "Lock your domain to prevent it from being transferred away without your authorization.";
$_LANG['domaincurrentlyunlocked'] = "Domain Currently Unlocked!";
$_LANG['domaincurrentlyunlockedexp'] = "You should enable the registrar lock unless you are transferring the domain.";
$_LANG['searchmultipletlds'] = "Search Multiple TLDs";

$_LANG['networkstatustitle'] = "Network Status";
$_LANG['networkstatusnone'] = "There are no %s Network Issues Currently";
$_LANG['serverstatusheadingtext'] = "Die unten stehende Tabelle zeigt den aktuellen Serverstatus. Sie können diese Seite dazu benutzen um nachzusehen, ob einer der Serverdienste ausgefallen ist.";

$_LANG['clientareacancelreasonrequired'] = "You must enter a cancellation reason";

$_LANG['addfundsdescription'] = "Sie können Guthaben / Vorauszahlungen zur Zahlung der Rechnungen hinzufügen. Eingezahltes Guthaben ist nicht zurückzahlbar.";
$_LANG['addfundsnonrefundable'] = "* All deposits are non-refundable.";

$_LANG['creditcardexpirydateinvalid'] = "The expiry date must be entered in the format MM/YY and must not be in the past";

$_LANG['domaincheckerchoosedomain'] = "Choose a Domain...";
$_LANG['domaincheckerchecknewdomain'] = "Check Availability of a New Domain";
$_LANG['domaincheckerdomainexample'] = " eg. yourdomain.com";
$_LANG['domaincheckerinvalidtld'] = "is not a valid TLD. Please try again.";
$_LANG['domaincheckerhostingonly'] = "Order Hosting Only";
$_LANG['domaincheckeravailtransfer'] = "Available for Transfer";
$_LANG['domaincheckerenterdomain'] = "Start your web hosting experience with us by entering the domain name you want to register, transfer or simply purchase hosting for below...";
$_LANG['domaincheckerbulkinvaliddomain'] = "One or more of the domains you entered above was invalid and so has been ommitted from the results";

$_LANG['kbquestionsearchere'] = "Have a question? Start your search here.";
$_LANG['contactus'] = "Contact Us";

$_LANG['opennewticket'] = "Open New Ticket";
$_LANG['searchtickets'] = "Enter Ticket # or Subject";
$_LANG['supportticketspriority'] = "Priority";
$_LANG['supportticketsubmitted'] = "Submitted";
$_LANG['supportticketscontact'] = "Contact";
$_LANG['supportticketsticketlastupdated'] = "Last Updated";

$_LANG['upgradedowngradepackage'] = "Hosting-Paket upgraden/downgraden";
$_LANG['upgradedowngradechooseproduct'] = "Choose Product";

$_LANG['jobtitlereqforcompany'] = "(Required if Organization Name is set)";

$_LANG['downloadproductrequired'] = "Downloading this item requires you to have an active instance of the following product/service:";

$_LANG['affiliatesignuptitle'] = "Get Paid for Referring Customers to Us";
$_LANG['affiliatesignupintro'] = "Activate your affiliate account and start earning money today...";
$_LANG['affiliatesignupinfo1'] = "We pay commissions for every signup that comes via your custom signup link.";
$_LANG['affiliatesignupinfo2'] = "We track the visitors you refer to us using cookies, so users you refer don't have to purchase instantly for you to receive your commission.  Cookies last for up to 90 days following the initial visit.";
$_LANG['affiliatesignupinfo3'] = "If you would like to find out more, please contact us.";

# Version 5.1

$_LANG['copyright'] = "Copyright";
$_LANG['allrightsreserved'] = "All Rights Reserved";
$_LANG['supportticketsclose'] = "Close Ticket";
$_LANG['affiliatesinitialthen'] = "Initially then";
$_LANG['invoicesoutstandingbalance'] = "Outstanding Balance";

$_LANG['cpanellogin'] = "Login to cPanel";
$_LANG['cpanelwhmlogin'] = "Login to WHM";
$_LANG['cpanelwebmaillogin'] = "Login to Webmail";
$_LANG['enkompasslogin'] = "Login to Enkompass";
$_LANG['plesklogin'] = "Login to Plesk Control Panel";
$_LANG['helmlogin'] = "Login to Helm Control Panel";
$_LANG['hypervmrestart'] = "Restart VPS Server";
$_LANG['siteworxlogin'] = "Login to SiteWorx Control Panel";
$_LANG['nodeworxlogin'] = "Login to NodeWorx Control Panel";
$_LANG['veportallogin'] = "Login to vePortal";
$_LANG['virtualminlogin'] = "Login to Control Panel";
$_LANG['websitepanellogin'] = "Login to Control Panel";
$_LANG['whmsoniclogin'] = "Login to Control Panel";
$_LANG['xpanelmaillogin'] = "Login to Webmail";
$_LANG['xpanellogin'] = "Login to XPanel";
$_LANG['heartinternetlogin'] = "Login to Control Panel";
$_LANG['gamecplogin'] = "Login to GameCP";
$_LANG['fluidvmrestart'] = "Restart VPS Server";
$_LANG['enomtrustedesc'] = "The TRUSTe Control Panel contains the set up wizard to get your Privacy Policy up and running.";
$_LANG['enomtrustelogin'] = "Login to TrustE Control Panel";
$_LANG['directadminlogin'] = "Login to DirectAdmin";
$_LANG['centovacastlogin'] = "Login to Centova Cast";
$_LANG['castcontrollogin'] = "Login to Control Panel";

$_LANG['sslconfigurenow'] = "Configure Now";
$_LANG['sslprovisioningdate'] = "SSL Provisioning Date";
$_LANG['globalsignvoucherscode'] = "Your OneClickSSL Voucher Code";
$_LANG['globalsignvouchersnotissued'] = "Not Yet Issued";

$_LANG['domaintrffailreasonunavailable'] = "Failure Reason Unavailable";

$_LANG['clientareaprojects'] = "My Projects";

$_LANG['clientgroupdiscount'] = "Client Discount";
$_LANG['billableitemshours'] = "Hours";
$_LANG['billableitemshour'] = "Hour";

$_LANG['invoicefilename'] = "Invoice-";
$_LANG['quotefilename'] = "Quote-";

# Licensing Addon

$_LANG['licensingkey'] = "License Key";
$_LANG['licensingvaliddomains'] = "Valid Domains";
$_LANG['licensingvalidips'] = "Valid IPs";
$_LANG['licensingvaliddirectory'] = "Valid Directory";
$_LANG['licensingstatus'] = "License Status";
$_LANG['licensingreissue'] = "Reissue License";
$_LANG['licensingreissued'] = "The Valid Domain, IP and Directory will be detected & saved the next time the license is used.";

# Domain Addons

$_LANG['domainaddons'] = "Addons";
$_LANG['domainaddonsinfo'] = "The following addons are available for your domain(s)...";
$_LANG['domainaddonsdnsmanagement'] = "DNS Host Record Management";
$_LANG['domainaddonsidprotectioninfo'] = "Protect your personal information and reduce the amount of spam to your inbox by enabling ID Protection.";
$_LANG['domainaddonsdnsmanagementinfo'] = "External DNS Hosting can help speed up your website and improve availability with reduced redundancy.";
$_LANG['domainaddonsemailforwardinginfo'] = "Get emails forwarded to alternate email addresses of your choice so that you can monitor all from a single account.";
$_LANG['domainaddonsbuynow'] = "Buy Now for";
$_LANG['domainaddonsperyear'] = "/Year";
$_LANG['domainaddonscancelareyousure'] = "Are you sure you want to disable & cancel this domain addon?";
$_LANG['domainaddonsconfirm'] = "Confirm Cancellation";
$_LANG['domainaddonscancelsuccess'] = "Addon Deactivated Successfully!";
$_LANG['domainaddonscancelfailed'] = "Failed to deactivate addon. Please contact support.";

# Version 5.2

$_LANG['yourclientareahostingaddons'] = "You have the following addons for this product.";
$_LANG['loginrequired'] = "Login Required";
$_LANG['unsubscribe'] = "Unsubscribe";
$_LANG['emailoptout'] = "Newsletter Opt-out";
$_LANG['newsletterunsubscribe'] = "Newsletter Unsubscribe";
$_LANG['emailoptoutdesc'] = "Tick to unsubscribe from our newsletters";
$_LANG['alreadyunsubscribed'] = "You have already unsubscribed from our newsletter.";
$_LANG['newsletterresubscribe'] = "If you wish to re-subscribe you can do so from the %sMy Details%s section of our client area at any time.";
$_LANG['unsubscribehashinvalid'] = "Unsubscribe failed, please contact support.";
$_LANG['unsubscribesuccess'] = "Unsubscribe Successful";
$_LANG['newsletterremoved'] = "Thank you, Your email has now been removed from our mailing list.";
$_LANG['erroroccured'] = "An Error Occurred";
$_LANG['pwresetsuccessdesc'] = "Your password has now been reset. %sClick here%s to continue to the client area...";
$_LANG['pwresetenternewpw'] = "Please enter your desired new password below.";
$_LANG['ordererrorsbudomainbanned'] = "The subdomain prefix you entered is not allowed - please try another";

$_LANG['ticketfeedbacktitle'] = "Feedback Request for Ticket";

$_LANG['nosupportdepartments'] = "No support departments found. Please try again later.";

$_LANG['feedbackclosed'] = "Feedback cannot be provided until the ticket is closed";
$_LANG['feedbackprovided'] = "You have already provided feedback for this ticket";
$_LANG['feedbackthankyou'] = "We thank you for taking the time to provide your feedback.";
$_LANG['feedbackreceived'] = "Submission Received";
$_LANG['feedbackdesc'] = "Please can we ask you to take a moment of your time to fill out the below form about the quality of your experience with our support team.";
$_LANG['feedbackclickreview'] = "Click here to Review The Ticket";
$_LANG['feedbackopenedat'] = "Opened At";
$_LANG['feedbacklastreplied'] = "Last Replied To";
$_LANG['feedbackstaffinvolved'] = "Staff Involved";
$_LANG['feedbacktotalduration'] = "Total Duration";
$_LANG['feedbackpleaserate1'] = "Please rate (on a scale of 1 to 10) how well";
$_LANG['feedbackpleasecomment1'] = "Please comment on how well";
$_LANG['feedbackhandled'] = "handled this support request";
$_LANG['feedbackworst'] = "Worst";
$_LANG['feedbackbest'] = "Best";
$_LANG['feedbackimprove'] = "How may we make your experience better in the future?";
$_LANG['pleaserate2'] = "handled this support request";
$_LANG['returnclient'] = "Return to Client Area";

$_LANG['clientareanavsecurity'] = "Security Settings";
$_LANG['twofactorauth'] = "Two-Factor Authentication";
$_LANG['twofaenable'] = "Enable Two-Factor Authentication";
$_LANG['twofadisable'] = "Disable Two-Factor Authentication";
$_LANG['twofaenableclickhere'] = "Click here to Enable";
$_LANG['twofadisableclickhere'] = "Click here to Disable";
$_LANG['twofaenforced'] = "The system administrator has enforced that you must enable Two-Factor Authentication before you can continue. This page will guide you through the process of setting it up.";
$_LANG['twofasetup'] = "Two-Factor Authentication Setup Process";
$_LANG['twofasetupgetstarted'] = "Get Started";
$_LANG['twofaactivationintro'] = "Two-Factor Authentication adds an extra layer of protection to logins. Once enabled &amp; configured, each time you sign in you will be asked to enter both your username & password as well as a second factor such as a security code.";
$_LANG['twofaactivationmultichoice'] = "To continue, please choose your desired Two-Factor Authentication method from below.";
$_LANG['twofadisableintro'] = "To disable Two-Factor Authentication please confirm your password in the field below.";
$_LANG['twofaactivationerror'] = "An error occurred while attempting to activate Two-Factor Authentication for your account. Please try again.";
$_LANG['twofamoduleerror'] = "An error occurred loading the module. Please try again.";
$_LANG['twofaactivationcomplete'] = "Two-Factor Authentication Setup is Complete!";
$_LANG['twofadisableconfirmation'] = "Two-Factor Authentication has now been disabled for your account.";
$_LANG['twofabackupcodeis'] = "Your Backup Code is";
$_LANG['twofanewbackupcodeis'] = "Your New Backup Code is";
$_LANG['twofabackupcodelogin'] = "Enter Your Backup Code Above to Login";
$_LANG['twofabackupcodeexpl'] = "Write this down on paper and keep it safe.<br />It will be needed if you ever lose your 2nd factor device or it is unavailable to you.";
$_LANG['twofaconfirmpw'] = "Enter Your Password";
$_LANG['twofa2ndfactorreq'] = "Your second factor is required to complete login.";
$_LANG['twofa2ndfactorincorrect'] = "The second factor you supplied was incorrect. Please try again.";
$_LANG['twofabackupcodereset'] = "Login via Backup Code Successful. Backup Codes are valid once only. It will now be reset.";
$_LANG['twofacantaccess2ndfactor'] = "Can't Access Your 2nd Factor Device?";
$_LANG['twofaloginusingbackupcode'] = "Login using Backup Code";
$_LANG['twofageneralerror'] = "An error occurred loading the module. Please try again.";

$_LANG['continue'] = "Continue";
$_LANG['disable'] = "Disable";
$_LANG['manage'] = "Manage";
