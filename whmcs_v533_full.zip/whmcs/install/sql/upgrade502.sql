ALTER TABLE `tblbundles`  ADD `showgroup` INT(1) NOT NULL,  ADD `gid` INT(10) NOT NULL,  ADD `description` TEXT NOT NULL,  ADD `displayprice` DECIMAL(10,2) NOT NULL,  ADD `sortorder` INT(3) NOT NULL;

UPDATE tblconfiguration SET value='5.0.2' WHERE setting='Version';