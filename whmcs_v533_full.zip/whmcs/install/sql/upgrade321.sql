INSERT INTO `tblconfiguration` (`setting` ,`value` ) VALUES ('ProductMonthlyPricingBreakdown', '');
UPDATE `tblconfiguration` SET `value` = '3.2.1' WHERE `setting`= 'Version';
