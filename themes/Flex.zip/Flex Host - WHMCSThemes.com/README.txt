=================================
 WHMCS Themes by Zumada Limited
  https://www.whmcsthemes.com
=================================


Thank you for downloading our free template.


Please visit the following URL to access documentation
that demonstrates how to install and edit the template:


https://www.whmcsthemes.com/documentation/whmcs-templates/flex-host/


=================================
 WHMCS Themes by Zumada Limited
  https://www.whmcsthemes.com
=================================