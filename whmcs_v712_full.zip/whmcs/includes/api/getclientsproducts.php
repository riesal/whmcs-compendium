<?php //00ee8
// *************************************************************************
// *                                                                       *
// * WHMCS - The Complete Client Management, Billing & Support Solution    *
// * Copyright (c) WHMCS Ltd. All Rights Reserved,                         *
// * Version: 7.1.2 (7.1.2-release.1)                                      *
// * BuildId: e8bae97.200                                                  *
// * Build Date: 15 Feb 2017                                               *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@whmcs.com                                                 *
// * Website: http://www.whmcs.com                                         *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only  in  accordance  with  the  terms  of such  license and with the *
// * inclusion of the above copyright notice.  This software  or any other *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license.  WHMCompleteSolution may terminate this license if you don't *
// * comply with any of the terms and conditions set forth in our end user *
// * license agreement (EULA).  In such event,  licensee  agrees to return *
// * licensor  or destroy  all copies of software  upon termination of the *
// * license.                                                              *
// *                                                                       *
// * Please see the EULA file for the full End User License Agreement.     *
// *                                                                       *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx8bA6hMmf1Dtz2zIQquLeTwtPYD1AqXLS5dfcCwdmVrqWxOZ4cAOSSkzJDdcXl+E3NO9LxP
BoqD8OHFC1z4BE05oN4ShGlwgefUFU9zq5tDgXCF/lvIIWC1mFDdzNqSkIM9gSGYsZszpzU1KKWr
4ynCS6zK4F5PX9AesAXf8/ajMQLWlQ2Np/2X67Kn4O3jGO+GXgZ6+WchoSf/MoBvXF2GhivwpW0F
axb2Hrnqbp1E8FYnbxBYCy71JlZnCajSbnT8IzWmZaT2ev6mLSco0NPWKPN32UAMg4SLzkSetYud
Cew2N6/9AAb33LnMgCNwZZ2Iirx/esoLQG0Pw8rtGP1l+4Plzml66JXY+7HWnvl9m9mX6lfNcROY
NHSW3VUwW0Nh+3d2qjUy3J1/XTXfeHNjugBRqNXlVuBI0+tcNh2gqYNHn4cCQRbVV3vXsMnTNdKa
e7LC7K8apFvlcn6BGtYxZBZkfupHV+J+TB0hAilZlpkrhLiRzHTP0pGivFwsGyyto5SACBWSI1zr
JNocHeRc72qVThX7s/Dcr9bYhbgK4Fhst341pSluytG/w0yiNXSTzci5bI4f0J8SCRd+q5XcxdRz
1DHBcfdDrpQOWcPSLqjmxUURW1DuQIdcy78T7XZYtoGqtzLh++8BDiJG5Ly68EqbNaA8+9KV89Td
gf61dNxSIiMi8IwAW38q6+gAuMaN+jkzqg5GLfbQ9Lsqd0/Vyjd9ojI4742upbb+O0uXSAKOSfTD
xS6Uk1gy3+JoDvYz9GcP/84UQXBF5LydIgxtHzfUGZY7hkDE5dEWneJNohtRsxUKIJ5iZla9oh1o
dYMupCURjDwb9nOgP+KUSmGHfI8ZuhLdnhhMdSHl3DBnLiRTD7PFiJOWJ9+6EAzWrcdEp8WQS/cd
AnkO4jg8qnoYAmmt2UJL0L0Qnzyw/AcY7fmExAQPMfrI02ZFgfrN5tbCBuWeJr/GM6/uXYcPXm3Z
S1ylsxvwiqa/au73usVTrHEILDlPx/jMbu/f2fTRyyaGKQYF0xSJdaAvKTsIPdo0+WfzNjcEVfeV
m9Jm29Fq+ABsgl+/oqP/DmpilXLe1zmpXSf0jRzsnY+EWhfsb/aRf0rMhVPfdsNegrLmTNKgfL6A
iERPXKsZ6Yfv5eoqo3CSFYt3sgE2z61erUdC714TEizktkbA0GjOKmfYETEzMsJFKbShZpJz7frY
v+oLZ76M5JLdn0+70Zt3kCSBMqEzh9o0qiJaKvR1QyG2MAQWmQ6ceRUfZNkSJslr5/mSn2cFhDnw
31SZo2tum8zUbVOCLOHgsfVMvuXEY9/P+oHEZqx0VxqoEkXqCbeTl1LqECGCV8Nioitg07/1QN4N
yOSoff4HMYaX63UEFiLyDsyzrGDDSy+HyNJdBFP1hOl5PB4NgYeY/SrVDKnbrvWh0giBFkjBkmIg
rGBjyaGPznRtMXv6z2DP35hnQ3uc4ieFtzBHnPo70fWYN0I2I8yNK2CKf1Cd/HzXoxhZu5JtQr6x
zIp96mU9JdX8vJfYnSq66XcmFRZKa5iTOuPDbkLImLU0ys9CVMzrDtB3Ih4Qw8rpRiwDhayxbgVS
dRp0/nomdrrUJz4MxTvdQu9l5xfL21KN8vxp6ZgiL2HrscE55tjyMaSKLcPc1NhysRPcosR52AVz
w9R0JHm2pgPFgjIHX5c5OnLsjEb80rBbqLY8eLCoVZD0x7SPSoHwbl9N3MMkcoZEya59IV5oaR1A
NPka7okqDhQNRBk2oi1ww446Lzmo9EptUcAUDseM6fBcUA1++Uwbqw/fIgmAi5MpWbv06ufVVH+J
VpA+SIf+Luo4Vds5XkBWTMldXAD0LEAVoJjrdotvdOCNHvxsI9F9/plfwPi8b2/FlvXAg+K+JPKC
vvOf4ifBr0cJG/42uFhIhebWacLiL09WkeOVgehGly8wtGDb7XQedj15q6ldS9lwbx0uJ4VpekdW
PITbdvCYnXi0VEktpogFrBpgtVkXZZ2fbtdfkuWUrRixIEUI5vc6BYhUrQvIZUrhWKOo93uH1pyu
JKrt4DR/96+bexCdxnaM//A7yizqxM92Bu5hujHW+egvYBUYCeWsIlM4X0b6SHtGIFxrfUVpGzor
AYycxNARp7E3MyoTbFQ5lf8UVxI6Zwu36KUxml0t/+fFeiBhfPyqgvRDOrXUdEORdn3ZDPREYeuN
gUXVVDREdqiGhdbdZygvn9qIxx0JCRCRt6Z3hg7lOU6lHMGNQwSQS702N0xBB1vtHA1BGBYvNDK+
4A192IJJtUIkDYoR56MDwBGYlalkWhX09TFUSZ31lxq0UtCMl8lwkoXmx3F+x9MJ8zjVS3ZS7HQo
lv+9PLwrHSRl/EGGz1kFWP6LbmHtdVP93+kjgWv+k15fTjkt5/3WwPBrLb1pQZdtg6wnwvMLjcpe
xb+xVUrjkV/UjctZyqENIFoy7zooKck+0UBjx+YHk+WOgF6r+YaDgEYDEzIZzhmCTDJJB51MVtUk
XdZEqoWIr5PurovhuLn5BCyebdTyFMxhIDQSLNflucqsXj68tf7KGno3Uy91CP07JuiQIbdyoXqh
dIg/75HYLG0GRP7fhhUohE2GYSXXRGHV7U7C9CX0xyALZvbBiqL9kH8k0gkSuE/MEPtbyZOB5eGt
av/v9dFWtjGQR7m58Y4OtVP+9A2ngYbtXvjI77SSVwcbTLNTr7hcYcvSCU5pi9r2NNNCl3SavcH4
kaMtPjxwvRJg3n3yziXCmnsFNYUL4TmrHmg/9HmYwsms6cNsFKmr+PQMwyEOSrJaes/0Ylp3cudX
z8QU2LFNC/g5LbytX+DJB6O7Rvp1/qBeycMjiuI1+LkGScyHTKAQ6opESBvKMtHyy1T24gUokHIq
pcvTa2gggSf5VWWip8dp9abY3rp+tbt5xIf7qasR56prAPQCekm/T6zSbRMXi8XN2OEf6O8br8/x
u+1MTtxUEKn1zurd9N6HYNd5Otz5bDux0T/et9i0Ffr/y9QQDfb/1uxrRGObEqJnGN3w8jf6bPLq
qqcgMakWGcCZzOPRQts3ynh5Ddp3iCuCA6Y295SFgJ4hCjfFr8GXBMJEGF9avUJoYODtjbYt6r0i
ltRqvtBNAW/o2oIC+r2YHjNuojkcjZj1BDVYOHqRrHYNVzuwBJTExNMJZWtA4XKpUfLJMbckt/1g
bAgfaDcg5dHBzkeEtj1qstRMHH5Kx7Dv4QReIrCohESVecniBzGDiFIvuO6LK2IwwekRKVvPJXgM
7UevQzsPFjrDBN3s0Ua2gZykoVdLW7qedT4QbvvYc3cTYR/0y5YBd9AvOWBmakK6qwqXQTL7UQjG
4HctCs5AbszaI6HKtVcjBWXqU7qms369qeSmCKBR78GOeVkGVvCgLO+aNZ9DPy/p2PssypMrVVJ0
tiPxnYX3t4dSC6zlhQ0IwnCGKmItOZOAb7p/c8aDrO9neqydEhI0Y+SIEnEguxh7knhfvofkn+hu
xRqZgvHhatCuwoK6lCDtL5+YU98iuCMhUPPwirQ3z7v2/xkigAeJBFmbUMzbfDLUqj5gsXTH6ck/
Uh9dXZsZnrDFk6Z7FqBiZbXEnyQU8Bm328/+iTUBIfB4Ng2ST1Z0G8jq+ckhZRFQ/tu814k91QZk
E5AvSMtC8VPbpPy2MCTIMm0JlfD+tIvDYjiRWqoGXsV6wOczcISj2bxo9OLNfKsuGSbtXr7lj9vW
Mt0IUeAJH53k0HZnT61eeeWhFSrREAEq0t4qh9q/QK7L4OoV632sXY0vWJtt51GbLdW9W4hhB/+l
al6tmELmuDWLOneRs1EFU68/atGbtphaIN0XJetkXsZHk/+hxqPHuXBdKbpqtIX9K6oTAwfaMiw1
z4YGqMQTvG4AK2J89Q/2K51B06VojevDnqFJs00bE2LQQOMSkuH10RUQW1IeDvxQ8ZLXJLFPPvDp
YbVCZUH7Jl3+JKGKRWtpiDcIKdGk+aB0swjLpdMHd7QwTIoTCzpNznQQxD4A7QbKPu3akEx72k58
kHXHvgXR14w72DUAvmlRZtDPlPjYPEfMn6gEOY0PH1cGnWcDXZAHlGLQHlE2hkl3hMD1QKMjMORk
K2AyTVQLbpONglLcpaMqVNsR/a1UJE/4rKWN4UzKPRFnfBkM7vlwi0jDub0kbxje33fPm9jpzNa8
An6Xe8YWKiC0Z1WNUgHx48DwQCkq3JNfT01WRraPCf+sFp80plKlV4xJI/EPY+D/WRmHTOpYrju0
FILSooaT7SH9UefJ9BdIL1/WOnXm2ggfWON1OxiwtA54bbouyZXbCzdYMj/r8AOg81BpINoy8wsM
uTqLg/5+FeamKGwxRcuDUTV3DTttkEI7PQJ2Vr4j+AegCllqDIRKTUQ2oeSWdX9rNLZJ/kMulljT
TCvKvQOAmar+7u8KCeCXoRLqZ948IoqgsqFTEUrAWvQIP2uS/iu+a86AA5yR4SCG8cLUfGVrzEQX
DStdMkonubyOruFPLSdiKsmJtYl0r+1d77Z6w+A/QNy3dwGVvd6H9L/N/rry8dar57sCCsI4DvmT
RHV8GWGJWC3KsJ3jTVHwfRgyskLzDy9pUyNQeAN+ubm20EGkdclohM317H7zYCcTI23bZAKkQ+TK
3h+JBdFZ7YgjECIHm/1UujbVKzBWVQPbqMHsvRYXkhL7aNItV6EFu5/cy0h+Zaj2X9Ldo1ACXERU
Es1QU55DH8gugz7fGpPP3PGt3iIcCv6G7r008tukw58z0Y1P0+M4+IF64GaRWfntUc+zlb6rUzvB
10bIuRcd1E2R2JKNoE1oICNoAz9IDSXZX9UBd2PPyJhmP0vrTdpF0bDuEKQjumhviwce5fD13idm
39Gx10bYmoNmxRY4l4UkCms2VCril3wKENQIWmldMzqmcGdiWcaOkU8mIk6VB+cHeBNz8d2hkONo
EJCR+ksEUpKew88F8Ak3zE2KKe8noFeWW23t1+cyVg7yfRLvxoDV1xFiCD8bz/ePia7QNY8sPqge
Plafgx/OFsEvPdVQYIFqMTNM2ZLs0pCqfD8oaatq0+OHG382DGek+y7RA97LqarMa7NAfO49l4ak
xaUVbiAw9udn38fvp61CfZYD/vM/Eu5788i6ntKrtjqlbWSRKML2PhCJWO8wuH3jcEY6WBc+0LuS
FpkgxFiA1Z3xE+eJWZSm/uVLIuJmaQTF2pHHlkP8HkFxNSkxuP0MAbTe8uw9nFe60YeMuDHWgaFR
yH53bCSMFSXkd5Wm9TEJTqdhLzcs2q34RzvTMPCK7ambBCkT/82S99hiUcuvQI53U1Nc5BTRTw4z
3BQkv3TnP5pLT8cgfD5COtwsRZrjGjAbU//qsXNEtxeFTe2rjat/QQwp9XwPeXl+EN9vJZ+NO8Mb
4GAJBWnM/TPbVX+DVpGh1VT9YX0CYZkWsBMoPiTIXH1Chv28tFo5PQUHDg9bsmec5s9d/psS6UTu
3OsO8P6ePwEAKVfymtKDw+petowYTStsPtJPq6sI5DSBlU4edrcCFQh97svFDdRAY/CCQF9Azs0z
ixfqqAL3OsNSZ/8qtDtkGBUgSWHK2t7xo69i8vpXuWcdyKLWWfhzXjnbm82TBpaMWV/1exBgC5Os
kGMCxnNWuwYOuOxnGwzUbbbHgzZCfrNMNSpAMQtLCcx8jwydpE7g40FIBxw51HaWov1/wN9AdJjJ
kmD9K7bM9GKWLHkkSXpDx9lpLu4PuhKRVXO7YOlto7e1xdLojHS+HHYppxm6hlFtvy4CNxWRMQSB
unn0el5s6UR4tHkdRcnypnBjgz/d/SdpX+xPiZWN2kmd/irsjnAOiTBStF8K4/wuf2oj2qqGHD7p
gG1YdmVb8QRy7v3uP5KfJax5N09Jn9nLOVo5MTqE8h0ZrgT0PjvkH9NVT0N1TOUlTv6hHu7VIPLs
MOMPxo8+/4EiXgZjZYJFiDrxuUODsurX+mpdCB2Bg3lWcNgrRlSQPW/XwqGqoESL2Ow40Wgc68bi
GWxMCxSpjalKNAKwrJ99sjeUPSsU35Ua+COrJCkAv0cDimJizLAqM0YiE3hbDk50EU/IDHf3Plz7
2MjIJ7zt2dSMOls46EaAzgdSVem+V/Hz6V41HIUf7w9tv9hWTJFMfiRy/PRceofP9zAQdtbPA+4T
qffCraKW9gBKTISkhz9pbW3Y7BTRaVT9t2iKM9kCgpyM8utD/4AKhzI/2aWi1+BDhe0hOD0qOgXc
hB4qRRc5F+JnC2NvtTJHjpHrei2FT52JNKB3C27CwUoOeUGrSjGbz3gxu1IcsqO/TvjUS73lsVNI
X+hNUtHSW9fw/FehjBkpXcwxPmf+x5Tf3yHjMiUFrCanYOjUVPxB7tAAJnP9X4OaAyvt7VTlzYvP
mqMyj764CPcrG15F9rBBpJIEOA+K6F1CUq/RAZEY8YfTvmf3s+kr/aDBYW0VV9ybcQAwcLGjuoZM
2M/eJgcsj8cAhyGV42wDquEEO+CiSO35EZqe/5AVsg1xX9wZp5LaD0cjG+TUNrPvd14ALgLDJStf
SYUqwUrJswQZuiN/LfCaSC8NGCrhBiOrYMW8lk9saNSZ9LM8jK/svHxdgb1swzAqbYS9SSl8ZCNY
b197Jb08hVSFmQnA3LEM0RsaRaEcnTEWgzcka0CfTVCb1HpeEndqVmmFxSvdfBUTmFcQUJX+Hn3d
m4fi9HyUiww28KZ9UCCO77q4qxvjM9jPKcdhbSV+qBvVxd73ZV17Gs+vCc6IBsr1DtaTIR4eJyIK
FH5Uz/QTq0FInb0/vAKAx1RM1n5Nj9CTEhN5QE9SxWMNdL9MAN3pWs5bjurrLVckXwjsrCBle/qH
EdNQGt3//fhS9cnR4zwQklOwb8YjDloGouoUJDNSg471kMYJjk1afYrbkwcV2kwKBcHGWPd/tn7a
6V/EWc/NeW57hsN0mylsipvdaaiO1mNkbE34qpiYfuBEIeOgDJNsuxN7m8PJ7YBn+UX7ijVhop53
3R60lETHnhrTZNDSVkPs6Vvj7hRG8lKTMrQO3hTT+he7B3ASjzbvKdD9NLrSlZJo+JDfjfqsbRsX
mn1MH3wYx12xdQ9TdspRki9g/xjv5mjCta2+A6pOyy76IzMaX13KU2a6ElL1eksZBvsUApAze+eW
dqvIKG7rQIh8qQ7Ne/SOhO8LaGrOkOl8DZ7oUjxtzsK71EvrMkoIzH25Pd6SpjTVkBKT4yDh9NRL
Vr7VHMGs3Z1BMpzRmP9wQ9+bMt2hY1texTEC7dj4+bj5r8DylGDWKH6AiGQaS375XTVmVBrY87KW
EVlkIlhntA44TPkrGx1qTGdzh7/Zzqs6tWRCmycTo74hKvZiODRJhApQSZxBSXZLGPF+wEkEmg3h
7zOhenIHqGFKn2NfgMNnzH66vpGJ0nU/xTO4UhhWGDWvs9tP5Ucq+VjsgktgW1t4x4QYj2v0z5rZ
cSykLmUrOIdNDDhUeAQP9XXQE3jk9/flGKMVYm56QFtSw8wr1HTOdUlmlnoN83NUmHdCDd7BQVPt
SZKpM7vTUg0JeAz1viTa2wJCeZKkiit6Mle/qqpe53LGzV+DuBWnY+pXDWHaRJ6j+212Hag42su4
1QP+J7N/gp1VMaJl/2Dk5+LxbqXM6CSjFbfgLk8xnic+1nO/AP1jyLnaiWdRR1MwZ8s0KeS9ATkY
rlSgEOxa/4wS2nUGnGKbqQD8VSTFJ4mPU/9iq1/4Zsat+1fJWiuKAiv7uvWc3+VTpOUWJ1l09VBc
EUtrOxtsYYr6wp2PLw7kliBi+YPkvGSgqNo3i3DvUUserOHQhRciYbYcb67UNVqjzhvYHyb5EQQ/
QrXBvC6SRIOL6FL9P2lykekkbos/hFDdoyM+60OADLuZPetBExA11sfjgEMAPQwzArekHcANOJdZ
4M3L6N2nDpJ4GSds0K5MKxRkBToHoPPqfC0ONV8qgdXwNxBwZWDiwdu2HvEJvBGfRwQiiYLalMm4
mSujlKAQL4NLufFdkGuZKoUAULd5+BmqhgI5K0JVcbpGKpCS8CXHnJCBSQzJV8Xlv4BGUx1kjRX1
PuvPgiCaKVFXPiSD2yD90v6Sg8B7qDocSbHiFMwDyQmWOwmkDDNvRnvCgbmiqCXxwFptjX8LKaoy
tVzLfrnzXi8iYcq0uOgx6usNmWecBu7N5AUymvltnk+IMn0rEkHH9td6dniAJB1m+j8Bv2MwiT9Q
/6XHr4lgI0o1lFPQCO5iREaAPvk8KkKB+TVp4umzMwMWIGOS8jhwICvRiOO5hBAjM2AT0S+R22i1
o+wfoU0rW9SnYTH7gq8/18IdunacDsTFUX+b1gMAa2OOHhwDWKhH14glGDfNWlyGgmx/ND3M7Ndf
zu7+4xUbbxL2MbUGrmyr53P6lnXguPCrGazDgWsE8sVeie2ULld9m5PqI6FIh3yWPu76V+bTFMGW
PzD+2EAy7OJ4xrg4Ha8lTXKt4uqBthF8Pd7/WVEqHmBeaPiiTPL7Ayc/IE7x0+Z815faLkyCsA/0
CNJzg7IOQZu1VXYE/K0S3evoMuW6D4Hp2S8HMSWf4L/96FkL45LoYEpHZZ9qoCf/V9jpLMQfnyxV
1jXlV3tnh1IIoU+8+wqFYrubX6IGT6/oltFNDrH6zs4sQ5Til67rFLWDBp1FcAR8NyEHzqiBXvXN
8F63l6MQ9ToeEjt01fgwac4hIwrZXvqsfZMvNNN7QO4bb4VEcb3h6y/hZvjn+KDBkx6Q+l/Mc9i4
WR+Sphqg8VAEzPtFY9n2p5czXtqsV+PaBOfZ7lpV1suKFsrst0NJyLXdcRiAibftLdNdo1CYKAjK
VfAx6RVi5/y9ySoXqUtebwVCaXh/YknTwZC1OnsLARebl9eI6u1nL+5Ln50Utd5K8ErMAi+4zG7H
2Xvdp6wGp9ANLQP3xghlgokXXC4c7hea3dISotugfqK7gdBn0aeNKRiOsq3VRIzw6SnF/YDiO99Q
GnTgNWfSQT/wi75PsrLs0DNzUSxhFMlkVe8o1iPYxaJThmNoGowepWkKZmtm1Zx24cJUpNuSuzbe
VKg4Ip1gwLJl82WjARIg1hCGw7bPAecDaIWGBtmWvrZMMK5UKHBp8up4QpWBluM0MpAfAjfJTOQB
kLcIGwo0TYdmUDBI2lBodGWU2bdMJO0lYynJIoQxYvffKNDE6lmV2nDNZ7B4imacfX+jyRUsjRGH
FhnMjwrxUmjH/ZJxS36fAQl90G7rCztDcWf5950RbdNLS33D0VExidxLv9VwxJyD2UE43ZZWODz/
Eag0jraf+m2wjvUelBNW8d7eHy2/+0VGgoRhM+e7D2fajsvpJXzXsKjnzFmEHHrw//Plulgv/WyB
PadZeLsamDQkuZbz69EP/G04X1PV4w09rx37EWE1Rzlqyvqq/h7QYpO3VOPqdvNppCbZYsbCQ/3p
039CqBqfifcpV4noA36/KSNznTtStOv/OC1WjqZ9CFydt4MRP4xMc9iR8O6hlOomOI9nePZC8KIG
IcxkgPcLacxyoaHDpXNUhPDeHPql6dwgQgLk6qGSLiT7YSoxr7maoT1Dctjpe+PHGiNoVGYjgc/C
V6/NswCwokJZjLYTL7c3u4wkz//q8HyjtAN2KcPyg4VXEOWPTgRyX2feELzQ3vZ/E5eItUQr371N
0Pm8U+s0bJFIUIWI0pJx3HrOUcuNyF6SGygtZRrbkBApDE91D/VL2hKX2r6EXsBduq8Ul8L4erRT
XWmiFRZcos9y8B7PV7OB8A6FXs2zCW24KLHT/EOrOhIlJqg/X6iNW89rnlmJChv8e0OodYMjmxz+
o0Vjh0CW+wAplkSMcGr1IP9o+c23KxZ2DbYIJYuizC8EkJLpVrzhPwIzkqICJmN4la3Ml1P3+uZq
XlsjktX19585NaPsHsCmazUSRGpQhwJGkT9/t9Uy+IOg89i50adzeOITDHIqAerCAD1eW1AArcAy
gocqbpaZQDOVUkAEBwIG8AalZOzPPkGOZgG0N6sGSwQIBD/foLZSOldEbIsM54VyjmBY2V+ocCER
qTwqgjdaoL1aEDODd/n+xqQuzMn2fFy2Tk4rHeOSmTs2yNl5QmZOSLLhyKeOTwSFBKPZCUDvLNUi
Bzk04A5hP+1dEybqq3duhq04Tx40gu2V7YPMWrLwqJ2i1AAH2tzJx7L8bkLYmfASd2HrTdLYOa9r
WqPwHzkPRugk99TnEE6mtKt6pSY5oV4DCRHqqWYD0VhbNCXFo71RLhpnimrHDFrZaGlLIxqmVHvl
7sv5dzO7Avn5OcOzGD4CBwZuCZKhPn6fUeLKPjkzJdozJitS7Q+A8XFmBL2fM2DZzW9lP2boG05F
u20bMZ7rOCWXHQX1+ZAu8Vly42JVr80xh7KuUdVbSASOcd+czuovPfIJOakGqkkmpxGRvPx0wOTs
4G6Kw4HPP00V2eXMuifuQAmNfzY8OojqffelsMiPTRUogAKmM8uRbtYWt4mmugSMKc8rp6MdtSRO
sU+ruGMLQceep7z0ldTxdbW0uMxDx2+NIqQ19dMxbENYKo6ppW4VcLWEwwTBH7Y1ohKYoVTzdmSD
DFCsXKm8ohvyZBLiTO68A+96jRXY+yRVy8URxdbItnEDtZb9wwTyf8HMjLQJBzW+gnTx2Y6ONWBI
jaXYtQBgClEAJ5rxq45fWyGwvMUhXXw3dTcjQWdTlxHR8V1LEaZgEIuHnT4iam/7SSoifQ1DDax/
tx6QWPiIm2u3iVLGjriB9zOuWUJjr2vYaUg7Fbo3MaifV/MC5Qws70XfGICKTkn5VcIBS8nVo1O0
3fJ5w3qifiu+438NZFHvdde7kmxK85IJbrgXZzDwkv82WLSY77wiRnR7e/z5f583UXHP/0FVViad
xpklsBt53QL145J+At/3UrEfL7AKwd7qj8tyGWKO9r6juH05vzWImPiIJbFsCSycKl8bCYix5nhf
2oi95xYYMjShDqZOTnlnaFh1EhMzuSEQsInCZXf3wLPps9/RnXF2bCrxwT00/jgdxkk+VMA6amlw
gf1x5JZs3I843DK8Fy+yggPANhVDfgeOGDy+ebx7yLar/nDBVl09Znax8q3i3djMiNHMObhWoQu0
fbsvLYTxSuL6eddxsLejO0AojJxB1jsfbVuTY9ittBQ8UIkVfZc8OkwHfH75YXnyAa2TGeTH211J
pNJugH0PiLwVFP8YJJGDIEVRnIhVT4karewNq1aNcMYt4KuLudhQw1uSdUcqGCkAGPgsWU9hWSuH
AH0kjgckv8bVVf5lx/5++w8sLuFSs2ItWvqb98DSKxOC5micbR6KjjaGbZvPmz/X6+JDXdNaLlYp
8bFJorySqOmWN9D3JtuuHqfQZ9XFQSJtUI6PTq2vQrNMi7qc3I1H+uo8eZ8vnHWIj8mborNgCuqX
oYgxVpR/8nhTb+ywrZKp2I+NE8J8At/iGeklN5lt5PNy+gKHeMmPpfZ0YVNJTsHZfq9dOvQhljXJ
gI4xo2lDTpSU35dxBuLC1NvafBa8SpXHm0VSUAb6+sS05HCzkEEiwlzKQphBUBp/Kzed9hKm6Of2
FMtWOUN4P1MsNR9JAsUigrN5If7TevBNYO+P1JQZ5YeO4To558o539k9XOrN59cJtgWmttV5CxI5
SAa0dRESFoQwe0ss9BwrwNcYkKG9IXMVVnFiOvFgUxdI0Cu5tfrr00h9ezTn5HuOTRf8UoKwuvCk
1L8Xz5DNE1MJ4ejkHW2Vz5M9GmWw8GkwAX1wil/XxHC4L2YZ8lgNIQDf5OUF/09XpGMk6+uaRz1/
n2uEM3aInJ55gR7zCA0E0NKJbDvMrlk/N7um53vgBW3uQ7PkaKc6Xl8l+M34513PHt4IhnrmXGvu
N0ZXmcwMBlCIwHSRNTyUioZ7ZdvxU50/9qTBgCwogoZ0i3McjbLa6Xmtzl4FeRpE92qoPSRim37a
zekQxbK1nJ0xJdfKI9oLgtktHuYXZKXYsFSz3MAhvsbzNHeBJhoN5Rais/uqhjz51923NqkjZ0hD
iCCfJhR/UeaiPv133GuCWIgs36+R+agblfYg78Pq+NRhgfOFNCzdGQyf2o811nC4h0xMBS5EXcR5
4Qe7IO6ay+a3/upCQ+ZDIXk9x7yP7070niFNDqNX8WAvqmShykYslMY0tedZzfI/3CKCIWMR6w83
GN1G1XmrinCqkk5rc/cPaCvAYZORlPcrUQbr+iDQqPhMqnkEUHgsCrzFf8JSG4ITZwH7URE5sq5g
VtA81+p31Og6JlZKL9CRYfO/w/kzDH9+JR94THxeVQZzcLssZggR7MuewYkojWUox6kolvPWubF4
8RlSY05cQ3DNS6AG0BCQzTq8baCOf5pp8uEwLgmgZib4UDArSfZ+g5QqOr9nRUZjywUszfDsGpiT
gEkTe75srmKPdwyugXfrQpFA9fPHSHzonT+/VvinWeuBa0DX9st/jAX/oHZi5ETbGcDZZFTgK1AW
KiJv1kR2lgSXqUXLjE5Sjq6h0uUUpexayKYr4cMLaOLX9gE80ryDCrEeapvCcPPolr2sHZr1Yqy1
GGbdzO61V2owc4hifZ+TG3JsE+8SUkzEcg09bo11ZM+4RpHZC5mRaPif0mZYx6kpZifv4s9iyvug
aSLyburOhwT1tLyldgGd1CSF2wdyP67vBkUdWcfliXjyaM9VAZfhVZ//ofveFJEmV0V1Hjj16Xoi
DqnBTr/qp+gO9NXf5tgkhKtjGpiS3zWkXxZlzQAraHpDXwpDVIUHFZ+tMoHceVHjXLr+NR4lWzoA
7ss8t7h20BuMGqdqzHUkdiS9hHl+gdYMBth5OkLmNQPHHhFG3U4JY4lBOIZgqwRY1sMQvGg5DRJi
Fd/Aztf+whAMtaEkWTbAgyHph7CkIZ+r/YcoWmvwFgZJeZ2lPVW6s968Bw4cc0jmMFVVGsEhuzFn
MfGBiiukOWpy8DjpHMAo6d2dea2HOBRkTqh+j3LZa2RWQJ66ceGtNtgkXklHgj6Taj62NJL4eBct
6SFQuOSdviuZGMEAzfC+U2eDn2ENnh/fwnzCbbxddbn+Zb3KBWeqG3bGbFPj4x22JXh73nf0Teji
y9ZNllitI9YpLCtq5rdHaexRH/ONb/yu5bRr4koTbA2BQAgpUSZsMBWFelTvN2X9/oh31lWw920z
Oqno/EmigwY5YmPIUKIlTuIH56eeJYloxGrAEkVz3A4i9lyqfKPjjWnnbb4XqKZXmLizABsE0gOV
cR8ImH732RfhVZKgvaSK2dBWZqBsbPdO1a3+1thiPCJ2xsNt8h+3+rbRaXyPsB1XyLAhs0xL8IO5
afM2ozWCMANH2xA+GBl2CKWtLe4zHWeYyfrH6dLe5IkSKhzDC8LmME3AArcsYhwTiQmfe/LqX67T
HNDzuZHxH46AahRQZPdOAoPtpCIlhUV6oxhhjnjJ2uen5v5wMPuUyObKJVmm2X9Yt/aSlChqNOjj
NV9sUFBrSDBMIOLq6raKaOLF3GX58Isi0tSUFlumavCzo/BoNEX8JbhY/K7m7hYf6cOm6kBLXY1d
YHk2cNQsHVu8dAEiuW03z00+3WDeaZ6lLbD/J6zJB8h0Y3uokLyrd/GmTeQVlrp0kClEuAIcy6hx
Df+7ZxFoJ1FPspRCjtIGTBUCSwjiqixtZ1h+hcWFje64WX0dRfbmOOxC7+qTQs+9hbAxBNBvNoiN
NepdJPjN/E4lZiSl/bHIDGhRqknjxiGGMA9iKljRIofF0CGUEfQpDkMZckM5shb/YUAtQ8Up8i9v
2F//kVfPXF35aFiHOw7f9OUFcINLZgxMNSFUCRYeZrt7KuME98z+qyOtTDL80O88ywyTGnC7Za5K
flSEEJO7A1urlRf92yJOWweqHcfHATBiXgSmhHkoN8NLuRPzlZlf2lMee9EkLrtxkN5GT6UJrGGz
cb1hnCteFObhQUniVA0D3gbxBSDNIfXIMSJpSCOVKAgKTHMakTgpy09vkZVyfM0mDU69yPlPyBf/
H6lRJpXV8zSu7cb57yA7gI7uh91RuR+tUd7yOE58Kcor2uSwV6B5hN4clmKgP/qvoqFDyQWuKciL
fz/vceHsFYiYAReVjZkQDjj1Jy0w4tLqyQQ0/d9uVB5z4YBJ0rbpFxSJJh5Igow5hqSNUSi3xOq7
WeKO/wQMAEdjuEl82bwjEkLI2Mpp9NjeMPGmQUS3/o41zwk5T5/PkpCtleIpDLi9dgApJ62RB9Pv
lJGzpZU/3/pSZ+O8IG9iTWSehM9d07VlIOfVZC3m2/UwntXkd+tKizJ1ZiDB4tc5PE7ZR0kfLxfl
EKdGEJfaj2OlFnhYLCWamao4UjqkWRHGENr7wU3gycT46nNmc4HQFhe8y+7rZnaQgNfl70QCNATb
f4f4t4Yw7TKJc0UfTSD+XpOAv3Tsi/hqIlmH8kfNX8T1ZuAQtyfObqDdqfu9bo1GxWpPtjO5dyp/
L5us+rURXg7JRK1nTyf+ADGrSsErfFM9krRssPpbRqzdK8OPIGBeYgC4z+Sb+JlsSEt/K6ln+yv6
RdF/6oQo0B4FHZH1azBM0Z+7kA9+V/gLwaCbxLLEmd1dQq3NAbXxGZcUs5pg9xb5tTWpbgp9Ervr
d0QFmlkem2xP7RZDYh+z8LHgqZM3hkbb2J5uZ7nS5JPj9Axq3L5LqEMzsRS9x9br7mlbOqQRzwpv
ofQDwTEQdvwiTtKL2tYO8yWGKvVtO7k8GUknrQEO7QBwEhDWm8WpgUt2jvSYuaZ1o5aAwM0e7Qzy
WRV2zDes+RwEfrk4YeUs12BdVy9nigvfMykRWSNOsQ98jcj0FORFvA4gr33XFk5OnFHnL1QL+nwh
nBtatC+lwiCw+jVZJT2z9NkNliOx8r8liW7gxIZrBkp9fzX1Ju1Lfa/LqtE7C5Qn9A9anLkKg0F8
4rg8jn94PKILWofTiU29slUYqINw4Dq/Fs/o9frsNk53qvv2Yz4R3KWH+aTRvhx0KnQuxT5y9EaK
cidDpKIw94mr9Yc+npjpxqX/pHObFxia7EOKcAP0+3FuLIIW5Q9SnLWDWkrRIkd0iiH4S3T7QHH9
bubrdel6qVKrjx8vWscCSVra80jERmzVLZHULeSJ9naK3CbYbXbSFS+shbbXsShSQImC011mBqCh
69l6lO6v/ioJg+96XQaIYf//Q6j2+Gwq3MJcwhE4cFosviH7kIXHgOuEQHBMyHTINNwkKUbLYWA4
Y99L+7fIY4B8HqjZWvl3MZLDL5/P1X6q+m0CKlw9fhMfBKrrblvrr6W7CkzEkK6HLswkBghAoX9o
pWNuCr0wTBaHC4SxQMvxUu1nlfuN1YOsqm/35k+TdiY2PGBwZxriQ/f81/K2cKw3HgpMIWuCgrRK
zowIdhVMKpJavoynkng/NLom7NHduEBuXRVudGgI2beoyi54gDydnxCZA5r+vxxJA5Zo7WI61sRF
FnvF36UrJJ7MXspXHaGuLffxZHok3uFNNdQQNWiJ9I/TQelZXJxpDXj2/D778C5QqOjF62yqx/Fb
vQ5LYhy2jYGBxh56ghV2eAr31uQsM9FtMCRPmimB6faNEd+CNZVFo9FtysgA/w0DNUkMQkymeEKQ
l4Q9pdoiZ5U8RAl1XztRuJlw/80Pl6IY7U/XvVNglnHnKutDDx0ONiOgyU8wyQH9pKfSdYEdo2Ch
LNEWBpNAfmNvFdsUHToUdSXHfkvc5/D/McHbNzc9g7f5WxFl/DmDisGInLXmUWADvtkA7OoDBbh3
hGtacv9R6xY8TZ/wYiXITDERZ8kRM+Fq9TO7yq/45OLepifXzaEH4YCWEunhdHc6qDDn/2eqbOc+
JtUIh+iEutoo4OdE+iauGOV3in1Zu2Lnt4NHowxen5K3WGwcqgJWrQ4jdffRk+fVOnDq+3ILBqq0
URFvYs+99V/XaZqeoL6xuU9/JFys3SiQ7NIo4eZxSD3VERUSDuKwKWtjj3Gs/of07h2eTlFvh8Ug
XiHvCgdSmLwduNNSyN2AY919v4jXPvCOyllGn0tl05ul+N9kLtgx2Epw3p8ZkD41vrl+VgSr0+Os
2sZSdsrocluSiE93neS3XnOuUlYedR9E/HHnGLhNwpLukorz/rV5BVs/dETaL+O+JHatB4S6yhCw
KQi/krpvZeMwyRTZpDm7AURxBLwqi+Ac/MLeaqRRvX4Xd17UIsebHvqSBbJPdnaU094ZO9P8fBik
9hb9fEwhlIOPN4OtuYK5x/DB7ExmSwBhnuAihOl36X5hn+eXhf34oAwuOP7kXHqlndYm3xp1GX+j
i0taNxd8k+Rwo88z8dLIMJ/oljFdFyXvK5qVIOV5kFq+uwlqgRu5tukHOYDXxWkG5p76qVejG0IW
8TKcKJq4zwIPbNi4+aCC5XKp4+tBVzLimPLtlMJDzTHZvRiT+g1JgScck/74CHQkQ+2g4NxpbLoo
78Zt315h1UskwfSR2DHnZkBbDDdogug3Js5fyVZyvhgFsVEF/xsnO+Y5tKgzlDtaFhLUM51kjHZA
yjZ6qFRWj7zZcJHCsmPGCU8Az8zaG3WOnAQtbVHp/7sYwYBEAUygXbzJEp9Ap9o+R5mmXdwGml0J
HtZcatqvRzD047wgMcY+5sFKgsvhQbB/azc3eHskSY8R4D91kfHpGUxJhrLtob9LlBy5LigOQOHa
hfhPXBjeYLYbnAtijLSeGXX6iqnOf9uU4dyxq0R9ma4NC/7JPYQsNhaRnb6DukOmpDQgo8evtr6D
ZKfStumR/t4F280a84bKZWpEW2uAHEIV8gnljpSgS3kCmBrFY7sEMJ4j2nKOQ41kqf6x/nN5btNV
U9IfKnX14W/gn8tCk9Gpohm51G7MQ5i1BaPf56Ri+cMuzDamv18s3liLR6U5WoRhPjUie4wPkmka
O3RAM2viSLExLJ7UxS2uFz30tY2cDGySZIt8THPJcbEz62wm6YLXugQXlJupF/aq5WuUEV/zXkz4
GlNCxxWU4Tv4d8ixUUxt3rCxCrfhymD81F9RLEFColRlyyvSdqUAS3LjFcUJXC22A4pa6EGCm1ST
TXphtdF5t8lKiD+4hfnYHMPyUikA5s13NlniEt5D68idD6d+Xu2+s1Fxk3e2zPratJlNxb0IsnHI
PZPR/9OkK/zM8tlLRRc/WTTkhfQxywRJ1edGhfnI7Z6Z+lk+Mr8/0+VWbgq1tUeKD3A9vw1++/2E
Hyr0n4ae6c3BcCHbd9y7JkyMh3O9tVLQg35Dgp1u8ytXABOf8dZLfRnzA9NbupVjFGLB9dnqJpLo
jbIQfKbFFev7dcSpMnDQv4AVIV0W3M5h6EgbuFEeIueDTOiojlNeqFikNMKbtmOspek+AUPrrEdh
+d23hBJ5B363nmywl4UCA/tQhgLD32GFS/EaHIXnsqPamNCh7xnkXd4IneK26jMx79i/O2Wqn9+f
iRCJvRwRiozfvOzd0h0K90+8PI4BfyRJrqPVyA+TS+P/+E+vSBHKt2yZEVxVrxIxXc7rZRYfgMIW
GCbBOcq2rCBSTeOzmyuOTisoX0uI+jGPtnWiOno5S6FkR0XKtzImj4n37T8wL5LcuEAVUqDJy6cg
u1k8z0ARWJL4yrpc5qP98mVrJE+NZlP0oOcWyJfECgQP1S2hQWU2wbwUXAZxBKz6uxs8zFu2nNx/
d63Yk6YazRh1Ze8fVt7l3eiLQn+ULfJfh/GBUerszQZqZeOsNiKLvf+LEYo+JuvyjGr4MCBaO3RM
MZ+vfN1yiInvd0A2iwv/vY6l+Pnx0gC41MJL7429s+qeQhO3vN2R1OhUklmQhy2bza5YeRQw/JBG
DifcEj4Uo78mbF5Cn5I6ageL7Bcx3TIcLbk6TJ4FZ5Z0qkxQtARq7qVo3f3NkN762zSiSKH5vN3y
+0h3DiI1Ha3TDHQfcM753IFzzdjKPu3zLLzo+LSXRJlaALZve3V1sSUR0XxdW4/QNT47DRtNllOV
DWbA+5O7/DDV9MuM/I+SgB96pjOKhsvq+AIsGGJHjCUXWNPW+jqQKobr+nLNPFkU2z/70DWO73tG
g2jauc8kXsW/2qzb65B2nT2D/yLQpHKAkhufUpwj5UrTM6dIt4IE13CrJA+LvM+2D+cBhf9cqnVk
JjLvn9e3HUftRPurTdItBVI2vABSVu9BWOWITtgTtorros3Do6vUpsdQXUOQbKdQJuB9h49Mxi7D
5T3VvlMqRX9jusgD8Lc5vIW+evgT7GQRcbH2py+ML33fWfQBHqZF8Aw/mCvpS7mUld+6I6ZoCEiK
C39OfQ5GGZ0nclZQXdrv1CUnHx7AdL58m6CvmMBAvfPQWg2gK4UqU3GfKEqRWfCE6BZUTLFwAVKa
Zm1c5Fq7vkvvY6p6HvJURQiKS5URMmDVXbHQ7EA//SXPAcXNLLyCbLBOJ7ssqJRNZtH6hAt6HTUQ
Q37DeR5tpDQu+B/htXuOrPdFJQhazmah849JAjXNoq5uDuF8zhmq3gdAKurF9yiLH8qc3SNFFqhd
VNawlvFcqOcp/vWWPDRhQZtUwRU/wUM+dASxUfjiFslcsrDGNKHQuRVmAc9GRGLWwDpCEbHWr5PQ
sSfScbxbPH54rPl3yoUMaMdCk8n056LDmlurWN9DtLwmDWE3xB8oLmOYRObWMRGFXg3M51v+fOwH
J3O6o2Q4ryaslINR21IiO+gKqwiK7e6hWRY9I3i4rSmkHPYq237kRKdKiLYbNQUmTW5bIbEOiW9A
Xq4a+G8qtJeH/7xhr6AM6kaepOAVvD90qPm6T1JSRSSQS1XbwnYhYQujO32GaaGuqJP+lIkUD8HM
OznamshcRVdyewTF+XEsZT3/RRYWYzbfHSSwdn/39HyOqaZzfnUu9W9WLD053EAONGojZ99t48YN
eQ38vl1ugeT761GwR/e6M2jwmocKSayaklW3CtkBGwJI+VxFVMIJ0kvhxax1BVZlcrSz3/GIttU5
qW6kd+affyzCzkuNHrBlqBeqnrC7b9uz8HeMnugb1RiPHypkUjppKiJX7jHyqMvxoP5NUH0szZUW
iZ3o1tEmRbZoZEyWCasbbnf0hAcsNaY7cgxsXX7M05WNEG09WUn569RJMDtTI7bYrTbhTI/t+sHo
WPGhNXjs2Z2K1Fe40jq2SDxBbrj0nm48sR8rKXvWQ31K/vBKAYMvD++Gt87/sSVpZqmWHbFQSgPn
Sj/VYKcNa53zXoK3uvmbcGt1YiHG33xvm6HUETTMG+Q4x9236tvUEC5EYx/RNXA9jMWULqQuBNPW
2MqpPD31AfQkUNcbCwFiJLrkHCKwsfKmM5RaB1qqSzT3iSgcoezukanN4M2a9pH8WflQhXIZtgsm
ZvztdY/KTC+hhO9Ra8utSf5a1L78J2aC1pcA+UswCdgq/swYMsK9Q/91X/Y5l2c22irWTIxOSSvg
SzgojcbViR1w/nYMmRa6nAh+5wmBR2jbQfCXpEUQWkIO+jM53nrhlXx5R5F6hRTcmZqbDjUwxd/f
4CuHNvY3/8TG45uuc6DW2e9s4LQa9D2CXfcZ2lUXeZF7D6AQNfg9U93pvham9DQJlkVUhx0e782H
Bp50CVlg1N12zhrMvDGvZIuYwM5L0/D84zuXXooEVe+L6pl1s8Rgp9qhRt1Iw+HhqSp1ZoTW7H4I
D6grFwzkqsUkwPxQVyKEb8pHT3dvA44Y4UDyWFOpEU1XjZNUnhuPSjWxE2jEIDCeJGc4HpdO75PM
63LbDHYOKWnlrCt5OztNnoDhb4JO1/RW6b4oK5q9S3RLcdI9rN/0nYmNPFoe2MndS/eKIi3NsTVT
JoBos1f0y42LdQN268hTL41yRAaSfF5k9z6D4zT3EkFgNshUitAXQfRUsep6ctFUi/8Kbrh9Rga2
DDOb58ns0P85b6sC27fmpPElOwGcRqAfwqccmWREYrreZKpmXlanZ1jUJzQAVZEAwm8s7FODJIIX
T2kPwinOuy5xnEtDDlwDSd32bznNOzM9w5wrsl1G4VqZlq1trSAwJboxPZyxrigjrzlY80pm1YuI
6vmClk0QT+jY6EzlkigqteLXg0ZYkLK=